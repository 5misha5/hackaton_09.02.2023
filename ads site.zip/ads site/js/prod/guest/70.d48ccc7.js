(self.webpackChunkeva_dav = self.webpackChunkeva_dav || []).push([
    [70], {
        7849: function(e, t, n) {
            function s() {
                let e = document.querySelectorAll(".follow-block:not(.init)"),
                    t = e.length;
                if (0 !== t) {
                    const a = !matchMedia("(prefers-reduced-motion: reduce)").matches;
                    let o = [],
                        r = innerHeight,
                        c = innerWidth;

                    function n() {
                        this.classList.add("anim-end"), this.removeEventListener("animationend", n)
                    }

                    function s() {
                        null !== o && o.forEach(((s, l) => {
                            null !== s && !e[l].classList.contains("in-sight") && s <= r + pageYOffset && (a ? e[l].addEventListener("animationend", n) : e[l].classList.add("anim-end"), e[l].classList.add("in-sight"), o[l] = null), l === t - 1 && 0 === Math.max(...o) && (removeEventListener("scroll", i), o = null, e = null)
                        }))
                    }

                    function i() {
                        s()
                    }
                    e.forEach((e => {
                        e.classList.add("init"), o.push(e.getBoundingClientRect().top + pageYOffset)
                    })), addEventListener("scroll", i), s(), (0, l.Z)((t => {
                        c !== t && (c = t, null !== e && (removeEventListener("scroll", i), r = innerHeight, e.forEach(((e, t) => {
                            e.classList.contains("in-sight") ? o[t] = null : o[t] = e.getBoundingClientRect().top + pageYOffset
                        })), addEventListener("scroll", i), s()))
                    }))
                } else e = null
            }
            n.d(t, {
                Z: function() {
                    return s
                }
            });
            var l = n(4544)
        },
        94: function(e, t, n) {
            function s() {
                let e = document.querySelectorAll(".lazy-load:not(.init)");
                if (0 !== e.length) {
                    const i = document.body.classList.contains("support-webp");
                    let a = innerHeight,
                        o = innerWidth,
                        r = [];

                    function t() {
                        this.classList.add("ready"), this.removeEventListener("load", t)
                    }

                    function n() {
                        null !== r && r.forEach(((n, l) => {
                            null !== n && !e[l].classList.contains("has-listener") && n <= a + pageYOffset && (e[l].classList.add("has-listener"), "IMG" === e[l].tagName && e[l].addEventListener("load", t), i && e[l].classList.contains("has-webp") ? e[l].src = e[l].dataset.src.replace(/\.jpg|\.png/, ".webp") : e[l].src = e[l].dataset.src, r[l] = null, 0 === Math.max(...r) && (removeEventListener("scroll", s), r = null, e = null))
                        }))
                    }

                    function s() {
                        n()
                    }
                    e.forEach((e => {
                        e.classList.add("init"), r.push(e.getBoundingClientRect().top + pageYOffset)
                    })), addEventListener("scroll", s), n(), (0, l.Z)((t => {
                        o !== t && (o = t, null !== e && (removeEventListener("scroll", s), a = innerHeight, e.forEach(((e, t) => {
                            e.classList.contains("ready") ? r[t] = null : r[t] = e.getBoundingClientRect().top + pageYOffset
                        })), addEventListener("scroll", s), n()))
                    }))
                } else e = null
            }
            n.d(t, {
                Z: function() {
                    return s
                }
            });
            var l = n(4544)
        },
        1070: function(e, t, n) {
            n.r(t);
            var s = n(5097),
                l = n(94),
                i = n(7849),
                a = n(7977),
                o = n(4544),
                r = n(6199),
                c = n(5358),
                d = n(5086);
            (0, s.Z)(),
            function() {
                let e = document.querySelectorAll(".steps__nav-i"),
                    t = document.querySelectorAll(".steps__tx");
                e.forEach(((n, s) => {
                    n.dataset.index = "" + (s + 1), n.addEventListener("click", (function() {
                        e.forEach((e => {
                            e.classList.remove("active")
                        })), t.forEach((e => {
                            e.classList.remove("active")
                        })), this.classList.add("active"), Array.from(t).some((e => {
                            if (e.classList.contains("i-" + this.dataset.index)) return e.classList.add("active"), !0
                        }))
                    }))
                }))
            }(),
            function() {
                function e() {
                    0 == r._i % 4 && (document.querySelectorAll(".payments__slider .glide__bullet").forEach((e => {
                        e.classList.remove("glide__bullet--active")
                    })), document.querySelector(".payments__slider .glide__bullets").children[r._i].classList.add("glide__bullet--active"))
                }

                function t() {
                    r.go(this.dataset.goTo)
                }

                function n(e) {
                    768 <= l && 0 === e.steps && (e.steps = -4)
                }
                let s = document.createDocumentFragment();
                document.querySelectorAll(".payments__i").forEach(((e, n) => {
                    let l = document.createElement("div");
                    l.addEventListener("click", t), l.classList.add("glide__bullet"), l.dataset.goTo = "=" + n, 0 === n && l.classList.add("glide__bullet--active"), s.appendChild(l), l = null
                })), document.querySelector(".payments__slider .glide__bullets").appendChild(s), s = null, document.querySelectorAll(".payments__slider .glide__arrow").forEach((e => {
                    e.addEventListener("click", t)
                }));
                let l = innerWidth;
                const i = {
                    type: "slider",
                    bound: !0,
                    focusAt: 0,
                    autoplay: 3e3,
                    animationTimingFunc: "ease",
                    animationDuration: matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 600,
                    hoverpause: !1,
                    perView: 4,
                    gap: 0
                };
                767 >= l && (i.type = "carousel", i.focusAt = "center", i.perView = 3), 424 >= l && (i.perView = 2);
                let r = new a.ZP(".payments__slider", i).on("run.before", n).on("run", e).mount({
                    Autoplay: a.pt,
                    Swipe: a.oF
                });
                (0, o.Z)((t => {
                    l !== t && (l = t, 767 >= l && (i.type = "carousel", i.focusAt = "center", i.perView = 3), 424 >= l && (i.perView = 2), 768 <= l && (i.type = "slider", i.focusAt = 0, i.perView = 4), r.destroy(), r = null, r = new a.ZP(".payments__slider", i).on("run.before", n).on("run", e).mount({
                        Autoplay: a.pt,
                        Swipe: a.oF
                    }))
                }))
            }(), (0, l.Z)(), (0, i.Z)(), (0, r.Z)(), (0, c.Z)(), null !== new URL(location.href).searchParams.get("reset-password") && (0, d.Z)(null, new URL(location.href).searchParams.get("reset-password"))
        }
    }
]);