(self.webpackChunkeva_dav = self.webpackChunkeva_dav || []).push([
    [587], {
        5358: function(e, t, s) {
            function n() {
                null !== document.getElementById("template-form-login") ? (document.querySelectorAll(".is-btn-login").forEach(((e, t, s) => {
                    e.addEventListener("click", (function() {
                        function e(e) {
                            function t() {
                                this.parentNode.classList.remove("error"), this.classList.remove("error"), this.classList.remove("has-listener"), this.removeEventListener("input", t)
                            }

                            function s() {
                                let t = [e.email, e.password];
                                e.querySelector(".form-login__error-msg").hidden = !0, this.classList.add("hide"), e.ga_code.parentNode.classList.add("hide"), e.ga_code.parentNode.classList.remove("showed"), e.ga_code.value = "", e.ga_code.disabled = !0, e.ga_code.dispatchEvent(new Event("input")), t.forEach((e => {
                                    e.classList.remove("error"), e.parentNode.classList.remove("error", "hide")
                                })), t = null, this.removeEventListener("click", s)
                            }
                            fetch(e.action, {
                                method: "post",
                                credentials: "same-origin",
                                body: new FormData(e)
                            }).then((o => o.json().then((o => {
                                let r = [e.email, e.password, e.ga_code];
                                if (r.forEach((e => {
                                        e.classList.contains("has-listener") || (e.classList.add("has-listener"), e.addEventListener("input", t))
                                    })), r = null, null !== o) {
                                    if (void 0 !== o.route) location.href = o.route;
                                    else if (void 0 !== o.userActivationEmail) n.close(), (0, a.Z)(o.message);
                                    else if (void 0 !== o.needGA) {
                                        let t = e.ga_code.parentNode,
                                            n = [e.email, e.password];
                                        t.classList.contains("showed") ? (e.querySelector(".form-login__error-msg").textContent = o.message.system || o.message, e.querySelector(".form-login__error-msg").hidden = !1, t.classList.add("error"), e.ga_code.classList.add("error")) : (e.querySelector(".form-login__error-msg").hidden = !0, t.classList.add("showed")), n.forEach((e => {
                                            e.parentNode.classList.add("hide"), e.dispatchEvent(new Event("input"))
                                        })), e.querySelector(".form-login__btn-back").addEventListener("click", s), e.ga_code.disabled = !1, t.classList.remove("hide"), e.querySelector(".form-login__btn-back").classList.remove("hide"), e.querySelector(".my-form__is").disabled = !1, n = null, t = null
                                    } else {
                                        let t = [e.email, e.password];
                                        e.querySelector(".form-login__error-msg").textContent = o.message.system || o.message, e.querySelector(".form-login__error-msg").hidden = !1, t.forEach((e => {
                                            e.parentNode.classList.add("error"), e.classList.add("error")
                                        })), e.querySelector(".my-form__is").disabled = !1, t = null
                                    }
                                    o = null
                                }
                            })))).catch((() => {
                                e.querySelector(".my-form__is").disabled = !1
                            }))
                        }
                        s.forEach((e => {
                            e.disabled = !0
                        }));
                        let t = null,
                            n = new r.Z(null, (() => {
                                n = null, c = null, s.forEach((e => {
                                    e.disabled = !1
                                }))
                            })),
                            c = document.getElementById("template-form-login").content.querySelector(".form-login").cloneNode(!0);
                        c.addEventListener("submit", (function(s) {
                            s.preventDefault(), this.querySelector(".my-form__is").disabled = !0, null !== t ? (0, o.Z)(t, (t => {
                                this.reCaptcha.value = t, e(this)
                            })) : e(this)
                        })), c.querySelector(".is-btn-forgot-password").addEventListener("click", (function() {
                            let e = null;
                            c.email.checkValidity() && (e = c.email.value), n.close(), (0, l.Z)(e)
                        })), c.querySelector(".is-btn-signup").addEventListener("click", (function() {
                            n.close(), document.querySelector(".is-btn-signup").dispatchEvent(new Event("click"))
                        })), n.insertContent(c), (0, i.Z)((e => {
                            t = e, null !== t && (c.querySelector(".recaptcha-info").hidden = !1), n.open(), this.blur()
                        }))
                    }))
                })), -1 !== location.search.indexOf("login") && document.querySelector(".is-btn-login").dispatchEvent(new Event("click"))) : document.querySelectorAll(".is-btn-login").forEach((e => {
                    e.addEventListener("click", (function() {
                        location.href = document.querySelector(".is-lk-go-cabinet").href
                    }))
                }))
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            });
            var o = s(9152),
                r = s(8757),
                i = s(8814),
                l = s(5086),
                a = s(9023)
        },
        5086: function(e, t, s) {
            function n(e, t) {
                function s(e) {
                    function s() {
                        this.parentNode.classList.remove("error"), this.classList.remove("error"), this.classList.remove("has-listener"), this.removeEventListener("input", s)
                    }
                    let n = "";
                    "string" == typeof t && (n = "?token=" + t), fetch(e.action + n, {
                        method: "post",
                        credentials: "same-origin",
                        body: new FormData(e)
                    }).then((n => n.json().then((n => {
                        "string" == typeof t && (e.password.classList.contains("has-listener") || (e.password.classList.add("has-listener"), e.password.addEventListener("input", s))), null !== n && ("success" === n.status ? (l.close(), function(e) {
                            let t = new o.Z,
                                s = document.createElement("div");
                            s.classList.add("my-popup__msg-tx"), s.textContent = e, t.insertContent(s), t.open(), s = null, t = null
                        }(n.message)) : "error" === n.status && (e.querySelector(".form-password-reset__error-msg").textContent = n.message.system || n.message, e.querySelector(".form-password-reset__error-msg").hidden = !1, "string" == typeof t && (e.password.parentNode.classList.add("error"), e.password.classList.add("error")))), e.querySelector(".my-form__is").disabled = !1, n = null
                    })))).catch((() => {
                        e.querySelector(".my-form__is").disabled = !1
                    }))
                }
                let n = null,
                    l = new o.Z(null, (() => {
                        l = null, a = null
                    })),
                    a = document.getElementById("template-reset-password").content.querySelector(".form-password-reset").cloneNode(!0);
                null !== e && (a.email.value = e), a.addEventListener("submit", (function(e) {
                    e.preventDefault(), this.querySelector(".my-form__is").disabled = !0, null !== n ? (0, i.Z)(n, (e => {
                        this.reCaptcha.value = e, s(this)
                    })) : s(this)
                })), a.querySelector(".is-btn-login").addEventListener("click", (function() {
                    l.close(), document.querySelector(".is-btn-login").dispatchEvent(new Event("click"))
                })), l.insertContent(a), (0, r.Z)((function(e) {
                    n = e, null !== n && (a.querySelector(".recaptcha-info").hidden = !1), "string" == typeof t && (a.email.parentNode.classList.add("hide"), a.email.disabled = !0, a.password.parentNode.classList.remove("hide"), a.password.disabled = !1), l.open()
                }))
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            });
            var o = s(8757),
                r = s(8814),
                i = s(9152)
        },
        6199: function(e, t, s) {
            function n() {
                if (null !== document.getElementById("template-form-login")) {
                    let e = innerWidth;
                    ! function() {
                        let e = document.getElementById("template-form-signup").content.querySelector(".form-signup");
                        null !== e.querySelector("#form-signup-has-phone") && (window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                            event: "popup-send-code",
                            "gtm-event-category": "Funnel - Send code",
                            "gtm-event-action": "Page view"
                        })), window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                            event: "contact-form",
                            "form-event-category": "Reg form " + e.dataset.id,
                            "form-event-action": "Page view"
                        }), e = null
                    }(), document.querySelectorAll(".is-btn-signup").forEach(((e, t, s) => {
                        e.addEventListener("click", (function() {
                            function e() {
                                this.parentNode.classList.remove("error"), this.classList.remove("error"), this.classList.remove("has-listener"), this.removeEventListener("input", e)
                            }

                            function t(t) {
                                fetch(t.action, {
                                    method: "post",
                                    credentials: "same-origin",
                                    body: new FormData(t)
                                }).then((s => s.json().then((s => {
                                    let n = [t.email, t.password, t.passwordRepeat, t.skype, t.whatsapp, t.telegram];
                                    if (n.forEach((t => {
                                            void 0 === t || t.classList.contains("has-listener") || (t.classList.add("has-listener"), t.addEventListener("input", e))
                                        })), n = null, null !== s) {
                                        if ("error" === s.status) {
                                            if ("string" == typeof s.message || void 0 !== s.message.system) {
                                                let e = t.querySelector(".form-signup__error-msg");
                                                e.textContent = s.message.system || s.message, e.classList.remove("success"), e.hidden = !1, e = null
                                            } else Object.keys(s.message).forEach((e => {
                                                "reCaptcha" === e ? (t.querySelector(".form-signup__error-msg").textContent = s.message[e], t.querySelector(".form-signup__error-msg").hidden = !1) : "termsAndPrivacy" === e ? (t[e].parentNode.classList.add("error"), t[e].classList.add("error")) : (t[e].nextElementSibling.textContent = s.message[e], t[e].parentNode.classList.add("error"), t[e].classList.add("error"))
                                            }));
                                            t.querySelector(".my-form__is").disabled = !1
                                        }
                                        if ("success" === s.status) {
                                            g.close(), void 0 !== s.userActivationEmail && (0, c.Z)(s.message);
                                            let e = "Publisher";
                                            "adv" === t.querySelector(".is-change-type:checked").value && (e = "Advertiser");
                                            let n = {
                                                event: "successful-registration-" + e.toLowerCase(),
                                                "gtm-event-category": "Funnel",
                                                "gtm-event-action": "Successful registration - " + e
                                            };
                                            window.dataLayer = window.dataLayer || [], window.dataLayer.push(n), n = null, t = null
                                        }
                                        s = null
                                    }
                                })))).catch((() => {
                                    t.querySelector(".my-form__is").disabled = !1
                                }))
                            }

                            function n() {
                                this.disabled = !0;
                                let e = {};
                                e[document.getElementById("csrf-token").name] = document.getElementById("csrf-token").value, e.phone = y.phone.value;
                                let t = new FormData;
                                Object.keys(e).forEach((s => {
                                    t.append(s, e[s])
                                })), window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                                    event: "popup-send-code",
                                    "gtm-event-category": "Funnel - Send code",
                                    "gtm-event-action": "Button click"
                                }), fetch("/validate-phone", {
                                    method: "post",
                                    credentials: "same-origin",
                                    body: t
                                }).then((e => e.json().then((e => {
                                    if ("error" === e.status)
                                        if (void 0 !== e.message.phone) {
                                            let t = y.phone;
                                            t.nextElementSibling.textContent = e.message.phone, t.parentNode.classList.add("error"), t.classList.add("error"), t = null
                                        } else {
                                            let t = y.querySelector(".form-signup__error-msg");
                                            t.textContent = e.message.system || e.message, t.classList.remove("success"), t.hidden = !1, t = null
                                        }
                                    if ("success" === e.status) {
                                        let t = y.querySelector(".form-signup__error-msg");
                                        t.classList.add("success"), t.textContent = e.message, t.hidden = !1, t = null, this.classList.contains("form-signup__btn-send-code") && (window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                                            event: "popup-send-code",
                                            "gtm-event-category": "Funnel - Send code",
                                            "gtm-event-action": "Send code"
                                        }), y.querySelector(".form-signup__w-phone").classList.add("hide"), y.querySelector(".form-signup__w-code").classList.remove("hide"))
                                    }
                                    void 0 !== e.seconds ? (clearTimeout(u), u = setTimeout((() => {
                                        this.disabled = !1
                                    }), 1e3 * parseInt(e.seconds, 10))) : this.disabled = !1, e = null
                                })))).catch((() => {
                                    this.disabled = !1
                                })), t = null, e = null
                            }

                            function i() {
                                let e = y.querySelector(".form-signup__btn-send-code"),
                                    t = y.querySelector(".form-signup__btn-resend-code");
                                this.checkValidity() ? (e.addEventListener("click", n), t.addEventListener("click", n), e.disabled = !1) : (e.removeEventListener("click", n), t.removeEventListener("click", n), e.disabled = !0), e = null, t = null
                            }

                            function d() {
                                let e = !0;
                                Array.from(y.querySelectorAll(".my-form__control")).some((t => {
                                    if (!t.checkValidity()) return e = !1, !0
                                })), y.querySelector(".my-form__is").disabled = !e
                            }
                            let u;
                            s.forEach((e => {
                                e.disabled = !0
                            }));
                            let m = null,
                                p = null,
                                h = !1,
                                f = !0,
                                y = document.getElementById("template-form-signup").content.querySelector(".form-signup").cloneNode(!0);
                            null !== y.querySelector(".not-password") && (f = !1), y.classList.contains("type-2") && (h = !0, p = "is-signup-type-2");
                            let g = new l.Z(p, (() => {
                                clearTimeout(u), g = null, y = null, s.forEach((e => {
                                    e.disabled = !1
                                }))
                            }));
                            y.querySelectorAll(".is-change-type").forEach((e => {
                                e.addEventListener("change", (function() {
                                    let e = y.querySelector(".form-signup__chose-type-slider"),
                                        t = y.querySelector(".form-signup__chose-type-lbl." + this.dataset.type),
                                        s = y.querySelector(".form-signup__type-tx");
                                    e.style.setProperty("transform", "translateX(" + t.offsetLeft + "px)"), e.style.setProperty("width", t.offsetWidth + "px"), y.querySelectorAll(".form-signup__chose-type-lbl").forEach((e => {
                                        e.classList.remove("active")
                                    })), t.classList.add("active"), s.textContent = JSON.parse(s.dataset.text)[this.dataset.type], s = null, e = null, t = null
                                }))
                            })), (this.classList.contains("pub") || -1 !== location.search.indexOf("pub")) && (y.querySelector(".is-change-type.i-2").checked = !0), f && y.querySelector(".is-sel-msg").addEventListener("change", (function() {
                                let e = y.querySelector(".is-it-msg"),
                                    t = JSON.parse(e.dataset.attrs.replace(/'/g, '"').replace(/\\/g, "\\/"));
                                Object.keys(t).some((s => {
                                    if (this.value === s) return Object.keys(t[s]).forEach((n => {
                                        e.setAttribute(n, t[s][n].replace(/\//g, "\\"))
                                    })), !0
                                })), e = null, t = null
                            })), y.termsAndPrivacy.addEventListener("change", (function() {
                                this.parentNode.classList.remove("error"), this.classList.remove("error")
                            })), y.addEventListener("submit", (function(s) {
                                s.preventDefault(), this.querySelector(".my-form__is").disabled = !0, f && this.password.value !== this.passwordRepeat.value ? (this.passwordRepeat.parentNode.classList.add("error"), this.passwordRepeat.classList.add("error"), this.passwordRepeat.focus(), this.passwordRepeat.classList.contains("has-listener") || (this.passwordRepeat.classList.add("has-listener"), this.passwordRepeat.addEventListener("input", e)), this.querySelector(".my-form__is").disabled = !1) : null !== m ? (0, r.Z)(m, (e => {
                                    this.reCaptcha.value = e, t(this)
                                })) : t(this)
                            })), y.querySelector(".is-btn-login").addEventListener("click", (function() {
                                g.close(), document.querySelector(".is-btn-login").dispatchEvent(new Event("click"))
                            })), null !== y.querySelector("#form-signup-has-phone") && ([y.phone, y.code].forEach((e => {
                                e.addEventListener("input", (function() {
                                    this.parentNode.classList.remove("error"), this.classList.remove("error")
                                }))
                            })), y.phone.addEventListener("change", i), y.phone.addEventListener("input", i), y.querySelectorAll(".my-form__control").forEach((e => {
                                e.addEventListener("input", d), e.addEventListener("change", d)
                            }))), g.insertContent(y), (0, a.Z)((e => {
                                if (m = e, null !== m && (y.querySelector(".recaptcha-info").hidden = !1), g.open(), this.blur(), y.querySelector(".is-change-type:checked").dispatchEvent(new Event("change")), h) {
                                    let e = document.createDocumentFragment();
                                    y.querySelectorAll(".glide__slide").forEach(((s, n) => {
                                        let o = document.createElement("div");
                                        o.addEventListener("click", (function() {
                                            t.go(this.dataset.goTo)
                                        })), o.classList.add("glide__bullet"), o.dataset.goTo = "=" + n, 0 === n && o.classList.add("glide__bullet--active"), e.appendChild(o), o = null
                                    })), y.querySelector(".glide__bullets").appendChild(e), e = null;
                                    let t = new o.ZP(y.querySelector(".glide"), {
                                        type: "carousel",
                                        animationTimingFunc: "ease",
                                        animationDuration: matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 600,
                                        gap: 0
                                    }).on("run", (function() {
                                        y.querySelectorAll(".glide__bullet").forEach((e => {
                                            e.classList.remove("glide__bullet--active")
                                        })), y.querySelector(".glide__bullets").children[t._i].classList.add("glide__bullet--active")
                                    })).mount({
                                        Swipe: o.oF
                                    })
                                }
                                window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                                    event: "contact-form",
                                    "form-event-category": "Reg form " + y.dataset.id,
                                    "form-event-action": "Form opened"
                                })
                            }))
                        }))
                    })), (0, i.Z)((t => {
                        e !== t && (e = t, null !== document.querySelector(".form-signup") && document.querySelector(".is-change-type:checked").dispatchEvent(new Event("change")))
                    })), -1 === location.search.indexOf("signup") && -1 === location.search.indexOf("phoneconfirm") || document.querySelector(".is-btn-signup").dispatchEvent(new Event("click"))
                } else document.querySelectorAll(".is-btn-signup").forEach((e => {
                    e.addEventListener("click", (function() {
                        location.href = document.querySelector(".is-lk-go-cabinet").href
                    }))
                }))
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            });
            var o = s(7977),
                r = s(9152),
                i = s(4544),
                l = s(8757),
                a = s(8814),
                c = s(9023)
        },
        9023: function(e, t, s) {
            function n(e) {
                let t, s = new o.Z("msg-email-activate__popup", (() => {
                        void 0 !== t && clearTimeout(t), s = null
                    })),
                    n = document.getElementById("template-msg-email-activate").content.querySelector(".msg-email-activate").cloneNode(!0),
                    r = document.getElementById("template-form-signup").content.querySelector(".form-signup");
                "1" === r.dataset.id || "3" === r.dataset.id ? n.querySelector(".msg-email-activate__w-tx.is-short").hidden = !1 : n.querySelector(".msg-email-activate__w-tx.is-full").hidden = !1, n.querySelector(".msg-email-activate__tx.response").innerHTML = e, n.querySelectorAll(".is-btn-resend").forEach((e => {
                    e.addEventListener("click", (function() {
                        this.disabled = !0, void 0 !== t && clearTimeout(t);
                        let e = new FormData;
                        e.set(document.getElementById("csrf-token").name, document.getElementById("csrf-token").value), fetch("/site/resend", {
                            method: "post",
                            credentials: "same-origin",
                            body: e
                        }).then((e => e.json().then((e => {
                            if (null !== e) {
                                let s = n.querySelector(".msg-email-activate__msg-info");
                                s.textContent = e.message, "success" === e.status ? (s.classList.remove("error"), s.classList.add("success")) : (s.classList.remove("success"), s.classList.add("error")), s.hidden = !1, t = setTimeout((() => {
                                    s.hidden = !0, s = null
                                }), 4e3)
                            }
                            this.disabled = !1, e = null
                        })))).catch((() => {
                            this.disabled = !1
                        })), e = null
                    }))
                })), s.insertContent(n), s.open()
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            });
            var o = s(8757)
        },
        8757: function(e, t, s) {
            function n(e, t) {
                this.template = document.getElementById("template-popup").content.querySelector(".my-popup").cloneNode(!0), this.open = function() {
                    document.addEventListener("keydown", this.closeEsc), document.body.classList.add("no-scroll"), null !== e && this.template.classList.add(e), document.body.appendChild(this.template), this.template.classList.add("open")
                }, this.closeEsc = e => {
                    27 === e.keyCode && this.close()
                }, this.close = function() {
                    if (document.body.classList.contains("mobile-menu-open") || document.body.classList.remove("no-scroll"), document.removeEventListener("keydown", this.closeEsc), this.template.classList.remove("open"), document.body.removeChild(this.template), this.template = null, void 0 !== t) return t()
                }, this.insertContent = function(e) {
                    this.template.querySelector(".my-popup__cnt").appendChild(e)
                }, this.template.querySelectorAll(".my-popup__bg, .my-popup__btn-close").forEach((e => {
                    e.addEventListener("click", (() => {
                        this.close()
                    }))
                }))
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            })
        },
        8814: function(e, t, s) {
            function n(e) {
                let t = document.getElementById("re-captcha");
                if (null === t) return e(null);
                if (t.classList.contains("ready")) return e(t.value); {
                    let s = document.createElement("script");
                    s.async = !0, s.addEventListener("load", (function s() {
                        return t.classList.add("ready"), this.removeEventListener("load", s), e(t.value)
                    })), s.src = "https://www.google.com/recaptcha/api.js?render=" + t.value, document.body.appendChild(s), s = null
                }
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            })
        },
        9152: function(e, t, s) {
            function n(e, t) {
                grecaptcha.ready((() => grecaptcha.execute(e, {
                    action: "submit"
                }).then((e => t(e)))))
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            })
        },
        5097: function(e, t, s) {
            function n() {
                document.getElementById("my-loading").classList.add("hide"), document.body.classList.remove("no-scroll")
            }
            s.d(t, {
                Z: function() {
                    return n
                }
            })
        }
    }
]);