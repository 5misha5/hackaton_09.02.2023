var J = Object.defineProperty,
    Q = Object.defineProperties;
var X = Object.getOwnPropertyDescriptors;
var I = Object.getOwnPropertySymbols;
var Y = Object.prototype.hasOwnProperty,
    k = Object.prototype.propertyIsEnumerable;
var A = (e, l, i) => l in e ? J(e, l, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: i
    }) : e[l] = i,
    R = (e, l) => {
        for (var i in l || (l = {})) Y.call(l, i) && A(e, i, l[i]);
        if (I)
            for (var i of I(l)) k.call(l, i) && A(e, i, l[i]);
        return e
    },
    D = (e, l) => Q(e, X(l));
import {
    S as T
} from "./core.c3b10569.js";
import {
    h,
    r as S,
    o as L,
    p as $,
    w as ee,
    n as ne,
    a as G,
    b as F,
    c as te,
    d as le,
    i as V
} from "./app.7a8f50c0.js";

function E(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function m(e, l) {
    const i = ["__proto__", "constructor", "prototype"];
    Object.keys(l).filter(t => i.indexOf(t) < 0).forEach(t => {
        typeof e[t] == "undefined" ? e[t] = l[t] : E(l[t]) && E(e[t]) && Object.keys(l[t]).length > 0 ? l[t].__swiper__ ? e[t] = l[t] : m(e[t], l[t]) : e[t] = l[t]
    })
}

function W(e) {
    return e === void 0 && (e = {}), e.navigation && typeof e.navigation.nextEl == "undefined" && typeof e.navigation.prevEl == "undefined"
}

function H(e) {
    return e === void 0 && (e = {}), e.pagination && typeof e.pagination.el == "undefined"
}

function U(e) {
    return e === void 0 && (e = {}), e.scrollbar && typeof e.scrollbar.el == "undefined"
}

function q(e) {
    e === void 0 && (e = "");
    const l = e.split(" ").map(t => t.trim()).filter(t => !!t),
        i = [];
    return l.forEach(t => {
        i.indexOf(t) < 0 && i.push(t)
    }), i.join(" ")
}
const K = ["modules", "init", "_direction", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_preloadImages", "updateOnImagesReady", "_loop", "_loopAdditionalSlides", "_loopedSlides", "_loopedSlidesLimit", "_loopFillGroupWithBlank", "loopPreventsSlide", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideBlankClass", "slideActiveClass", "slideDuplicateActiveClass", "slideVisibleClass", "slideDuplicateClass", "slideNextClass", "slideDuplicateNextClass", "slidePrevClass", "slideDuplicatePrevClass", "wrapperClass", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "lazy", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom"];

function M(e, l) {
    e === void 0 && (e = {}), l === void 0 && (l = !0);
    const i = {
            on: {}
        },
        t = {},
        a = {};
    m(i, T.defaults), m(i, T.extendedDefaults), i._emitClasses = !0, i.init = !1;
    const s = {},
        d = K.map(n => n.replace(/_/, "")),
        u = Object.assign({}, e);
    return Object.keys(u).forEach(n => {
        typeof e[n] != "undefined" && (d.indexOf(n) >= 0 ? E(e[n]) ? (i[n] = {}, a[n] = {}, m(i[n], e[n]), m(a[n], e[n])) : (i[n] = e[n], a[n] = e[n]) : n.search(/on[A-Z]/) === 0 && typeof e[n] == "function" ? l ? t[`${n[2].toLowerCase()}${n.substr(3)}`] = e[n] : i.on[`${n[2].toLowerCase()}${n.substr(3)}`] = e[n] : s[n] = e[n])
    }), ["navigation", "pagination", "scrollbar"].forEach(n => {
        i[n] === !0 && (i[n] = {}), i[n] === !1 && delete i[n]
    }), {
        params: i,
        passedParams: a,
        rest: s,
        events: t
    }
}

function ie(e, l) {
    let {
        el: i,
        nextEl: t,
        prevEl: a,
        paginationEl: s,
        scrollbarEl: d,
        swiper: u
    } = e;
    W(l) && t && a && (u.params.navigation.nextEl = t, u.originalParams.navigation.nextEl = t, u.params.navigation.prevEl = a, u.originalParams.navigation.prevEl = a), H(l) && s && (u.params.pagination.el = s, u.originalParams.pagination.el = s), U(l) && d && (u.params.scrollbar.el = d, u.originalParams.scrollbar.el = d), u.init(i)
}

function Z(e, l) {
    let i = l.slidesPerView;
    if (l.breakpoints) {
        const a = T.prototype.getBreakpoint(l.breakpoints),
            s = a in l.breakpoints ? l.breakpoints[a] : void 0;
        s && s.slidesPerView && (i = s.slidesPerView)
    }
    let t = Math.ceil(parseFloat(l.loopedSlides || i, 10));
    return t += l.loopAdditionalSlides, t > e.length && l.loopedSlidesLimit && (t = e.length), t
}

function ae(e, l, i) {
    const t = l.map((n, p) => (n.props || (n.props = {}), n.props.swiperRef = e, n.props["data-swiper-slide-index"] = p, n));

    function a(n, p, r) {
        return n.props || (n.props = {}), h(n.type, D(R({}, n.props), {
            key: `${n.key}-duplicate-${p}-${r}`,
            class: `${n.props.className||""} ${i.slideDuplicateClass} ${n.props.class||""}`
        }), n.children)
    }
    if (i.loopFillGroupWithBlank) {
        const n = i.slidesPerGroup - t.length % i.slidesPerGroup;
        if (n !== i.slidesPerGroup)
            for (let p = 0; p < n; p += 1) {
                const r = h("div", {
                    class: `${i.slideClass} ${i.slideBlankClass}`
                });
                t.push(r)
            }
    }
    i.slidesPerView === "auto" && !i.loopedSlides && (i.loopedSlides = t.length);
    const s = Z(t, i),
        d = [],
        u = [];
    for (let n = 0; n < s; n += 1) {
        const p = n - Math.floor(n / t.length) * t.length;
        u.push(a(t[p], n, "append")), d.unshift(a(t[t.length - p - 1], n, "prepend"))
    }
    return e.value && (e.value.loopedSlides = s), [...d, ...t, ...u]
}

function de(e, l, i, t, a) {
    const s = [];
    if (!l) return s;
    const d = n => {
        s.indexOf(n) < 0 && s.push(n)
    };
    if (i && t) {
        const n = t.map(a),
            p = i.map(a);
        n.join("") !== p.join("") && d("children"), t.length !== i.length && d("children")
    }
    return K.filter(n => n[0] === "_").map(n => n.replace(/_/, "")).forEach(n => {
        if (n in e && n in l)
            if (E(e[n]) && E(l[n])) {
                const p = Object.keys(e[n]),
                    r = Object.keys(l[n]);
                p.length !== r.length ? d(n) : (p.forEach(o => {
                    e[n][o] !== l[n][o] && d(n)
                }), r.forEach(o => {
                    e[n][o] !== l[n][o] && d(n)
                }))
            } else e[n] !== l[n] && d(n)
    }), s
}

function j(e, l, i) {
    e === void 0 && (e = {});
    const t = [],
        a = {
            "container-start": [],
            "container-end": [],
            "wrapper-start": [],
            "wrapper-end": []
        },
        s = (d, u) => {
            !Array.isArray(d) || d.forEach(n => {
                const p = typeof n.type == "symbol";
                u === "default" && (u = "container-end"), p && n.children ? s(n.children, "default") : n.type && (n.type.name === "SwiperSlide" || n.type.name === "AsyncComponentWrapper") ? t.push(n) : a[u] && a[u].push(n)
            })
        };
    return Object.keys(e).forEach(d => {
        if (typeof e[d] != "function") return;
        const u = e[d]();
        s(u, d)
    }), i.value = l.value, l.value = t, {
        slides: t,
        slots: a
    }
}

function oe(e) {
    let {
        swiper: l,
        slides: i,
        passedParams: t,
        changedParams: a,
        nextEl: s,
        prevEl: d,
        scrollbarEl: u,
        paginationEl: n
    } = e;
    const p = a.filter(f => f !== "children" && f !== "direction"),
        {
            params: r,
            pagination: o,
            navigation: y,
            scrollbar: g,
            virtual: w,
            thumbs: C
        } = l;
    let x, B, O, b, P;
    a.includes("thumbs") && t.thumbs && t.thumbs.swiper && r.thumbs && !r.thumbs.swiper && (x = !0), a.includes("controller") && t.controller && t.controller.control && r.controller && !r.controller.control && (B = !0), a.includes("pagination") && t.pagination && (t.pagination.el || n) && (r.pagination || r.pagination === !1) && o && !o.el && (O = !0), a.includes("scrollbar") && t.scrollbar && (t.scrollbar.el || u) && (r.scrollbar || r.scrollbar === !1) && g && !g.el && (b = !0), a.includes("navigation") && t.navigation && (t.navigation.prevEl || d) && (t.navigation.nextEl || s) && (r.navigation || r.navigation === !1) && y && !y.prevEl && !y.nextEl && (P = !0);
    const z = f => {
        !l[f] || (l[f].destroy(), f === "navigation" ? (r[f].prevEl = void 0, r[f].nextEl = void 0, l[f].prevEl = void 0, l[f].nextEl = void 0) : (r[f].el = void 0, l[f].el = void 0))
    };
    p.forEach(f => {
        if (E(r[f]) && E(t[f])) m(r[f], t[f]);
        else {
            const c = t[f];
            (c === !0 || c === !1) && (f === "navigation" || f === "pagination" || f === "scrollbar") ? c === !1 && z(f): r[f] = t[f]
        }
    }), p.includes("controller") && !B && l.controller && l.controller.control && r.controller && r.controller.control && (l.controller.control = r.controller.control), a.includes("children") && i && w && r.virtual.enabled ? (w.slides = i, w.update(!0)) : a.includes("children") && l.lazy && l.params.lazy.enabled && l.lazy.load(), x && C.init() && C.update(!0), B && (l.controller.control = r.controller.control), O && (n && (r.pagination.el = n), o.init(), o.render(), o.update()), b && (u && (r.scrollbar.el = u), g.init(), g.updateSize(), g.setTranslate()), P && (s && (r.navigation.nextEl = s), d && (r.navigation.prevEl = d), y.init(), y.update()), a.includes("allowSlideNext") && (l.allowSlideNext = t.allowSlideNext), a.includes("allowSlidePrev") && (l.allowSlidePrev = t.allowSlidePrev), a.includes("direction") && l.changeDirection(t.direction, !1), l.update()
}

function re(e, l, i) {
    if (!i) return null;
    const t = e.value.isHorizontal() ? {
        [e.value.rtlTranslate ? "right" : "left"]: `${i.offset}px`
    } : {
        top: `${i.offset}px`
    };
    return l.filter((a, s) => s >= i.from && s <= i.to).map(a => (a.props || (a.props = {}), a.props.style || (a.props.style = {}), a.props.swiperRef = e, a.props.style = t, h(a.type, R({}, a.props), a.children)))
}
const se = e => {
        !e || e.destroyed || !e.params.virtual || e.params.virtual && !e.params.virtual.enabled || (e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.lazy && e.params.lazy.enabled && e.lazy.load(), e.parallax && e.params.parallax && e.params.parallax.enabled && e.parallax.setTranslate())
    },
    ce = {
        name: "Swiper",
        props: {
            tag: {
                type: String,
                default: "div"
            },
            wrapperTag: {
                type: String,
                default: "div"
            },
            modules: {
                type: Array,
                default: void 0
            },
            init: {
                type: Boolean,
                default: void 0
            },
            direction: {
                type: String,
                default: void 0
            },
            touchEventsTarget: {
                type: String,
                default: void 0
            },
            initialSlide: {
                type: Number,
                default: void 0
            },
            speed: {
                type: Number,
                default: void 0
            },
            cssMode: {
                type: Boolean,
                default: void 0
            },
            updateOnWindowResize: {
                type: Boolean,
                default: void 0
            },
            resizeObserver: {
                type: Boolean,
                default: void 0
            },
            nested: {
                type: Boolean,
                default: void 0
            },
            focusableElements: {
                type: String,
                default: void 0
            },
            width: {
                type: Number,
                default: void 0
            },
            height: {
                type: Number,
                default: void 0
            },
            preventInteractionOnTransition: {
                type: Boolean,
                default: void 0
            },
            userAgent: {
                type: String,
                default: void 0
            },
            url: {
                type: String,
                default: void 0
            },
            edgeSwipeDetection: {
                type: [Boolean, String],
                default: void 0
            },
            edgeSwipeThreshold: {
                type: Number,
                default: void 0
            },
            autoHeight: {
                type: Boolean,
                default: void 0
            },
            setWrapperSize: {
                type: Boolean,
                default: void 0
            },
            virtualTranslate: {
                type: Boolean,
                default: void 0
            },
            effect: {
                type: String,
                default: void 0
            },
            breakpoints: {
                type: Object,
                default: void 0
            },
            spaceBetween: {
                type: Number,
                default: void 0
            },
            slidesPerView: {
                type: [Number, String],
                default: void 0
            },
            maxBackfaceHiddenSlides: {
                type: Number,
                default: void 0
            },
            slidesPerGroup: {
                type: Number,
                default: void 0
            },
            slidesPerGroupSkip: {
                type: Number,
                default: void 0
            },
            slidesPerGroupAuto: {
                type: Boolean,
                default: void 0
            },
            centeredSlides: {
                type: Boolean,
                default: void 0
            },
            centeredSlidesBounds: {
                type: Boolean,
                default: void 0
            },
            slidesOffsetBefore: {
                type: Number,
                default: void 0
            },
            slidesOffsetAfter: {
                type: Number,
                default: void 0
            },
            normalizeSlideIndex: {
                type: Boolean,
                default: void 0
            },
            centerInsufficientSlides: {
                type: Boolean,
                default: void 0
            },
            watchOverflow: {
                type: Boolean,
                default: void 0
            },
            roundLengths: {
                type: Boolean,
                default: void 0
            },
            touchRatio: {
                type: Number,
                default: void 0
            },
            touchAngle: {
                type: Number,
                default: void 0
            },
            simulateTouch: {
                type: Boolean,
                default: void 0
            },
            shortSwipes: {
                type: Boolean,
                default: void 0
            },
            longSwipes: {
                type: Boolean,
                default: void 0
            },
            longSwipesRatio: {
                type: Number,
                default: void 0
            },
            longSwipesMs: {
                type: Number,
                default: void 0
            },
            followFinger: {
                type: Boolean,
                default: void 0
            },
            allowTouchMove: {
                type: Boolean,
                default: void 0
            },
            threshold: {
                type: Number,
                default: void 0
            },
            touchMoveStopPropagation: {
                type: Boolean,
                default: void 0
            },
            touchStartPreventDefault: {
                type: Boolean,
                default: void 0
            },
            touchStartForcePreventDefault: {
                type: Boolean,
                default: void 0
            },
            touchReleaseOnEdges: {
                type: Boolean,
                default: void 0
            },
            uniqueNavElements: {
                type: Boolean,
                default: void 0
            },
            resistance: {
                type: Boolean,
                default: void 0
            },
            resistanceRatio: {
                type: Number,
                default: void 0
            },
            watchSlidesProgress: {
                type: Boolean,
                default: void 0
            },
            grabCursor: {
                type: Boolean,
                default: void 0
            },
            preventClicks: {
                type: Boolean,
                default: void 0
            },
            preventClicksPropagation: {
                type: Boolean,
                default: void 0
            },
            slideToClickedSlide: {
                type: Boolean,
                default: void 0
            },
            preloadImages: {
                type: Boolean,
                default: void 0
            },
            updateOnImagesReady: {
                type: Boolean,
                default: void 0
            },
            loop: {
                type: Boolean,
                default: void 0
            },
            loopAdditionalSlides: {
                type: Number,
                default: void 0
            },
            loopedSlides: {
                type: Number,
                default: void 0
            },
            loopedSlidesLimit: {
                type: Boolean,
                default: !0
            },
            loopFillGroupWithBlank: {
                type: Boolean,
                default: void 0
            },
            loopPreventsSlide: {
                type: Boolean,
                default: void 0
            },
            rewind: {
                type: Boolean,
                default: void 0
            },
            allowSlidePrev: {
                type: Boolean,
                default: void 0
            },
            allowSlideNext: {
                type: Boolean,
                default: void 0
            },
            swipeHandler: {
                type: Boolean,
                default: void 0
            },
            noSwiping: {
                type: Boolean,
                default: void 0
            },
            noSwipingClass: {
                type: String,
                default: void 0
            },
            noSwipingSelector: {
                type: String,
                default: void 0
            },
            passiveListeners: {
                type: Boolean,
                default: void 0
            },
            containerModifierClass: {
                type: String,
                default: void 0
            },
            slideClass: {
                type: String,
                default: void 0
            },
            slideBlankClass: {
                type: String,
                default: void 0
            },
            slideActiveClass: {
                type: String,
                default: void 0
            },
            slideDuplicateActiveClass: {
                type: String,
                default: void 0
            },
            slideVisibleClass: {
                type: String,
                default: void 0
            },
            slideDuplicateClass: {
                type: String,
                default: void 0
            },
            slideNextClass: {
                type: String,
                default: void 0
            },
            slideDuplicateNextClass: {
                type: String,
                default: void 0
            },
            slidePrevClass: {
                type: String,
                default: void 0
            },
            slideDuplicatePrevClass: {
                type: String,
                default: void 0
            },
            wrapperClass: {
                type: String,
                default: void 0
            },
            runCallbacksOnInit: {
                type: Boolean,
                default: void 0
            },
            observer: {
                type: Boolean,
                default: void 0
            },
            observeParents: {
                type: Boolean,
                default: void 0
            },
            observeSlideChildren: {
                type: Boolean,
                default: void 0
            },
            a11y: {
                type: [Boolean, Object],
                default: void 0
            },
            autoplay: {
                type: [Boolean, Object],
                default: void 0
            },
            controller: {
                type: Object,
                default: void 0
            },
            coverflowEffect: {
                type: Object,
                default: void 0
            },
            cubeEffect: {
                type: Object,
                default: void 0
            },
            fadeEffect: {
                type: Object,
                default: void 0
            },
            flipEffect: {
                type: Object,
                default: void 0
            },
            creativeEffect: {
                type: Object,
                default: void 0
            },
            cardsEffect: {
                type: Object,
                default: void 0
            },
            hashNavigation: {
                type: [Boolean, Object],
                default: void 0
            },
            history: {
                type: [Boolean, Object],
                default: void 0
            },
            keyboard: {
                type: [Boolean, Object],
                default: void 0
            },
            lazy: {
                type: [Boolean, Object],
                default: void 0
            },
            mousewheel: {
                type: [Boolean, Object],
                default: void 0
            },
            navigation: {
                type: [Boolean, Object],
                default: void 0
            },
            pagination: {
                type: [Boolean, Object],
                default: void 0
            },
            parallax: {
                type: [Boolean, Object],
                default: void 0
            },
            scrollbar: {
                type: [Boolean, Object],
                default: void 0
            },
            thumbs: {
                type: Object,
                default: void 0
            },
            virtual: {
                type: [Boolean, Object],
                default: void 0
            },
            zoom: {
                type: [Boolean, Object],
                default: void 0
            },
            grid: {
                type: [Object],
                default: void 0
            },
            freeMode: {
                type: [Boolean, Object],
                default: void 0
            },
            enabled: {
                type: Boolean,
                default: void 0
            }
        },
        emits: ["_beforeBreakpoint", "_containerClasses", "_slideClass", "_slideClasses", "_swiper", "_freeModeNoMomentumRelease", "activeIndexChange", "afterInit", "autoplay", "autoplayStart", "autoplayStop", "autoplayPause", "autoplayResume", "beforeDestroy", "beforeInit", "beforeLoopFix", "beforeResize", "beforeSlideChangeStart", "beforeTransitionStart", "breakpoint", "changeDirection", "click", "disable", "doubleTap", "doubleClick", "destroy", "enable", "fromEdge", "hashChange", "hashSet", "imagesReady", "init", "keyPress", "lazyImageLoad", "lazyImageReady", "lock", "loopFix", "momentumBounce", "navigationHide", "navigationShow", "navigationPrev", "navigationNext", "observerUpdate", "orientationchange", "paginationHide", "paginationRender", "paginationShow", "paginationUpdate", "progress", "reachBeginning", "reachEnd", "realIndexChange", "resize", "scroll", "scrollbarDragEnd", "scrollbarDragMove", "scrollbarDragStart", "setTransition", "setTranslate", "slideChange", "slideChangeTransitionEnd", "slideChangeTransitionStart", "slideNextTransitionEnd", "slideNextTransitionStart", "slidePrevTransitionEnd", "slidePrevTransitionStart", "slideResetTransitionStart", "slideResetTransitionEnd", "sliderMove", "sliderFirstMove", "slidesLengthChange", "slidesGridLengthChange", "snapGridLengthChange", "snapIndexChange", "swiper", "tap", "toEdge", "touchEnd", "touchMove", "touchMoveOpposite", "touchStart", "transitionEnd", "transitionStart", "unlock", "update", "virtualUpdate", "zoomChange"],
        setup(e, l) {
            let {
                slots: i,
                emit: t
            } = l;
            const {
                tag: a,
                wrapperTag: s
            } = e, d = S("swiper"), u = S(null), n = S(!1), p = S(!1), r = S(null), o = S(null), y = S(null), g = {
                value: []
            }, w = {
                value: []
            }, C = S(null), x = S(null), B = S(null), O = S(null), {
                params: b,
                passedParams: P
            } = M(e, !1);
            j(i, g, w), y.value = P, w.value = g.value;
            const z = () => {
                j(i, g, w), n.value = !0
            };
            if (b.onAny = function(c) {
                    for (var v = arguments.length, _ = new Array(v > 1 ? v - 1 : 0), N = 1; N < v; N++) _[N - 1] = arguments[N];
                    t(c, ..._)
                }, Object.assign(b.on, {
                    _beforeBreakpoint: z,
                    _containerClasses(c, v) {
                        d.value = v
                    }
                }), o.value = new T(b), o.value.loopCreate = () => {}, o.value.loopDestroy = () => {}, b.loop && (o.value.loopedSlides = Z(g.value, b)), o.value.virtual && o.value.params.virtual.enabled) {
                o.value.virtual.slides = g.value;
                const c = {
                    cache: !1,
                    slides: g.value,
                    renderExternal: v => {
                        u.value = v
                    },
                    renderExternalUpdate: !1
                };
                m(o.value.params.virtual, c), m(o.value.originalParams.virtual, c)
            }
            L(() => {
                !p.value && o.value && (o.value.emitSlidesClasses(), p.value = !0);
                const {
                    passedParams: c
                } = M(e, !1), v = de(c, y.value, g.value, w.value, _ => _.props && _.props.key);
                y.value = c, (v.length || n.value) && o.value && !o.value.destroyed && oe({
                    swiper: o.value,
                    slides: g.value,
                    passedParams: c,
                    changedParams: v,
                    nextEl: C.value,
                    prevEl: x.value,
                    scrollbarEl: O.value,
                    paginationEl: B.value
                }), n.value = !1
            }), $("swiper", o), ee(u, () => {
                ne(() => {
                    se(o.value)
                })
            }), G(() => {
                !r.value || (ie({
                    el: r.value,
                    nextEl: C.value,
                    prevEl: x.value,
                    paginationEl: B.value,
                    scrollbarEl: O.value,
                    swiper: o.value
                }, b), t("swiper", o.value))
            }), F(() => {
                o.value && !o.value.destroyed && o.value.destroy(!0, !1)
            });

            function f(c) {
                return b.virtual ? re(o, c, u.value) : !b.loop || o.value && o.value.destroyed ? (c.forEach(v => {
                    v.props || (v.props = {}), v.props.swiperRef = o
                }), c) : ae(o, c, b)
            }
            return () => {
                const {
                    slides: c,
                    slots: v
                } = j(i, g, w);
                return h(a, {
                    ref: r,
                    class: q(d.value)
                }, [v["container-start"], h(s, {
                    class: "swiper-wrapper"
                }, [v["wrapper-start"], f(c), v["wrapper-end"]]), W(e) && [h("div", {
                    ref: x,
                    class: "swiper-button-prev"
                }), h("div", {
                    ref: C,
                    class: "swiper-button-next"
                })], U(e) && h("div", {
                    ref: O,
                    class: "swiper-scrollbar"
                }), H(e) && h("div", {
                    ref: B,
                    class: "swiper-pagination"
                }), v["container-end"]])
            }
        }
    },
    ve = {
        name: "SwiperSlide",
        props: {
            tag: {
                type: String,
                default: "div"
            },
            swiperRef: {
                type: Object,
                required: !1
            },
            zoom: {
                type: Boolean,
                default: void 0
            },
            virtualIndex: {
                type: [String, Number],
                default: void 0
            }
        },
        setup(e, l) {
            let {
                slots: i
            } = l, t = !1;
            const {
                swiperRef: a
            } = e, s = S(null), d = S("swiper-slide");

            function u(p, r, o) {
                r === s.value && (d.value = o)
            }
            G(() => {
                !a.value || (a.value.on("_slideClass", u), t = !0)
            }), te(() => {
                t || !a || !a.value || (a.value.on("_slideClass", u), t = !0)
            }), L(() => {
                !s.value || !a || !a.value || a.value.destroyed && d.value !== "swiper-slide" && (d.value = "swiper-slide")
            }), F(() => {
                !a || !a.value || a.value.off("_slideClass", u)
            });
            const n = le(() => ({
                isActive: d.value.indexOf("swiper-slide-active") >= 0 || d.value.indexOf("swiper-slide-duplicate-active") >= 0,
                isVisible: d.value.indexOf("swiper-slide-visible") >= 0,
                isDuplicate: d.value.indexOf("swiper-slide-duplicate") >= 0,
                isPrev: d.value.indexOf("swiper-slide-prev") >= 0 || d.value.indexOf("swiper-slide-duplicate-prev") >= 0,
                isNext: d.value.indexOf("swiper-slide-next") >= 0 || d.value.indexOf("swiper-slide-duplicate-next") >= 0
            }));
            return $("swiperSlide", n), () => h(e.tag, {
                class: q(`${d.value}`),
                ref: s,
                "data-swiper-slide-index": e.virtualIndex
            }, e.zoom ? h("div", {
                class: "swiper-zoom-container",
                "data-swiper-zoom": typeof e.zoom == "number" ? e.zoom : void 0
            }, i.default && i.default(n.value)) : i.default && i.default(n.value))
        }
    },
    ge = () => V("swiperSlide"),
    Se = () => V("swiper");
export {
    ce as Swiper, ve as SwiperSlide, Se as useSwiper, ge as useSwiperSlide
};