function J(e) {
    return e !== null && typeof e == "object" && "constructor" in e && e.constructor === Object
}

function q(e = {}, t = {}) {
    Object.keys(t).forEach(i => {
        typeof e[i] == "undefined" ? e[i] = t[i] : J(t[i]) && J(e[i]) && Object.keys(t[i]).length > 0 && q(e[i], t[i])
    })
}
const se = {
    body: {},
    addEventListener() {},
    removeEventListener() {},
    activeElement: {
        blur() {},
        nodeName: ""
    },
    querySelector() {
        return null
    },
    querySelectorAll() {
        return []
    },
    getElementById() {
        return null
    },
    createEvent() {
        return {
            initEvent() {}
        }
    },
    createElement() {
        return {
            children: [],
            childNodes: [],
            style: {},
            setAttribute() {},
            getElementsByTagName() {
                return []
            }
        }
    },
    createElementNS() {
        return {}
    },
    importNode() {
        return null
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    }
};

function L() {
    const e = typeof document != "undefined" ? document : {};
    return q(e, se), e
}
const he = {
    document: se,
    navigator: {
        userAgent: ""
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    },
    history: {
        replaceState() {},
        pushState() {},
        go() {},
        back() {}
    },
    CustomEvent: function() {
        return this
    },
    addEventListener() {},
    removeEventListener() {},
    getComputedStyle() {
        return {
            getPropertyValue() {
                return ""
            }
        }
    },
    Image() {},
    Date() {},
    screen: {},
    setTimeout() {},
    clearTimeout() {},
    matchMedia() {
        return {}
    },
    requestAnimationFrame(e) {
        return typeof setTimeout == "undefined" ? (e(), null) : setTimeout(e, 0)
    },
    cancelAnimationFrame(e) {
        typeof setTimeout != "undefined" && clearTimeout(e)
    }
};

function C() {
    const e = typeof window != "undefined" ? window : {};
    return q(e, he), e
}

function me(e) {
    const t = e.__proto__;
    Object.defineProperty(e, "__proto__", {
        get() {
            return t
        },
        set(i) {
            t.__proto__ = i
        }
    })
}
class k extends Array {
    constructor(t) {
        if (typeof t == "number") super(t);
        else {
            super(...t || []);
            me(this)
        }
    }
}

function D(e = []) {
    const t = [];
    return e.forEach(i => {
        Array.isArray(i) ? t.push(...D(i)) : t.push(i)
    }), t
}

function ne(e, t) {
    return Array.prototype.filter.call(e, t)
}

function ge(e) {
    const t = [];
    for (let i = 0; i < e.length; i += 1) t.indexOf(e[i]) === -1 && t.push(e[i]);
    return t
}

function ve(e, t) {
    if (typeof e != "string") return [e];
    const i = [],
        s = t.querySelectorAll(e);
    for (let r = 0; r < s.length; r += 1) i.push(s[r]);
    return i
}

function p(e, t) {
    const i = C(),
        s = L();
    let r = [];
    if (!t && e instanceof k) return e;
    if (!e) return new k(r);
    if (typeof e == "string") {
        const n = e.trim();
        if (n.indexOf("<") >= 0 && n.indexOf(">") >= 0) {
            let a = "div";
            n.indexOf("<li") === 0 && (a = "ul"), n.indexOf("<tr") === 0 && (a = "tbody"), (n.indexOf("<td") === 0 || n.indexOf("<th") === 0) && (a = "tr"), n.indexOf("<tbody") === 0 && (a = "table"), n.indexOf("<option") === 0 && (a = "select");
            const l = s.createElement(a);
            l.innerHTML = n;
            for (let o = 0; o < l.childNodes.length; o += 1) r.push(l.childNodes[o])
        } else r = ve(e.trim(), t || s)
    } else if (e.nodeType || e === i || e === s) r.push(e);
    else if (Array.isArray(e)) {
        if (e instanceof k) return e;
        r = e
    }
    return new k(ge(r))
}
p.fn = k.prototype;

function we(...e) {
    const t = D(e.map(i => i.split(" ")));
    return this.forEach(i => {
        i.classList.add(...t)
    }), this
}

function Se(...e) {
    const t = D(e.map(i => i.split(" ")));
    return this.forEach(i => {
        i.classList.remove(...t)
    }), this
}

function Te(...e) {
    const t = D(e.map(i => i.split(" ")));
    this.forEach(i => {
        t.forEach(s => {
            i.classList.toggle(s)
        })
    })
}

function be(...e) {
    const t = D(e.map(i => i.split(" ")));
    return ne(this, i => t.filter(s => i.classList.contains(s)).length > 0).length > 0
}

function ye(e, t) {
    if (arguments.length === 1 && typeof e == "string") return this[0] ? this[0].getAttribute(e) : void 0;
    for (let i = 0; i < this.length; i += 1)
        if (arguments.length === 2) this[i].setAttribute(e, t);
        else
            for (const s in e) this[i][s] = e[s], this[i].setAttribute(s, e[s]);
    return this
}

function xe(e) {
    for (let t = 0; t < this.length; t += 1) this[t].removeAttribute(e);
    return this
}

function Ee(e) {
    for (let t = 0; t < this.length; t += 1) this[t].style.transform = e;
    return this
}

function Ce(e) {
    for (let t = 0; t < this.length; t += 1) this[t].style.transitionDuration = typeof e != "string" ? `${e}ms` : e;
    return this
}

function Me(...e) {
    let [t, i, s, r] = e;
    typeof e[1] == "function" && ([t, s, r] = e, i = void 0), r || (r = !1);

    function n(d) {
        const f = d.target;
        if (!f) return;
        const c = d.target.dom7EventData || [];
        if (c.indexOf(d) < 0 && c.unshift(d), p(f).is(i)) s.apply(f, c);
        else {
            const u = p(f).parents();
            for (let h = 0; h < u.length; h += 1) p(u[h]).is(i) && s.apply(u[h], c)
        }
    }

    function a(d) {
        const f = d && d.target ? d.target.dom7EventData || [] : [];
        f.indexOf(d) < 0 && f.unshift(d), s.apply(this, f)
    }
    const l = t.split(" ");
    let o;
    for (let d = 0; d < this.length; d += 1) {
        const f = this[d];
        if (i)
            for (o = 0; o < l.length; o += 1) {
                const c = l[o];
                f.dom7LiveListeners || (f.dom7LiveListeners = {}), f.dom7LiveListeners[c] || (f.dom7LiveListeners[c] = []), f.dom7LiveListeners[c].push({
                    listener: s,
                    proxyListener: n
                }), f.addEventListener(c, n, r)
            } else
                for (o = 0; o < l.length; o += 1) {
                    const c = l[o];
                    f.dom7Listeners || (f.dom7Listeners = {}), f.dom7Listeners[c] || (f.dom7Listeners[c] = []), f.dom7Listeners[c].push({
                        listener: s,
                        proxyListener: a
                    }), f.addEventListener(c, a, r)
                }
    }
    return this
}

function Pe(...e) {
    let [t, i, s, r] = e;
    typeof e[1] == "function" && ([t, s, r] = e, i = void 0), r || (r = !1);
    const n = t.split(" ");
    for (let a = 0; a < n.length; a += 1) {
        const l = n[a];
        for (let o = 0; o < this.length; o += 1) {
            const d = this[o];
            let f;
            if (!i && d.dom7Listeners ? f = d.dom7Listeners[l] : i && d.dom7LiveListeners && (f = d.dom7LiveListeners[l]), f && f.length)
                for (let c = f.length - 1; c >= 0; c -= 1) {
                    const u = f[c];
                    s && u.listener === s || s && u.listener && u.listener.dom7proxy && u.listener.dom7proxy === s ? (d.removeEventListener(l, u.proxyListener, r), f.splice(c, 1)) : s || (d.removeEventListener(l, u.proxyListener, r), f.splice(c, 1))
                }
        }
    }
    return this
}

function Le(...e) {
    const t = C(),
        i = e[0].split(" "),
        s = e[1];
    for (let r = 0; r < i.length; r += 1) {
        const n = i[r];
        for (let a = 0; a < this.length; a += 1) {
            const l = this[a];
            if (t.CustomEvent) {
                const o = new t.CustomEvent(n, {
                    detail: s,
                    bubbles: !0,
                    cancelable: !0
                });
                l.dom7EventData = e.filter((d, f) => f > 0), l.dispatchEvent(o), l.dom7EventData = [], delete l.dom7EventData
            }
        }
    }
    return this
}

function Oe(e) {
    const t = this;

    function i(s) {
        s.target === this && (e.call(this, s), t.off("transitionend", i))
    }
    return e && t.on("transitionend", i), this
}

function $e(e) {
    if (this.length > 0) {
        if (e) {
            const t = this.styles();
            return this[0].offsetWidth + parseFloat(t.getPropertyValue("margin-right")) + parseFloat(t.getPropertyValue("margin-left"))
        }
        return this[0].offsetWidth
    }
    return null
}

function Ie(e) {
    if (this.length > 0) {
        if (e) {
            const t = this.styles();
            return this[0].offsetHeight + parseFloat(t.getPropertyValue("margin-top")) + parseFloat(t.getPropertyValue("margin-bottom"))
        }
        return this[0].offsetHeight
    }
    return null
}

function ke() {
    if (this.length > 0) {
        const e = C(),
            t = L(),
            i = this[0],
            s = i.getBoundingClientRect(),
            r = t.body,
            n = i.clientTop || r.clientTop || 0,
            a = i.clientLeft || r.clientLeft || 0,
            l = i === e ? e.scrollY : i.scrollTop,
            o = i === e ? e.scrollX : i.scrollLeft;
        return {
            top: s.top + l - n,
            left: s.left + o - a
        }
    }
    return null
}

function ze() {
    const e = C();
    return this[0] ? e.getComputedStyle(this[0], null) : {}
}

function Ae(e, t) {
    const i = C();
    let s;
    if (arguments.length === 1)
        if (typeof e == "string") {
            if (this[0]) return i.getComputedStyle(this[0], null).getPropertyValue(e)
        } else {
            for (s = 0; s < this.length; s += 1)
                for (const r in e) this[s].style[r] = e[r];
            return this
        }
    if (arguments.length === 2 && typeof e == "string") {
        for (s = 0; s < this.length; s += 1) this[s].style[e] = t;
        return this
    }
    return this
}

function De(e) {
    return e ? (this.forEach((t, i) => {
        e.apply(t, [t, i])
    }), this) : this
}

function Ge(e) {
    const t = ne(this, e);
    return p(t)
}

function Ne(e) {
    if (typeof e == "undefined") return this[0] ? this[0].innerHTML : null;
    for (let t = 0; t < this.length; t += 1) this[t].innerHTML = e;
    return this
}

function Be(e) {
    if (typeof e == "undefined") return this[0] ? this[0].textContent.trim() : null;
    for (let t = 0; t < this.length; t += 1) this[t].textContent = e;
    return this
}

function Ve(e) {
    const t = C(),
        i = L(),
        s = this[0];
    let r, n;
    if (!s || typeof e == "undefined") return !1;
    if (typeof e == "string") {
        if (s.matches) return s.matches(e);
        if (s.webkitMatchesSelector) return s.webkitMatchesSelector(e);
        if (s.msMatchesSelector) return s.msMatchesSelector(e);
        for (r = p(e), n = 0; n < r.length; n += 1)
            if (r[n] === s) return !0;
        return !1
    }
    if (e === i) return s === i;
    if (e === t) return s === t;
    if (e.nodeType || e instanceof k) {
        for (r = e.nodeType ? [e] : e, n = 0; n < r.length; n += 1)
            if (r[n] === s) return !0;
        return !1
    }
    return !1
}

function He() {
    let e = this[0],
        t;
    if (e) {
        for (t = 0;
            (e = e.previousSibling) !== null;) e.nodeType === 1 && (t += 1);
        return t
    }
}

function _e(e) {
    if (typeof e == "undefined") return this;
    const t = this.length;
    if (e > t - 1) return p([]);
    if (e < 0) {
        const i = t + e;
        return i < 0 ? p([]) : p([this[i]])
    }
    return p([this[e]])
}

function Fe(...e) {
    let t;
    const i = L();
    for (let s = 0; s < e.length; s += 1) {
        t = e[s];
        for (let r = 0; r < this.length; r += 1)
            if (typeof t == "string") {
                const n = i.createElement("div");
                for (n.innerHTML = t; n.firstChild;) this[r].appendChild(n.firstChild)
            } else if (t instanceof k)
            for (let n = 0; n < t.length; n += 1) this[r].appendChild(t[n]);
        else this[r].appendChild(t)
    }
    return this
}

function Re(e) {
    const t = L();
    let i, s;
    for (i = 0; i < this.length; i += 1)
        if (typeof e == "string") {
            const r = t.createElement("div");
            for (r.innerHTML = e, s = r.childNodes.length - 1; s >= 0; s -= 1) this[i].insertBefore(r.childNodes[s], this[i].childNodes[0])
        } else if (e instanceof k)
        for (s = 0; s < e.length; s += 1) this[i].insertBefore(e[s], this[i].childNodes[0]);
    else this[i].insertBefore(e, this[i].childNodes[0]);
    return this
}

function We(e) {
    return this.length > 0 ? e ? this[0].nextElementSibling && p(this[0].nextElementSibling).is(e) ? p([this[0].nextElementSibling]) : p([]) : this[0].nextElementSibling ? p([this[0].nextElementSibling]) : p([]) : p([])
}

function je(e) {
    const t = [];
    let i = this[0];
    if (!i) return p([]);
    for (; i.nextElementSibling;) {
        const s = i.nextElementSibling;
        e ? p(s).is(e) && t.push(s) : t.push(s), i = s
    }
    return p(t)
}

function qe(e) {
    if (this.length > 0) {
        const t = this[0];
        return e ? t.previousElementSibling && p(t.previousElementSibling).is(e) ? p([t.previousElementSibling]) : p([]) : t.previousElementSibling ? p([t.previousElementSibling]) : p([])
    }
    return p([])
}

function Xe(e) {
    const t = [];
    let i = this[0];
    if (!i) return p([]);
    for (; i.previousElementSibling;) {
        const s = i.previousElementSibling;
        e ? p(s).is(e) && t.push(s) : t.push(s), i = s
    }
    return p(t)
}

function Ye(e) {
    const t = [];
    for (let i = 0; i < this.length; i += 1) this[i].parentNode !== null && (e ? p(this[i].parentNode).is(e) && t.push(this[i].parentNode) : t.push(this[i].parentNode));
    return p(t)
}

function Ke(e) {
    const t = [];
    for (let i = 0; i < this.length; i += 1) {
        let s = this[i].parentNode;
        for (; s;) e ? p(s).is(e) && t.push(s) : t.push(s), s = s.parentNode
    }
    return p(t)
}

function Ue(e) {
    let t = this;
    return typeof e == "undefined" ? p([]) : (t.is(e) || (t = t.parents(e).eq(0)), t)
}

function Je(e) {
    const t = [];
    for (let i = 0; i < this.length; i += 1) {
        const s = this[i].querySelectorAll(e);
        for (let r = 0; r < s.length; r += 1) t.push(s[r])
    }
    return p(t)
}

function Qe(e) {
    const t = [];
    for (let i = 0; i < this.length; i += 1) {
        const s = this[i].children;
        for (let r = 0; r < s.length; r += 1)(!e || p(s[r]).is(e)) && t.push(s[r])
    }
    return p(t)
}

function Ze() {
    for (let e = 0; e < this.length; e += 1) this[e].parentNode && this[e].parentNode.removeChild(this[e]);
    return this
}
const Q = {
    addClass: we,
    removeClass: Se,
    hasClass: be,
    toggleClass: Te,
    attr: ye,
    removeAttr: xe,
    transform: Ee,
    transition: Ce,
    on: Me,
    off: Pe,
    trigger: Le,
    transitionEnd: Oe,
    outerWidth: $e,
    outerHeight: Ie,
    styles: ze,
    offset: ke,
    css: Ae,
    each: De,
    html: Ne,
    text: Be,
    is: Ve,
    index: He,
    eq: _e,
    append: Fe,
    prepend: Re,
    next: We,
    nextAll: je,
    prev: qe,
    prevAll: Xe,
    parent: Ye,
    parents: Ke,
    closest: Ue,
    find: Je,
    children: Qe,
    filter: Ge,
    remove: Ze
};
Object.keys(Q).forEach(e => {
    Object.defineProperty(p.fn, e, {
        value: Q[e],
        writable: !0
    })
});

function et(e) {
    const t = e;
    Object.keys(t).forEach(i => {
        try {
            t[i] = null
        } catch {}
        try {
            delete t[i]
        } catch {}
    })
}

function j(e, t) {
    return t === void 0 && (t = 0), setTimeout(e, t)
}

function A() {
    return Date.now()
}

function tt(e) {
    const t = C();
    let i;
    return t.getComputedStyle && (i = t.getComputedStyle(e, null)), !i && e.currentStyle && (i = e.currentStyle), i || (i = e.style), i
}

function it(e, t) {
    t === void 0 && (t = "x");
    const i = C();
    let s, r, n;
    const a = tt(e);
    return i.WebKitCSSMatrix ? (r = a.transform || a.webkitTransform, r.split(",").length > 6 && (r = r.split(", ").map(l => l.replace(",", ".")).join(", ")), n = new i.WebKitCSSMatrix(r === "none" ? "" : r)) : (n = a.MozTransform || a.OTransform || a.MsTransform || a.msTransform || a.transform || a.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), s = n.toString().split(",")), t === "x" && (i.WebKitCSSMatrix ? r = n.m41 : s.length === 16 ? r = parseFloat(s[12]) : r = parseFloat(s[4])), t === "y" && (i.WebKitCSSMatrix ? r = n.m42 : s.length === 16 ? r = parseFloat(s[13]) : r = parseFloat(s[5])), r || 0
}

function G(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function st(e) {
    return typeof window != "undefined" && typeof window.HTMLElement != "undefined" ? e instanceof HTMLElement : e && (e.nodeType === 1 || e.nodeType === 11)
}

function P() {
    const e = Object(arguments.length <= 0 ? void 0 : arguments[0]),
        t = ["__proto__", "constructor", "prototype"];
    for (let i = 1; i < arguments.length; i += 1) {
        const s = i < 0 || arguments.length <= i ? void 0 : arguments[i];
        if (s != null && !st(s)) {
            const r = Object.keys(Object(s)).filter(n => t.indexOf(n) < 0);
            for (let n = 0, a = r.length; n < a; n += 1) {
                const l = r[n],
                    o = Object.getOwnPropertyDescriptor(s, l);
                o !== void 0 && o.enumerable && (G(e[l]) && G(s[l]) ? s[l].__swiper__ ? e[l] = s[l] : P(e[l], s[l]) : !G(e[l]) && G(s[l]) ? (e[l] = {}, s[l].__swiper__ ? e[l] = s[l] : P(e[l], s[l])) : e[l] = s[l])
            }
        }
    }
    return e
}

function N(e, t, i) {
    e.style.setProperty(t, i)
}

function re(e) {
    let {
        swiper: t,
        targetPosition: i,
        side: s
    } = e;
    const r = C(),
        n = -t.translate;
    let a = null,
        l;
    const o = t.params.speed;
    t.wrapperEl.style.scrollSnapType = "none", r.cancelAnimationFrame(t.cssModeFrameID);
    const d = i > n ? "next" : "prev",
        f = (u, h) => d === "next" && u >= h || d === "prev" && u <= h,
        c = () => {
            l = new Date().getTime(), a === null && (a = l);
            const u = Math.max(Math.min((l - a) / o, 1), 0),
                h = .5 - Math.cos(u * Math.PI) / 2;
            let m = n + h * (i - n);
            if (f(m, i) && (m = i), t.wrapperEl.scrollTo({
                    [s]: m
                }), f(m, i)) {
                t.wrapperEl.style.overflow = "hidden", t.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
                    t.wrapperEl.style.overflow = "", t.wrapperEl.scrollTo({
                        [s]: m
                    })
                }), r.cancelAnimationFrame(t.cssModeFrameID);
                return
            }
            t.cssModeFrameID = r.requestAnimationFrame(c)
        };
    c()
}
let H;

function nt() {
    const e = C(),
        t = L();
    return {
        smoothScroll: t.documentElement && "scrollBehavior" in t.documentElement.style,
        touch: !!("ontouchstart" in e || e.DocumentTouch && t instanceof e.DocumentTouch),
        passiveListener: function() {
            let s = !1;
            try {
                const r = Object.defineProperty({}, "passive", {
                    get() {
                        s = !0
                    }
                });
                e.addEventListener("testPassiveListener", null, r)
            } catch {}
            return s
        }(),
        gestures: function() {
            return "ongesturestart" in e
        }()
    }
}

function ae() {
    return H || (H = nt()), H
}
let _;

function rt(e) {
    let {
        userAgent: t
    } = e === void 0 ? {} : e;
    const i = ae(),
        s = C(),
        r = s.navigator.platform,
        n = t || s.navigator.userAgent,
        a = {
            ios: !1,
            android: !1
        },
        l = s.screen.width,
        o = s.screen.height,
        d = n.match(/(Android);?[\s\/]+([\d.]+)?/);
    let f = n.match(/(iPad).*OS\s([\d_]+)/);
    const c = n.match(/(iPod)(.*OS\s([\d_]+))?/),
        u = !f && n.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
        h = r === "Win32";
    let m = r === "MacIntel";
    const v = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
    return !f && m && i.touch && v.indexOf(`${l}x${o}`) >= 0 && (f = n.match(/(Version)\/([\d.]+)/), f || (f = [0, 1, "13_0_0"]), m = !1), d && !h && (a.os = "android", a.android = !0), (f || u || c) && (a.os = "ios", a.ios = !0), a
}

function at(e) {
    return e === void 0 && (e = {}), _ || (_ = rt(e)), _
}
let F;

function ot() {
    const e = C();

    function t() {
        const i = e.navigator.userAgent.toLowerCase();
        return i.indexOf("safari") >= 0 && i.indexOf("chrome") < 0 && i.indexOf("android") < 0
    }
    return {
        isSafari: t(),
        isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent)
    }
}

function lt() {
    return F || (F = ot()), F
}

function dt(e) {
    let {
        swiper: t,
        on: i,
        emit: s
    } = e;
    const r = C();
    let n = null,
        a = null;
    const l = () => {
            !t || t.destroyed || !t.initialized || (s("beforeResize"), s("resize"))
        },
        o = () => {
            !t || t.destroyed || !t.initialized || (n = new ResizeObserver(c => {
                a = r.requestAnimationFrame(() => {
                    const {
                        width: u,
                        height: h
                    } = t;
                    let m = u,
                        v = h;
                    c.forEach(g => {
                        let {
                            contentBoxSize: T,
                            contentRect: w,
                            target: b
                        } = g;
                        b && b !== t.el || (m = w ? w.width : (T[0] || T).inlineSize, v = w ? w.height : (T[0] || T).blockSize)
                    }), (m !== u || v !== h) && l()
                })
            }), n.observe(t.el))
        },
        d = () => {
            a && r.cancelAnimationFrame(a), n && n.unobserve && t.el && (n.unobserve(t.el), n = null)
        },
        f = () => {
            !t || t.destroyed || !t.initialized || s("orientationchange")
        };
    i("init", () => {
        if (t.params.resizeObserver && typeof r.ResizeObserver != "undefined") {
            o();
            return
        }
        r.addEventListener("resize", l), r.addEventListener("orientationchange", f)
    }), i("destroy", () => {
        d(), r.removeEventListener("resize", l), r.removeEventListener("orientationchange", f)
    })
}

function ft(e) {
    let {
        swiper: t,
        extendParams: i,
        on: s,
        emit: r
    } = e;
    const n = [],
        a = C(),
        l = function(f, c) {
            c === void 0 && (c = {});
            const u = a.MutationObserver || a.WebkitMutationObserver,
                h = new u(m => {
                    if (m.length === 1) {
                        r("observerUpdate", m[0]);
                        return
                    }
                    const v = function() {
                        r("observerUpdate", m[0])
                    };
                    a.requestAnimationFrame ? a.requestAnimationFrame(v) : a.setTimeout(v, 0)
                });
            h.observe(f, {
                attributes: typeof c.attributes == "undefined" ? !0 : c.attributes,
                childList: typeof c.childList == "undefined" ? !0 : c.childList,
                characterData: typeof c.characterData == "undefined" ? !0 : c.characterData
            }), n.push(h)
        },
        o = () => {
            if (!!t.params.observer) {
                if (t.params.observeParents) {
                    const f = t.$el.parents();
                    for (let c = 0; c < f.length; c += 1) l(f[c])
                }
                l(t.$el[0], {
                    childList: t.params.observeSlideChildren
                }), l(t.$wrapperEl[0], {
                    attributes: !1
                })
            }
        },
        d = () => {
            n.forEach(f => {
                f.disconnect()
            }), n.splice(0, n.length)
        };
    i({
        observer: !1,
        observeParents: !1,
        observeSlideChildren: !1
    }), s("init", o), s("destroy", d)
}
var ct = {
    on(e, t, i) {
        const s = this;
        if (!s.eventsListeners || s.destroyed || typeof t != "function") return s;
        const r = i ? "unshift" : "push";
        return e.split(" ").forEach(n => {
            s.eventsListeners[n] || (s.eventsListeners[n] = []), s.eventsListeners[n][r](t)
        }), s
    },
    once(e, t, i) {
        const s = this;
        if (!s.eventsListeners || s.destroyed || typeof t != "function") return s;

        function r() {
            s.off(e, r), r.__emitterProxy && delete r.__emitterProxy;
            for (var n = arguments.length, a = new Array(n), l = 0; l < n; l++) a[l] = arguments[l];
            t.apply(s, a)
        }
        return r.__emitterProxy = t, s.on(e, r, i)
    },
    onAny(e, t) {
        const i = this;
        if (!i.eventsListeners || i.destroyed || typeof e != "function") return i;
        const s = t ? "unshift" : "push";
        return i.eventsAnyListeners.indexOf(e) < 0 && i.eventsAnyListeners[s](e), i
    },
    offAny(e) {
        const t = this;
        if (!t.eventsListeners || t.destroyed || !t.eventsAnyListeners) return t;
        const i = t.eventsAnyListeners.indexOf(e);
        return i >= 0 && t.eventsAnyListeners.splice(i, 1), t
    },
    off(e, t) {
        const i = this;
        return !i.eventsListeners || i.destroyed || !i.eventsListeners || e.split(" ").forEach(s => {
            typeof t == "undefined" ? i.eventsListeners[s] = [] : i.eventsListeners[s] && i.eventsListeners[s].forEach((r, n) => {
                (r === t || r.__emitterProxy && r.__emitterProxy === t) && i.eventsListeners[s].splice(n, 1)
            })
        }), i
    },
    emit() {
        const e = this;
        if (!e.eventsListeners || e.destroyed || !e.eventsListeners) return e;
        let t, i, s;
        for (var r = arguments.length, n = new Array(r), a = 0; a < r; a++) n[a] = arguments[a];
        return typeof n[0] == "string" || Array.isArray(n[0]) ? (t = n[0], i = n.slice(1, n.length), s = e) : (t = n[0].events, i = n[0].data, s = n[0].context || e), i.unshift(s), (Array.isArray(t) ? t : t.split(" ")).forEach(o => {
            e.eventsAnyListeners && e.eventsAnyListeners.length && e.eventsAnyListeners.forEach(d => {
                d.apply(s, [o, ...i])
            }), e.eventsListeners && e.eventsListeners[o] && e.eventsListeners[o].forEach(d => {
                d.apply(s, i)
            })
        }), e
    }
};

function ut() {
    const e = this;
    let t, i;
    const s = e.$el;
    typeof e.params.width != "undefined" && e.params.width !== null ? t = e.params.width : t = s[0].clientWidth, typeof e.params.height != "undefined" && e.params.height !== null ? i = e.params.height : i = s[0].clientHeight, !(t === 0 && e.isHorizontal() || i === 0 && e.isVertical()) && (t = t - parseInt(s.css("padding-left") || 0, 10) - parseInt(s.css("padding-right") || 0, 10), i = i - parseInt(s.css("padding-top") || 0, 10) - parseInt(s.css("padding-bottom") || 0, 10), Number.isNaN(t) && (t = 0), Number.isNaN(i) && (i = 0), Object.assign(e, {
        width: t,
        height: i,
        size: e.isHorizontal() ? t : i
    }))
}

function pt() {
    const e = this;

    function t(S) {
        return e.isHorizontal() ? S : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
        }[S]
    }

    function i(S, y) {
        return parseFloat(S.getPropertyValue(t(y)) || 0)
    }
    const s = e.params,
        {
            $wrapperEl: r,
            size: n,
            rtlTranslate: a,
            wrongRTL: l
        } = e,
        o = e.virtual && s.virtual.enabled,
        d = o ? e.virtual.slides.length : e.slides.length,
        f = r.children(`.${e.params.slideClass}`),
        c = o ? e.virtual.slides.length : f.length;
    let u = [];
    const h = [],
        m = [];
    let v = s.slidesOffsetBefore;
    typeof v == "function" && (v = s.slidesOffsetBefore.call(e));
    let g = s.slidesOffsetAfter;
    typeof g == "function" && (g = s.slidesOffsetAfter.call(e));
    const T = e.snapGrid.length,
        w = e.slidesGrid.length;
    let b = s.spaceBetween,
        x = -v,
        $ = 0,
        I = 0;
    if (typeof n == "undefined") return;
    typeof b == "string" && b.indexOf("%") >= 0 && (b = parseFloat(b.replace("%", "")) / 100 * n), e.virtualSize = -b, a ? f.css({
        marginLeft: "",
        marginBottom: "",
        marginTop: ""
    }) : f.css({
        marginRight: "",
        marginBottom: "",
        marginTop: ""
    }), s.centeredSlides && s.cssMode && (N(e.wrapperEl, "--swiper-centered-offset-before", ""), N(e.wrapperEl, "--swiper-centered-offset-after", ""));
    const B = s.grid && s.grid.rows > 1 && e.grid;
    B && e.grid.initSlides(c);
    let M;
    const de = s.slidesPerView === "auto" && s.breakpoints && Object.keys(s.breakpoints).filter(S => typeof s.breakpoints[S].slidesPerView != "undefined").length > 0;
    for (let S = 0; S < c; S += 1) {
        M = 0;
        const y = f.eq(S);
        if (B && e.grid.updateSlide(S, y, c, t), y.css("display") !== "none") {
            if (s.slidesPerView === "auto") {
                de && (f[S].style[t("width")] = "");
                const E = getComputedStyle(y[0]),
                    z = y[0].style.transform,
                    V = y[0].style.webkitTransform;
                if (z && (y[0].style.transform = "none"), V && (y[0].style.webkitTransform = "none"), s.roundLengths) M = e.isHorizontal() ? y.outerWidth(!0) : y.outerHeight(!0);
                else {
                    const X = i(E, "width"),
                        fe = i(E, "padding-left"),
                        ce = i(E, "padding-right"),
                        Y = i(E, "margin-left"),
                        K = i(E, "margin-right"),
                        U = E.getPropertyValue("box-sizing");
                    if (U && U === "border-box") M = X + Y + K;
                    else {
                        const {
                            clientWidth: ue,
                            offsetWidth: pe
                        } = y[0];
                        M = X + fe + ce + Y + K + (pe - ue)
                    }
                }
                z && (y[0].style.transform = z), V && (y[0].style.webkitTransform = V), s.roundLengths && (M = Math.floor(M))
            } else M = (n - (s.slidesPerView - 1) * b) / s.slidesPerView, s.roundLengths && (M = Math.floor(M)), f[S] && (f[S].style[t("width")] = `${M}px`);
            f[S] && (f[S].swiperSlideSize = M), m.push(M), s.centeredSlides ? (x = x + M / 2 + $ / 2 + b, $ === 0 && S !== 0 && (x = x - n / 2 - b), S === 0 && (x = x - n / 2 - b), Math.abs(x) < 1 / 1e3 && (x = 0), s.roundLengths && (x = Math.floor(x)), I % s.slidesPerGroup === 0 && u.push(x), h.push(x)) : (s.roundLengths && (x = Math.floor(x)), (I - Math.min(e.params.slidesPerGroupSkip, I)) % e.params.slidesPerGroup === 0 && u.push(x), h.push(x), x = x + M + b), e.virtualSize += M + b, $ = M, I += 1
        }
    }
    if (e.virtualSize = Math.max(e.virtualSize, n) + g, a && l && (s.effect === "slide" || s.effect === "coverflow") && r.css({
            width: `${e.virtualSize+s.spaceBetween}px`
        }), s.setWrapperSize && r.css({
            [t("width")]: `${e.virtualSize+s.spaceBetween}px`
        }), B && e.grid.updateWrapperSize(M, u, t), !s.centeredSlides) {
        const S = [];
        for (let y = 0; y < u.length; y += 1) {
            let E = u[y];
            s.roundLengths && (E = Math.floor(E)), u[y] <= e.virtualSize - n && S.push(E)
        }
        u = S, Math.floor(e.virtualSize - n) - Math.floor(u[u.length - 1]) > 1 && u.push(e.virtualSize - n)
    }
    if (u.length === 0 && (u = [0]), s.spaceBetween !== 0) {
        const S = e.isHorizontal() && a ? "marginLeft" : t("marginRight");
        f.filter((y, E) => s.cssMode ? E !== f.length - 1 : !0).css({
            [S]: `${b}px`
        })
    }
    if (s.centeredSlides && s.centeredSlidesBounds) {
        let S = 0;
        m.forEach(E => {
            S += E + (s.spaceBetween ? s.spaceBetween : 0)
        }), S -= s.spaceBetween;
        const y = S - n;
        u = u.map(E => E < 0 ? -v : E > y ? y + g : E)
    }
    if (s.centerInsufficientSlides) {
        let S = 0;
        if (m.forEach(y => {
                S += y + (s.spaceBetween ? s.spaceBetween : 0)
            }), S -= s.spaceBetween, S < n) {
            const y = (n - S) / 2;
            u.forEach((E, z) => {
                u[z] = E - y
            }), h.forEach((E, z) => {
                h[z] = E + y
            })
        }
    }
    if (Object.assign(e, {
            slides: f,
            snapGrid: u,
            slidesGrid: h,
            slidesSizesGrid: m
        }), s.centeredSlides && s.cssMode && !s.centeredSlidesBounds) {
        N(e.wrapperEl, "--swiper-centered-offset-before", `${-u[0]}px`), N(e.wrapperEl, "--swiper-centered-offset-after", `${e.size/2-m[m.length-1]/2}px`);
        const S = -e.snapGrid[0],
            y = -e.slidesGrid[0];
        e.snapGrid = e.snapGrid.map(E => E + S), e.slidesGrid = e.slidesGrid.map(E => E + y)
    }
    if (c !== d && e.emit("slidesLengthChange"), u.length !== T && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), h.length !== w && e.emit("slidesGridLengthChange"), s.watchSlidesProgress && e.updateSlidesOffset(), !o && !s.cssMode && (s.effect === "slide" || s.effect === "fade")) {
        const S = `${s.containerModifierClass}backface-hidden`,
            y = e.$el.hasClass(S);
        c <= s.maxBackfaceHiddenSlides ? y || e.$el.addClass(S) : y && e.$el.removeClass(S)
    }
}

function ht(e) {
    const t = this,
        i = [],
        s = t.virtual && t.params.virtual.enabled;
    let r = 0,
        n;
    typeof e == "number" ? t.setTransition(e) : e === !0 && t.setTransition(t.params.speed);
    const a = l => s ? t.slides.filter(o => parseInt(o.getAttribute("data-swiper-slide-index"), 10) === l)[0] : t.slides.eq(l)[0];
    if (t.params.slidesPerView !== "auto" && t.params.slidesPerView > 1)
        if (t.params.centeredSlides)(t.visibleSlides || p([])).each(l => {
            i.push(l)
        });
        else
            for (n = 0; n < Math.ceil(t.params.slidesPerView); n += 1) {
                const l = t.activeIndex + n;
                if (l > t.slides.length && !s) break;
                i.push(a(l))
            } else i.push(a(t.activeIndex));
    for (n = 0; n < i.length; n += 1)
        if (typeof i[n] != "undefined") {
            const l = i[n].offsetHeight;
            r = l > r ? l : r
        }(r || r === 0) && t.$wrapperEl.css("height", `${r}px`)
}

function mt() {
    const e = this,
        t = e.slides;
    for (let i = 0; i < t.length; i += 1) t[i].swiperSlideOffset = e.isHorizontal() ? t[i].offsetLeft : t[i].offsetTop
}

function gt(e) {
    e === void 0 && (e = this && this.translate || 0);
    const t = this,
        i = t.params,
        {
            slides: s,
            rtlTranslate: r,
            snapGrid: n
        } = t;
    if (s.length === 0) return;
    typeof s[0].swiperSlideOffset == "undefined" && t.updateSlidesOffset();
    let a = -e;
    r && (a = e), s.removeClass(i.slideVisibleClass), t.visibleSlidesIndexes = [], t.visibleSlides = [];
    for (let l = 0; l < s.length; l += 1) {
        const o = s[l];
        let d = o.swiperSlideOffset;
        i.cssMode && i.centeredSlides && (d -= s[0].swiperSlideOffset);
        const f = (a + (i.centeredSlides ? t.minTranslate() : 0) - d) / (o.swiperSlideSize + i.spaceBetween),
            c = (a - n[0] + (i.centeredSlides ? t.minTranslate() : 0) - d) / (o.swiperSlideSize + i.spaceBetween),
            u = -(a - d),
            h = u + t.slidesSizesGrid[l];
        (u >= 0 && u < t.size - 1 || h > 1 && h <= t.size || u <= 0 && h >= t.size) && (t.visibleSlides.push(o), t.visibleSlidesIndexes.push(l), s.eq(l).addClass(i.slideVisibleClass)), o.progress = r ? -f : f, o.originalProgress = r ? -c : c
    }
    t.visibleSlides = p(t.visibleSlides)
}

function vt(e) {
    const t = this;
    if (typeof e == "undefined") {
        const d = t.rtlTranslate ? -1 : 1;
        e = t && t.translate && t.translate * d || 0
    }
    const i = t.params,
        s = t.maxTranslate() - t.minTranslate();
    let {
        progress: r,
        isBeginning: n,
        isEnd: a
    } = t;
    const l = n,
        o = a;
    s === 0 ? (r = 0, n = !0, a = !0) : (r = (e - t.minTranslate()) / s, n = r <= 0, a = r >= 1), Object.assign(t, {
        progress: r,
        isBeginning: n,
        isEnd: a
    }), (i.watchSlidesProgress || i.centeredSlides && i.autoHeight) && t.updateSlidesProgress(e), n && !l && t.emit("reachBeginning toEdge"), a && !o && t.emit("reachEnd toEdge"), (l && !n || o && !a) && t.emit("fromEdge"), t.emit("progress", r)
}

function wt() {
    const e = this,
        {
            slides: t,
            params: i,
            $wrapperEl: s,
            activeIndex: r,
            realIndex: n
        } = e,
        a = e.virtual && i.virtual.enabled;
    t.removeClass(`${i.slideActiveClass} ${i.slideNextClass} ${i.slidePrevClass} ${i.slideDuplicateActiveClass} ${i.slideDuplicateNextClass} ${i.slideDuplicatePrevClass}`);
    let l;
    a ? l = e.$wrapperEl.find(`.${i.slideClass}[data-swiper-slide-index="${r}"]`) : l = t.eq(r), l.addClass(i.slideActiveClass), i.loop && (l.hasClass(i.slideDuplicateClass) ? s.children(`.${i.slideClass}:not(.${i.slideDuplicateClass})[data-swiper-slide-index="${n}"]`).addClass(i.slideDuplicateActiveClass) : s.children(`.${i.slideClass}.${i.slideDuplicateClass}[data-swiper-slide-index="${n}"]`).addClass(i.slideDuplicateActiveClass));
    let o = l.nextAll(`.${i.slideClass}`).eq(0).addClass(i.slideNextClass);
    i.loop && o.length === 0 && (o = t.eq(0), o.addClass(i.slideNextClass));
    let d = l.prevAll(`.${i.slideClass}`).eq(0).addClass(i.slidePrevClass);
    i.loop && d.length === 0 && (d = t.eq(-1), d.addClass(i.slidePrevClass)), i.loop && (o.hasClass(i.slideDuplicateClass) ? s.children(`.${i.slideClass}:not(.${i.slideDuplicateClass})[data-swiper-slide-index="${o.attr("data-swiper-slide-index")}"]`).addClass(i.slideDuplicateNextClass) : s.children(`.${i.slideClass}.${i.slideDuplicateClass}[data-swiper-slide-index="${o.attr("data-swiper-slide-index")}"]`).addClass(i.slideDuplicateNextClass), d.hasClass(i.slideDuplicateClass) ? s.children(`.${i.slideClass}:not(.${i.slideDuplicateClass})[data-swiper-slide-index="${d.attr("data-swiper-slide-index")}"]`).addClass(i.slideDuplicatePrevClass) : s.children(`.${i.slideClass}.${i.slideDuplicateClass}[data-swiper-slide-index="${d.attr("data-swiper-slide-index")}"]`).addClass(i.slideDuplicatePrevClass)), e.emitSlidesClasses()
}

function St(e) {
    const t = this,
        i = t.rtlTranslate ? t.translate : -t.translate,
        {
            slidesGrid: s,
            snapGrid: r,
            params: n,
            activeIndex: a,
            realIndex: l,
            snapIndex: o
        } = t;
    let d = e,
        f;
    if (typeof d == "undefined") {
        for (let u = 0; u < s.length; u += 1) typeof s[u + 1] != "undefined" ? i >= s[u] && i < s[u + 1] - (s[u + 1] - s[u]) / 2 ? d = u : i >= s[u] && i < s[u + 1] && (d = u + 1) : i >= s[u] && (d = u);
        n.normalizeSlideIndex && (d < 0 || typeof d == "undefined") && (d = 0)
    }
    if (r.indexOf(i) >= 0) f = r.indexOf(i);
    else {
        const u = Math.min(n.slidesPerGroupSkip, d);
        f = u + Math.floor((d - u) / n.slidesPerGroup)
    }
    if (f >= r.length && (f = r.length - 1), d === a) {
        f !== o && (t.snapIndex = f, t.emit("snapIndexChange"));
        return
    }
    const c = parseInt(t.slides.eq(d).attr("data-swiper-slide-index") || d, 10);
    Object.assign(t, {
        snapIndex: f,
        realIndex: c,
        previousIndex: a,
        activeIndex: d
    }), t.emit("activeIndexChange"), t.emit("snapIndexChange"), l !== c && t.emit("realIndexChange"), (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange")
}

function Tt(e) {
    const t = this,
        i = t.params,
        s = p(e).closest(`.${i.slideClass}`)[0];
    let r = !1,
        n;
    if (s) {
        for (let a = 0; a < t.slides.length; a += 1)
            if (t.slides[a] === s) {
                r = !0, n = a;
                break
            }
    }
    if (s && r) t.clickedSlide = s, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(p(s).attr("data-swiper-slide-index"), 10) : t.clickedIndex = n;
    else {
        t.clickedSlide = void 0, t.clickedIndex = void 0;
        return
    }
    i.slideToClickedSlide && t.clickedIndex !== void 0 && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
}
var bt = {
    updateSize: ut,
    updateSlides: pt,
    updateAutoHeight: ht,
    updateSlidesOffset: mt,
    updateSlidesProgress: gt,
    updateProgress: vt,
    updateSlidesClasses: wt,
    updateActiveIndex: St,
    updateClickedSlide: Tt
};

function yt(e) {
    e === void 0 && (e = this.isHorizontal() ? "x" : "y");
    const t = this,
        {
            params: i,
            rtlTranslate: s,
            translate: r,
            $wrapperEl: n
        } = t;
    if (i.virtualTranslate) return s ? -r : r;
    if (i.cssMode) return r;
    let a = it(n[0], e);
    return s && (a = -a), a || 0
}

function xt(e, t) {
    const i = this,
        {
            rtlTranslate: s,
            params: r,
            $wrapperEl: n,
            wrapperEl: a,
            progress: l
        } = i;
    let o = 0,
        d = 0;
    const f = 0;
    i.isHorizontal() ? o = s ? -e : e : d = e, r.roundLengths && (o = Math.floor(o), d = Math.floor(d)), r.cssMode ? a[i.isHorizontal() ? "scrollLeft" : "scrollTop"] = i.isHorizontal() ? -o : -d : r.virtualTranslate || n.transform(`translate3d(${o}px, ${d}px, ${f}px)`), i.previousTranslate = i.translate, i.translate = i.isHorizontal() ? o : d;
    let c;
    const u = i.maxTranslate() - i.minTranslate();
    u === 0 ? c = 0 : c = (e - i.minTranslate()) / u, c !== l && i.updateProgress(e), i.emit("setTranslate", i.translate, t)
}

function Et() {
    return -this.snapGrid[0]
}

function Ct() {
    return -this.snapGrid[this.snapGrid.length - 1]
}

function Mt(e, t, i, s, r) {
    e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), i === void 0 && (i = !0), s === void 0 && (s = !0);
    const n = this,
        {
            params: a,
            wrapperEl: l
        } = n;
    if (n.animating && a.preventInteractionOnTransition) return !1;
    const o = n.minTranslate(),
        d = n.maxTranslate();
    let f;
    if (s && e > o ? f = o : s && e < d ? f = d : f = e, n.updateProgress(f), a.cssMode) {
        const c = n.isHorizontal();
        if (t === 0) l[c ? "scrollLeft" : "scrollTop"] = -f;
        else {
            if (!n.support.smoothScroll) return re({
                swiper: n,
                targetPosition: -f,
                side: c ? "left" : "top"
            }), !0;
            l.scrollTo({
                [c ? "left" : "top"]: -f,
                behavior: "smooth"
            })
        }
        return !0
    }
    return t === 0 ? (n.setTransition(0), n.setTranslate(f), i && (n.emit("beforeTransitionStart", t, r), n.emit("transitionEnd"))) : (n.setTransition(t), n.setTranslate(f), i && (n.emit("beforeTransitionStart", t, r), n.emit("transitionStart")), n.animating || (n.animating = !0, n.onTranslateToWrapperTransitionEnd || (n.onTranslateToWrapperTransitionEnd = function(u) {
        !n || n.destroyed || u.target === this && (n.$wrapperEl[0].removeEventListener("transitionend", n.onTranslateToWrapperTransitionEnd), n.$wrapperEl[0].removeEventListener("webkitTransitionEnd", n.onTranslateToWrapperTransitionEnd), n.onTranslateToWrapperTransitionEnd = null, delete n.onTranslateToWrapperTransitionEnd, i && n.emit("transitionEnd"))
    }), n.$wrapperEl[0].addEventListener("transitionend", n.onTranslateToWrapperTransitionEnd), n.$wrapperEl[0].addEventListener("webkitTransitionEnd", n.onTranslateToWrapperTransitionEnd))), !0
}
var Pt = {
    getTranslate: yt,
    setTranslate: xt,
    minTranslate: Et,
    maxTranslate: Ct,
    translateTo: Mt
};

function Lt(e, t) {
    const i = this;
    i.params.cssMode || i.$wrapperEl.transition(e), i.emit("setTransition", e, t)
}

function oe(e) {
    let {
        swiper: t,
        runCallbacks: i,
        direction: s,
        step: r
    } = e;
    const {
        activeIndex: n,
        previousIndex: a
    } = t;
    let l = s;
    if (l || (n > a ? l = "next" : n < a ? l = "prev" : l = "reset"), t.emit(`transition${r}`), i && n !== a) {
        if (l === "reset") {
            t.emit(`slideResetTransition${r}`);
            return
        }
        t.emit(`slideChangeTransition${r}`), l === "next" ? t.emit(`slideNextTransition${r}`) : t.emit(`slidePrevTransition${r}`)
    }
}

function Ot(e, t) {
    e === void 0 && (e = !0);
    const i = this,
        {
            params: s
        } = i;
    s.cssMode || (s.autoHeight && i.updateAutoHeight(), oe({
        swiper: i,
        runCallbacks: e,
        direction: t,
        step: "Start"
    }))
}

function $t(e, t) {
    e === void 0 && (e = !0);
    const i = this,
        {
            params: s
        } = i;
    i.animating = !1, !s.cssMode && (i.setTransition(0), oe({
        swiper: i,
        runCallbacks: e,
        direction: t,
        step: "End"
    }))
}
var It = {
    setTransition: Lt,
    transitionStart: Ot,
    transitionEnd: $t
};

function kt(e, t, i, s, r) {
    if (e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), i === void 0 && (i = !0), typeof e != "number" && typeof e != "string") throw new Error(`The 'index' argument cannot have type other than 'number' or 'string'. [${typeof e}] given.`);
    if (typeof e == "string") {
        const b = parseInt(e, 10);
        if (!isFinite(b)) throw new Error(`The passed-in 'index' (string) couldn't be converted to 'number'. [${e}] given.`);
        e = b
    }
    const n = this;
    let a = e;
    a < 0 && (a = 0);
    const {
        params: l,
        snapGrid: o,
        slidesGrid: d,
        previousIndex: f,
        activeIndex: c,
        rtlTranslate: u,
        wrapperEl: h,
        enabled: m
    } = n;
    if (n.animating && l.preventInteractionOnTransition || !m && !s && !r) return !1;
    const v = Math.min(n.params.slidesPerGroupSkip, a);
    let g = v + Math.floor((a - v) / n.params.slidesPerGroup);
    g >= o.length && (g = o.length - 1), (c || l.initialSlide || 0) === (f || 0) && i && n.emit("beforeSlideChangeStart");
    const T = -o[g];
    if (n.updateProgress(T), l.normalizeSlideIndex)
        for (let b = 0; b < d.length; b += 1) {
            const x = -Math.floor(T * 100),
                $ = Math.floor(d[b] * 100),
                I = Math.floor(d[b + 1] * 100);
            typeof d[b + 1] != "undefined" ? x >= $ && x < I - (I - $) / 2 ? a = b : x >= $ && x < I && (a = b + 1) : x >= $ && (a = b)
        }
    if (n.initialized && a !== c && (!n.allowSlideNext && T < n.translate && T < n.minTranslate() || !n.allowSlidePrev && T > n.translate && T > n.maxTranslate() && (c || 0) !== a)) return !1;
    let w;
    if (a > c ? w = "next" : a < c ? w = "prev" : w = "reset", u && -T === n.translate || !u && T === n.translate) return n.updateActiveIndex(a), l.autoHeight && n.updateAutoHeight(), n.updateSlidesClasses(), l.effect !== "slide" && n.setTranslate(T), w !== "reset" && (n.transitionStart(i, w), n.transitionEnd(i, w)), !1;
    if (l.cssMode) {
        const b = n.isHorizontal(),
            x = u ? T : -T;
        if (t === 0) {
            const $ = n.virtual && n.params.virtual.enabled;
            $ && (n.wrapperEl.style.scrollSnapType = "none", n._immediateVirtual = !0), h[b ? "scrollLeft" : "scrollTop"] = x, $ && requestAnimationFrame(() => {
                n.wrapperEl.style.scrollSnapType = "", n._swiperImmediateVirtual = !1
            })
        } else {
            if (!n.support.smoothScroll) return re({
                swiper: n,
                targetPosition: x,
                side: b ? "left" : "top"
            }), !0;
            h.scrollTo({
                [b ? "left" : "top"]: x,
                behavior: "smooth"
            })
        }
        return !0
    }
    return n.setTransition(t), n.setTranslate(T), n.updateActiveIndex(a), n.updateSlidesClasses(), n.emit("beforeTransitionStart", t, s), n.transitionStart(i, w), t === 0 ? n.transitionEnd(i, w) : n.animating || (n.animating = !0, n.onSlideToWrapperTransitionEnd || (n.onSlideToWrapperTransitionEnd = function(x) {
        !n || n.destroyed || x.target === this && (n.$wrapperEl[0].removeEventListener("transitionend", n.onSlideToWrapperTransitionEnd), n.$wrapperEl[0].removeEventListener("webkitTransitionEnd", n.onSlideToWrapperTransitionEnd), n.onSlideToWrapperTransitionEnd = null, delete n.onSlideToWrapperTransitionEnd, n.transitionEnd(i, w))
    }), n.$wrapperEl[0].addEventListener("transitionend", n.onSlideToWrapperTransitionEnd), n.$wrapperEl[0].addEventListener("webkitTransitionEnd", n.onSlideToWrapperTransitionEnd)), !0
}

function zt(e, t, i, s) {
    if (e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), i === void 0 && (i = !0), typeof e == "string") {
        const a = parseInt(e, 10);
        if (!isFinite(a)) throw new Error(`The passed-in 'index' (string) couldn't be converted to 'number'. [${e}] given.`);
        e = a
    }
    const r = this;
    let n = e;
    return r.params.loop && (n += r.loopedSlides), r.slideTo(n, t, i, s)
}

function At(e, t, i) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const s = this,
        {
            animating: r,
            enabled: n,
            params: a
        } = s;
    if (!n) return s;
    let l = a.slidesPerGroup;
    a.slidesPerView === "auto" && a.slidesPerGroup === 1 && a.slidesPerGroupAuto && (l = Math.max(s.slidesPerViewDynamic("current", !0), 1));
    const o = s.activeIndex < a.slidesPerGroupSkip ? 1 : l;
    if (a.loop) {
        if (r && a.loopPreventsSlide) return !1;
        s.loopFix(), s._clientLeft = s.$wrapperEl[0].clientLeft
    }
    return a.rewind && s.isEnd ? s.slideTo(0, e, t, i) : s.slideTo(s.activeIndex + o, e, t, i)
}

function Dt(e, t, i) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const s = this,
        {
            params: r,
            animating: n,
            snapGrid: a,
            slidesGrid: l,
            rtlTranslate: o,
            enabled: d
        } = s;
    if (!d) return s;
    if (r.loop) {
        if (n && r.loopPreventsSlide) return !1;
        s.loopFix(), s._clientLeft = s.$wrapperEl[0].clientLeft
    }
    const f = o ? s.translate : -s.translate;

    function c(g) {
        return g < 0 ? -Math.floor(Math.abs(g)) : Math.floor(g)
    }
    const u = c(f),
        h = a.map(g => c(g));
    let m = a[h.indexOf(u) - 1];
    if (typeof m == "undefined" && r.cssMode) {
        let g;
        a.forEach((T, w) => {
            u >= T && (g = w)
        }), typeof g != "undefined" && (m = a[g > 0 ? g - 1 : g])
    }
    let v = 0;
    if (typeof m != "undefined" && (v = l.indexOf(m), v < 0 && (v = s.activeIndex - 1), r.slidesPerView === "auto" && r.slidesPerGroup === 1 && r.slidesPerGroupAuto && (v = v - s.slidesPerViewDynamic("previous", !0) + 1, v = Math.max(v, 0))), r.rewind && s.isBeginning) {
        const g = s.params.virtual && s.params.virtual.enabled && s.virtual ? s.virtual.slides.length - 1 : s.slides.length - 1;
        return s.slideTo(g, e, t, i)
    }
    return s.slideTo(v, e, t, i)
}

function Gt(e, t, i) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const s = this;
    return s.slideTo(s.activeIndex, e, t, i)
}

function Nt(e, t, i, s) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0), s === void 0 && (s = .5);
    const r = this;
    let n = r.activeIndex;
    const a = Math.min(r.params.slidesPerGroupSkip, n),
        l = a + Math.floor((n - a) / r.params.slidesPerGroup),
        o = r.rtlTranslate ? r.translate : -r.translate;
    if (o >= r.snapGrid[l]) {
        const d = r.snapGrid[l],
            f = r.snapGrid[l + 1];
        o - d > (f - d) * s && (n += r.params.slidesPerGroup)
    } else {
        const d = r.snapGrid[l - 1],
            f = r.snapGrid[l];
        o - d <= (f - d) * s && (n -= r.params.slidesPerGroup)
    }
    return n = Math.max(n, 0), n = Math.min(n, r.slidesGrid.length - 1), r.slideTo(n, e, t, i)
}

function Bt() {
    const e = this,
        {
            params: t,
            $wrapperEl: i
        } = e,
        s = t.slidesPerView === "auto" ? e.slidesPerViewDynamic() : t.slidesPerView;
    let r = e.clickedIndex,
        n;
    if (t.loop) {
        if (e.animating) return;
        n = parseInt(p(e.clickedSlide).attr("data-swiper-slide-index"), 10), t.centeredSlides ? r < e.loopedSlides - s / 2 || r > e.slides.length - e.loopedSlides + s / 2 ? (e.loopFix(), r = i.children(`.${t.slideClass}[data-swiper-slide-index="${n}"]:not(.${t.slideDuplicateClass})`).eq(0).index(), j(() => {
            e.slideTo(r)
        })) : e.slideTo(r) : r > e.slides.length - s ? (e.loopFix(), r = i.children(`.${t.slideClass}[data-swiper-slide-index="${n}"]:not(.${t.slideDuplicateClass})`).eq(0).index(), j(() => {
            e.slideTo(r)
        })) : e.slideTo(r)
    } else e.slideTo(r)
}
var Vt = {
    slideTo: kt,
    slideToLoop: zt,
    slideNext: At,
    slidePrev: Dt,
    slideReset: Gt,
    slideToClosest: Nt,
    slideToClickedSlide: Bt
};

function Ht() {
    const e = this,
        t = L(),
        {
            params: i,
            $wrapperEl: s
        } = e,
        r = s.children().length > 0 ? p(s.children()[0].parentNode) : s;
    r.children(`.${i.slideClass}.${i.slideDuplicateClass}`).remove();
    let n = r.children(`.${i.slideClass}`);
    if (i.loopFillGroupWithBlank) {
        const o = i.slidesPerGroup - n.length % i.slidesPerGroup;
        if (o !== i.slidesPerGroup) {
            for (let d = 0; d < o; d += 1) {
                const f = p(t.createElement("div")).addClass(`${i.slideClass} ${i.slideBlankClass}`);
                r.append(f)
            }
            n = r.children(`.${i.slideClass}`)
        }
    }
    i.slidesPerView === "auto" && !i.loopedSlides && (i.loopedSlides = n.length), e.loopedSlides = Math.ceil(parseFloat(i.loopedSlides || i.slidesPerView, 10)), e.loopedSlides += i.loopAdditionalSlides, e.loopedSlides > n.length && e.params.loopedSlidesLimit && (e.loopedSlides = n.length);
    const a = [],
        l = [];
    n.each((o, d) => {
        p(o).attr("data-swiper-slide-index", d)
    });
    for (let o = 0; o < e.loopedSlides; o += 1) {
        const d = o - Math.floor(o / n.length) * n.length;
        l.push(n.eq(d)[0]), a.unshift(n.eq(n.length - d - 1)[0])
    }
    for (let o = 0; o < l.length; o += 1) r.append(p(l[o].cloneNode(!0)).addClass(i.slideDuplicateClass));
    for (let o = a.length - 1; o >= 0; o -= 1) r.prepend(p(a[o].cloneNode(!0)).addClass(i.slideDuplicateClass))
}

function _t() {
    const e = this;
    e.emit("beforeLoopFix");
    const {
        activeIndex: t,
        slides: i,
        loopedSlides: s,
        allowSlidePrev: r,
        allowSlideNext: n,
        snapGrid: a,
        rtlTranslate: l
    } = e;
    let o;
    e.allowSlidePrev = !0, e.allowSlideNext = !0;
    const f = -a[t] - e.getTranslate();
    t < s ? (o = i.length - s * 3 + t, o += s, e.slideTo(o, 0, !1, !0) && f !== 0 && e.setTranslate((l ? -e.translate : e.translate) - f)) : t >= i.length - s && (o = -i.length + t + s, o += s, e.slideTo(o, 0, !1, !0) && f !== 0 && e.setTranslate((l ? -e.translate : e.translate) - f)), e.allowSlidePrev = r, e.allowSlideNext = n, e.emit("loopFix")
}

function Ft() {
    const e = this,
        {
            $wrapperEl: t,
            params: i,
            slides: s
        } = e;
    t.children(`.${i.slideClass}.${i.slideDuplicateClass},.${i.slideClass}.${i.slideBlankClass}`).remove(), s.removeAttr("data-swiper-slide-index")
}
var Rt = {
    loopCreate: Ht,
    loopFix: _t,
    loopDestroy: Ft
};

function Wt(e) {
    const t = this;
    if (t.support.touch || !t.params.simulateTouch || t.params.watchOverflow && t.isLocked || t.params.cssMode) return;
    const i = t.params.touchEventsTarget === "container" ? t.el : t.wrapperEl;
    i.style.cursor = "move", i.style.cursor = e ? "grabbing" : "grab"
}

function jt() {
    const e = this;
    e.support.touch || e.params.watchOverflow && e.isLocked || e.params.cssMode || (e[e.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "")
}
var qt = {
    setGrabCursor: Wt,
    unsetGrabCursor: jt
};

function Xt(e, t) {
    t === void 0 && (t = this);

    function i(s) {
        if (!s || s === L() || s === C()) return null;
        s.assignedSlot && (s = s.assignedSlot);
        const r = s.closest(e);
        return !r && !s.getRootNode ? null : r || i(s.getRootNode().host)
    }
    return i(t)
}

function Yt(e) {
    const t = this,
        i = L(),
        s = C(),
        r = t.touchEventsData,
        {
            params: n,
            touches: a,
            enabled: l
        } = t;
    if (!l || t.animating && n.preventInteractionOnTransition) return;
    !t.animating && n.cssMode && n.loop && t.loopFix();
    let o = e;
    o.originalEvent && (o = o.originalEvent);
    let d = p(o.target);
    if (n.touchEventsTarget === "wrapper" && !d.closest(t.wrapperEl).length || (r.isTouchEvent = o.type === "touchstart", !r.isTouchEvent && "which" in o && o.which === 3) || !r.isTouchEvent && "button" in o && o.button > 0 || r.isTouched && r.isMoved) return;
    !!n.noSwipingClass && n.noSwipingClass !== "" && o.target && o.target.shadowRoot && e.path && e.path[0] && (d = p(e.path[0]));
    const c = n.noSwipingSelector ? n.noSwipingSelector : `.${n.noSwipingClass}`,
        u = !!(o.target && o.target.shadowRoot);
    if (n.noSwiping && (u ? Xt(c, d[0]) : d.closest(c)[0])) {
        t.allowClick = !0;
        return
    }
    if (n.swipeHandler && !d.closest(n.swipeHandler)[0]) return;
    a.currentX = o.type === "touchstart" ? o.targetTouches[0].pageX : o.pageX, a.currentY = o.type === "touchstart" ? o.targetTouches[0].pageY : o.pageY;
    const h = a.currentX,
        m = a.currentY,
        v = n.edgeSwipeDetection || n.iOSEdgeSwipeDetection,
        g = n.edgeSwipeThreshold || n.iOSEdgeSwipeThreshold;
    if (v && (h <= g || h >= s.innerWidth - g))
        if (v === "prevent") e.preventDefault();
        else return;
    if (Object.assign(r, {
            isTouched: !0,
            isMoved: !1,
            allowTouchCallbacks: !0,
            isScrolling: void 0,
            startMoving: void 0
        }), a.startX = h, a.startY = m, r.touchStartTime = A(), t.allowClick = !0, t.updateSize(), t.swipeDirection = void 0, n.threshold > 0 && (r.allowThresholdMove = !1), o.type !== "touchstart") {
        let T = !0;
        d.is(r.focusableElements) && (T = !1, d[0].nodeName === "SELECT" && (r.isTouched = !1)), i.activeElement && p(i.activeElement).is(r.focusableElements) && i.activeElement !== d[0] && i.activeElement.blur();
        const w = T && t.allowTouchMove && n.touchStartPreventDefault;
        (n.touchStartForcePreventDefault || w) && !d[0].isContentEditable && o.preventDefault()
    }
    t.params.freeMode && t.params.freeMode.enabled && t.freeMode && t.animating && !n.cssMode && t.freeMode.onTouchStart(), t.emit("touchStart", o)
}

function Kt(e) {
    const t = L(),
        i = this,
        s = i.touchEventsData,
        {
            params: r,
            touches: n,
            rtlTranslate: a,
            enabled: l
        } = i;
    if (!l) return;
    let o = e;
    if (o.originalEvent && (o = o.originalEvent), !s.isTouched) {
        s.startMoving && s.isScrolling && i.emit("touchMoveOpposite", o);
        return
    }
    if (s.isTouchEvent && o.type !== "touchmove") return;
    const d = o.type === "touchmove" && o.targetTouches && (o.targetTouches[0] || o.changedTouches[0]),
        f = o.type === "touchmove" ? d.pageX : o.pageX,
        c = o.type === "touchmove" ? d.pageY : o.pageY;
    if (o.preventedByNestedSwiper) {
        n.startX = f, n.startY = c;
        return
    }
    if (!i.allowTouchMove) {
        p(o.target).is(s.focusableElements) || (i.allowClick = !1), s.isTouched && (Object.assign(n, {
            startX: f,
            startY: c,
            currentX: f,
            currentY: c
        }), s.touchStartTime = A());
        return
    }
    if (s.isTouchEvent && r.touchReleaseOnEdges && !r.loop) {
        if (i.isVertical()) {
            if (c < n.startY && i.translate <= i.maxTranslate() || c > n.startY && i.translate >= i.minTranslate()) {
                s.isTouched = !1, s.isMoved = !1;
                return
            }
        } else if (f < n.startX && i.translate <= i.maxTranslate() || f > n.startX && i.translate >= i.minTranslate()) return
    }
    if (s.isTouchEvent && t.activeElement && o.target === t.activeElement && p(o.target).is(s.focusableElements)) {
        s.isMoved = !0, i.allowClick = !1;
        return
    }
    if (s.allowTouchCallbacks && i.emit("touchMove", o), o.targetTouches && o.targetTouches.length > 1) return;
    n.currentX = f, n.currentY = c;
    const u = n.currentX - n.startX,
        h = n.currentY - n.startY;
    if (i.params.threshold && Math.sqrt(u ** 2 + h ** 2) < i.params.threshold) return;
    if (typeof s.isScrolling == "undefined") {
        let T;
        i.isHorizontal() && n.currentY === n.startY || i.isVertical() && n.currentX === n.startX ? s.isScrolling = !1 : u * u + h * h >= 25 && (T = Math.atan2(Math.abs(h), Math.abs(u)) * 180 / Math.PI, s.isScrolling = i.isHorizontal() ? T > r.touchAngle : 90 - T > r.touchAngle)
    }
    if (s.isScrolling && i.emit("touchMoveOpposite", o), typeof s.startMoving == "undefined" && (n.currentX !== n.startX || n.currentY !== n.startY) && (s.startMoving = !0), s.isScrolling) {
        s.isTouched = !1;
        return
    }
    if (!s.startMoving) return;
    i.allowClick = !1, !r.cssMode && o.cancelable && o.preventDefault(), r.touchMoveStopPropagation && !r.nested && o.stopPropagation(), s.isMoved || (r.loop && !r.cssMode && i.loopFix(), s.startTranslate = i.getTranslate(), i.setTransition(0), i.animating && i.$wrapperEl.trigger("webkitTransitionEnd transitionend"), s.allowMomentumBounce = !1, r.grabCursor && (i.allowSlideNext === !0 || i.allowSlidePrev === !0) && i.setGrabCursor(!0), i.emit("sliderFirstMove", o)), i.emit("sliderMove", o), s.isMoved = !0;
    let m = i.isHorizontal() ? u : h;
    n.diff = m, m *= r.touchRatio, a && (m = -m), i.swipeDirection = m > 0 ? "prev" : "next", s.currentTranslate = m + s.startTranslate;
    let v = !0,
        g = r.resistanceRatio;
    if (r.touchReleaseOnEdges && (g = 0), m > 0 && s.currentTranslate > i.minTranslate() ? (v = !1, r.resistance && (s.currentTranslate = i.minTranslate() - 1 + (-i.minTranslate() + s.startTranslate + m) ** g)) : m < 0 && s.currentTranslate < i.maxTranslate() && (v = !1, r.resistance && (s.currentTranslate = i.maxTranslate() + 1 - (i.maxTranslate() - s.startTranslate - m) ** g)), v && (o.preventedByNestedSwiper = !0), !i.allowSlideNext && i.swipeDirection === "next" && s.currentTranslate < s.startTranslate && (s.currentTranslate = s.startTranslate), !i.allowSlidePrev && i.swipeDirection === "prev" && s.currentTranslate > s.startTranslate && (s.currentTranslate = s.startTranslate), !i.allowSlidePrev && !i.allowSlideNext && (s.currentTranslate = s.startTranslate), r.threshold > 0)
        if (Math.abs(m) > r.threshold || s.allowThresholdMove) {
            if (!s.allowThresholdMove) {
                s.allowThresholdMove = !0, n.startX = n.currentX, n.startY = n.currentY, s.currentTranslate = s.startTranslate, n.diff = i.isHorizontal() ? n.currentX - n.startX : n.currentY - n.startY;
                return
            }
        } else {
            s.currentTranslate = s.startTranslate;
            return
        }!r.followFinger || r.cssMode || ((r.freeMode && r.freeMode.enabled && i.freeMode || r.watchSlidesProgress) && (i.updateActiveIndex(), i.updateSlidesClasses()), i.params.freeMode && r.freeMode.enabled && i.freeMode && i.freeMode.onTouchMove(), i.updateProgress(s.currentTranslate), i.setTranslate(s.currentTranslate))
}

function Ut(e) {
    const t = this,
        i = t.touchEventsData,
        {
            params: s,
            touches: r,
            rtlTranslate: n,
            slidesGrid: a,
            enabled: l
        } = t;
    if (!l) return;
    let o = e;
    if (o.originalEvent && (o = o.originalEvent), i.allowTouchCallbacks && t.emit("touchEnd", o), i.allowTouchCallbacks = !1, !i.isTouched) {
        i.isMoved && s.grabCursor && t.setGrabCursor(!1), i.isMoved = !1, i.startMoving = !1;
        return
    }
    s.grabCursor && i.isMoved && i.isTouched && (t.allowSlideNext === !0 || t.allowSlidePrev === !0) && t.setGrabCursor(!1);
    const d = A(),
        f = d - i.touchStartTime;
    if (t.allowClick) {
        const w = o.path || o.composedPath && o.composedPath();
        t.updateClickedSlide(w && w[0] || o.target), t.emit("tap click", o), f < 300 && d - i.lastClickTime < 300 && t.emit("doubleTap doubleClick", o)
    }
    if (i.lastClickTime = A(), j(() => {
            t.destroyed || (t.allowClick = !0)
        }), !i.isTouched || !i.isMoved || !t.swipeDirection || r.diff === 0 || i.currentTranslate === i.startTranslate) {
        i.isTouched = !1, i.isMoved = !1, i.startMoving = !1;
        return
    }
    i.isTouched = !1, i.isMoved = !1, i.startMoving = !1;
    let c;
    if (s.followFinger ? c = n ? t.translate : -t.translate : c = -i.currentTranslate, s.cssMode) return;
    if (t.params.freeMode && s.freeMode.enabled) {
        t.freeMode.onTouchEnd({
            currentPos: c
        });
        return
    }
    let u = 0,
        h = t.slidesSizesGrid[0];
    for (let w = 0; w < a.length; w += w < s.slidesPerGroupSkip ? 1 : s.slidesPerGroup) {
        const b = w < s.slidesPerGroupSkip - 1 ? 1 : s.slidesPerGroup;
        typeof a[w + b] != "undefined" ? c >= a[w] && c < a[w + b] && (u = w, h = a[w + b] - a[w]) : c >= a[w] && (u = w, h = a[a.length - 1] - a[a.length - 2])
    }
    let m = null,
        v = null;
    s.rewind && (t.isBeginning ? v = t.params.virtual && t.params.virtual.enabled && t.virtual ? t.virtual.slides.length - 1 : t.slides.length - 1 : t.isEnd && (m = 0));
    const g = (c - a[u]) / h,
        T = u < s.slidesPerGroupSkip - 1 ? 1 : s.slidesPerGroup;
    if (f > s.longSwipesMs) {
        if (!s.longSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.swipeDirection === "next" && (g >= s.longSwipesRatio ? t.slideTo(s.rewind && t.isEnd ? m : u + T) : t.slideTo(u)), t.swipeDirection === "prev" && (g > 1 - s.longSwipesRatio ? t.slideTo(u + T) : v !== null && g < 0 && Math.abs(g) > s.longSwipesRatio ? t.slideTo(v) : t.slideTo(u))
    } else {
        if (!s.shortSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.navigation && (o.target === t.navigation.nextEl || o.target === t.navigation.prevEl) ? o.target === t.navigation.nextEl ? t.slideTo(u + T) : t.slideTo(u) : (t.swipeDirection === "next" && t.slideTo(m !== null ? m : u + T), t.swipeDirection === "prev" && t.slideTo(v !== null ? v : u))
    }
}

function Z() {
    const e = this,
        {
            params: t,
            el: i
        } = e;
    if (i && i.offsetWidth === 0) return;
    t.breakpoints && e.setBreakpoint();
    const {
        allowSlideNext: s,
        allowSlidePrev: r,
        snapGrid: n
    } = e;
    e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), e.updateSlidesClasses(), (t.slidesPerView === "auto" || t.slidesPerView > 1) && e.isEnd && !e.isBeginning && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0), e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.run(), e.allowSlidePrev = r, e.allowSlideNext = s, e.params.watchOverflow && n !== e.snapGrid && e.checkOverflow()
}

function Jt(e) {
    const t = this;
    !t.enabled || t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation()))
}

function Qt() {
    const e = this,
        {
            wrapperEl: t,
            rtlTranslate: i,
            enabled: s
        } = e;
    if (!s) return;
    e.previousTranslate = e.translate, e.isHorizontal() ? e.translate = -t.scrollLeft : e.translate = -t.scrollTop, e.translate === 0 && (e.translate = 0), e.updateActiveIndex(), e.updateSlidesClasses();
    let r;
    const n = e.maxTranslate() - e.minTranslate();
    n === 0 ? r = 0 : r = (e.translate - e.minTranslate()) / n, r !== e.progress && e.updateProgress(i ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1)
}
let ee = !1;

function Zt() {}
const le = (e, t) => {
    const i = L(),
        {
            params: s,
            touchEvents: r,
            el: n,
            wrapperEl: a,
            device: l,
            support: o
        } = e,
        d = !!s.nested,
        f = t === "on" ? "addEventListener" : "removeEventListener",
        c = t;
    if (!o.touch) n[f](r.start, e.onTouchStart, !1), i[f](r.move, e.onTouchMove, d), i[f](r.end, e.onTouchEnd, !1);
    else {
        const u = r.start === "touchstart" && o.passiveListener && s.passiveListeners ? {
            passive: !0,
            capture: !1
        } : !1;
        n[f](r.start, e.onTouchStart, u), n[f](r.move, e.onTouchMove, o.passiveListener ? {
            passive: !1,
            capture: d
        } : d), n[f](r.end, e.onTouchEnd, u), r.cancel && n[f](r.cancel, e.onTouchEnd, u)
    }(s.preventClicks || s.preventClicksPropagation) && n[f]("click", e.onClick, !0), s.cssMode && a[f]("scroll", e.onScroll), s.updateOnWindowResize ? e[c](l.ios || l.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", Z, !0) : e[c]("observerUpdate", Z, !0)
};

function ei() {
    const e = this,
        t = L(),
        {
            params: i,
            support: s
        } = e;
    e.onTouchStart = Yt.bind(e), e.onTouchMove = Kt.bind(e), e.onTouchEnd = Ut.bind(e), i.cssMode && (e.onScroll = Qt.bind(e)), e.onClick = Jt.bind(e), s.touch && !ee && (t.addEventListener("touchstart", Zt), ee = !0), le(e, "on")
}

function ti() {
    le(this, "off")
}
var ii = {
    attachEvents: ei,
    detachEvents: ti
};
const te = (e, t) => e.grid && t.grid && t.grid.rows > 1;

function si() {
    const e = this,
        {
            activeIndex: t,
            initialized: i,
            loopedSlides: s = 0,
            params: r,
            $el: n
        } = e,
        a = r.breakpoints;
    if (!a || a && Object.keys(a).length === 0) return;
    const l = e.getBreakpoint(a, e.params.breakpointsBase, e.el);
    if (!l || e.currentBreakpoint === l) return;
    const d = (l in a ? a[l] : void 0) || e.originalParams,
        f = te(e, r),
        c = te(e, d),
        u = r.enabled;
    f && !c ? (n.removeClass(`${r.containerModifierClass}grid ${r.containerModifierClass}grid-column`), e.emitContainerClasses()) : !f && c && (n.addClass(`${r.containerModifierClass}grid`), (d.grid.fill && d.grid.fill === "column" || !d.grid.fill && r.grid.fill === "column") && n.addClass(`${r.containerModifierClass}grid-column`), e.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach(g => {
        const T = r[g] && r[g].enabled,
            w = d[g] && d[g].enabled;
        T && !w && e[g].disable(), !T && w && e[g].enable()
    });
    const h = d.direction && d.direction !== r.direction,
        m = r.loop && (d.slidesPerView !== r.slidesPerView || h);
    h && i && e.changeDirection(), P(e.params, d);
    const v = e.params.enabled;
    Object.assign(e, {
        allowTouchMove: e.params.allowTouchMove,
        allowSlideNext: e.params.allowSlideNext,
        allowSlidePrev: e.params.allowSlidePrev
    }), u && !v ? e.disable() : !u && v && e.enable(), e.currentBreakpoint = l, e.emit("_beforeBreakpoint", d), m && i && (e.loopDestroy(), e.loopCreate(), e.updateSlides(), e.slideTo(t - s + e.loopedSlides, 0, !1)), e.emit("breakpoint", d)
}

function ni(e, t, i) {
    if (t === void 0 && (t = "window"), !e || t === "container" && !i) return;
    let s = !1;
    const r = C(),
        n = t === "window" ? r.innerHeight : i.clientHeight,
        a = Object.keys(e).map(l => {
            if (typeof l == "string" && l.indexOf("@") === 0) {
                const o = parseFloat(l.substr(1));
                return {
                    value: n * o,
                    point: l
                }
            }
            return {
                value: l,
                point: l
            }
        });
    a.sort((l, o) => parseInt(l.value, 10) - parseInt(o.value, 10));
    for (let l = 0; l < a.length; l += 1) {
        const {
            point: o,
            value: d
        } = a[l];
        t === "window" ? r.matchMedia(`(min-width: ${d}px)`).matches && (s = o) : d <= i.clientWidth && (s = o)
    }
    return s || "max"
}
var ri = {
    setBreakpoint: si,
    getBreakpoint: ni
};

function ai(e, t) {
    const i = [];
    return e.forEach(s => {
        typeof s == "object" ? Object.keys(s).forEach(r => {
            s[r] && i.push(t + r)
        }) : typeof s == "string" && i.push(t + s)
    }), i
}

function oi() {
    const e = this,
        {
            classNames: t,
            params: i,
            rtl: s,
            $el: r,
            device: n,
            support: a
        } = e,
        l = ai(["initialized", i.direction, {
            "pointer-events": !a.touch
        }, {
            "free-mode": e.params.freeMode && i.freeMode.enabled
        }, {
            autoheight: i.autoHeight
        }, {
            rtl: s
        }, {
            grid: i.grid && i.grid.rows > 1
        }, {
            "grid-column": i.grid && i.grid.rows > 1 && i.grid.fill === "column"
        }, {
            android: n.android
        }, {
            ios: n.ios
        }, {
            "css-mode": i.cssMode
        }, {
            centered: i.cssMode && i.centeredSlides
        }, {
            "watch-progress": i.watchSlidesProgress
        }], i.containerModifierClass);
    t.push(...l), r.addClass([...t].join(" ")), e.emitContainerClasses()
}

function li() {
    const e = this,
        {
            $el: t,
            classNames: i
        } = e;
    t.removeClass(i.join(" ")), e.emitContainerClasses()
}
var di = {
    addClasses: oi,
    removeClasses: li
};

function fi(e, t, i, s, r, n) {
    const a = C();
    let l;

    function o() {
        n && n()
    }!p(e).parent("picture")[0] && (!e.complete || !r) && t ? (l = new a.Image, l.onload = o, l.onerror = o, s && (l.sizes = s), i && (l.srcset = i), t && (l.src = t)) : o()
}

function ci() {
    const e = this;
    e.imagesToLoad = e.$el.find("img");

    function t() {
        typeof e == "undefined" || e === null || !e || e.destroyed || (e.imagesLoaded !== void 0 && (e.imagesLoaded += 1), e.imagesLoaded === e.imagesToLoad.length && (e.params.updateOnImagesReady && e.update(), e.emit("imagesReady")))
    }
    for (let i = 0; i < e.imagesToLoad.length; i += 1) {
        const s = e.imagesToLoad[i];
        e.loadImage(s, s.currentSrc || s.getAttribute("src"), s.srcset || s.getAttribute("srcset"), s.sizes || s.getAttribute("sizes"), !0, t)
    }
}
var ui = {
    loadImage: fi,
    preloadImages: ci
};

function pi() {
    const e = this,
        {
            isLocked: t,
            params: i
        } = e,
        {
            slidesOffsetBefore: s
        } = i;
    if (s) {
        const r = e.slides.length - 1,
            n = e.slidesGrid[r] + e.slidesSizesGrid[r] + s * 2;
        e.isLocked = e.size > n
    } else e.isLocked = e.snapGrid.length === 1;
    i.allowSlideNext === !0 && (e.allowSlideNext = !e.isLocked), i.allowSlidePrev === !0 && (e.allowSlidePrev = !e.isLocked), t && t !== e.isLocked && (e.isEnd = !1), t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock")
}
var hi = {
        checkOverflow: pi
    },
    ie = {
        init: !0,
        direction: "horizontal",
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 0,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        preloadImages: !0,
        updateOnImagesReady: !0,
        loop: !1,
        loopAdditionalSlides: 0,
        loopedSlides: null,
        loopedSlidesLimit: !0,
        loopFillGroupWithBlank: !1,
        loopPreventsSlide: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideBlankClass: "swiper-slide-invisible-blank",
        slideActiveClass: "swiper-slide-active",
        slideDuplicateActiveClass: "swiper-slide-duplicate-active",
        slideVisibleClass: "swiper-slide-visible",
        slideDuplicateClass: "swiper-slide-duplicate",
        slideNextClass: "swiper-slide-next",
        slideDuplicateNextClass: "swiper-slide-duplicate-next",
        slidePrevClass: "swiper-slide-prev",
        slideDuplicatePrevClass: "swiper-slide-duplicate-prev",
        wrapperClass: "swiper-wrapper",
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

function mi(e, t) {
    return function(s) {
        s === void 0 && (s = {});
        const r = Object.keys(s)[0],
            n = s[r];
        if (typeof n != "object" || n === null) {
            P(t, s);
            return
        }
        if (["navigation", "pagination", "scrollbar"].indexOf(r) >= 0 && e[r] === !0 && (e[r] = {
                auto: !0
            }), !(r in e && "enabled" in n)) {
            P(t, s);
            return
        }
        e[r] === !0 && (e[r] = {
            enabled: !0
        }), typeof e[r] == "object" && !("enabled" in e[r]) && (e[r].enabled = !0), e[r] || (e[r] = {
            enabled: !1
        }), P(t, s)
    }
}
const R = {
        eventsEmitter: ct,
        update: bt,
        translate: Pt,
        transition: It,
        slide: Vt,
        loop: Rt,
        grabCursor: qt,
        events: ii,
        breakpoints: ri,
        checkOverflow: hi,
        classes: di,
        images: ui
    },
    W = {};
class O {
    constructor() {
        let t, i;
        for (var s = arguments.length, r = new Array(s), n = 0; n < s; n++) r[n] = arguments[n];
        if (r.length === 1 && r[0].constructor && Object.prototype.toString.call(r[0]).slice(8, -1) === "Object" ? i = r[0] : [t, i] = r, i || (i = {}), i = P({}, i), t && !i.el && (i.el = t), i.el && p(i.el).length > 1) {
            const d = [];
            return p(i.el).each(f => {
                const c = P({}, i, {
                    el: f
                });
                d.push(new O(c))
            }), d
        }
        const a = this;
        a.__swiper__ = !0, a.support = ae(), a.device = at({
            userAgent: i.userAgent
        }), a.browser = lt(), a.eventsListeners = {}, a.eventsAnyListeners = [], a.modules = [...a.__modules__], i.modules && Array.isArray(i.modules) && a.modules.push(...i.modules);
        const l = {};
        a.modules.forEach(d => {
            d({
                swiper: a,
                extendParams: mi(i, l),
                on: a.on.bind(a),
                once: a.once.bind(a),
                off: a.off.bind(a),
                emit: a.emit.bind(a)
            })
        });
        const o = P({}, ie, l);
        return a.params = P({}, o, W, i), a.originalParams = P({}, a.params), a.passedParams = P({}, i), a.params && a.params.on && Object.keys(a.params.on).forEach(d => {
            a.on(d, a.params.on[d])
        }), a.params && a.params.onAny && a.onAny(a.params.onAny), a.$ = p, Object.assign(a, {
            enabled: a.params.enabled,
            el: t,
            classNames: [],
            slides: p(),
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal() {
                return a.params.direction === "horizontal"
            },
            isVertical() {
                return a.params.direction === "vertical"
            },
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            allowSlideNext: a.params.allowSlideNext,
            allowSlidePrev: a.params.allowSlidePrev,
            touchEvents: function() {
                const f = ["touchstart", "touchmove", "touchend", "touchcancel"],
                    c = ["pointerdown", "pointermove", "pointerup"];
                return a.touchEventsTouch = {
                    start: f[0],
                    move: f[1],
                    end: f[2],
                    cancel: f[3]
                }, a.touchEventsDesktop = {
                    start: c[0],
                    move: c[1],
                    end: c[2]
                }, a.support.touch || !a.params.simulateTouch ? a.touchEventsTouch : a.touchEventsDesktop
            }(),
            touchEventsData: {
                isTouched: void 0,
                isMoved: void 0,
                allowTouchCallbacks: void 0,
                touchStartTime: void 0,
                isScrolling: void 0,
                currentTranslate: void 0,
                startTranslate: void 0,
                allowThresholdMove: void 0,
                focusableElements: a.params.focusableElements,
                lastClickTime: A(),
                clickTimeout: void 0,
                velocities: [],
                allowMomentumBounce: void 0,
                isTouchEvent: void 0,
                startMoving: void 0
            },
            allowClick: !0,
            allowTouchMove: a.params.allowTouchMove,
            touches: {
                startX: 0,
                startY: 0,
                currentX: 0,
                currentY: 0,
                diff: 0
            },
            imagesToLoad: [],
            imagesLoaded: 0
        }), a.emit("_swiper"), a.params.init && a.init(), a
    }
    enable() {
        const t = this;
        t.enabled || (t.enabled = !0, t.params.grabCursor && t.setGrabCursor(), t.emit("enable"))
    }
    disable() {
        const t = this;
        !t.enabled || (t.enabled = !1, t.params.grabCursor && t.unsetGrabCursor(), t.emit("disable"))
    }
    setProgress(t, i) {
        const s = this;
        t = Math.min(Math.max(t, 0), 1);
        const r = s.minTranslate(),
            a = (s.maxTranslate() - r) * t + r;
        s.translateTo(a, typeof i == "undefined" ? 0 : i), s.updateActiveIndex(), s.updateSlidesClasses()
    }
    emitContainerClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const i = t.el.className.split(" ").filter(s => s.indexOf("swiper") === 0 || s.indexOf(t.params.containerModifierClass) === 0);
        t.emit("_containerClasses", i.join(" "))
    }
    getSlideClasses(t) {
        const i = this;
        return i.destroyed ? "" : t.className.split(" ").filter(s => s.indexOf("swiper-slide") === 0 || s.indexOf(i.params.slideClass) === 0).join(" ")
    }
    emitSlidesClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const i = [];
        t.slides.each(s => {
            const r = t.getSlideClasses(s);
            i.push({
                slideEl: s,
                classNames: r
            }), t.emit("_slideClass", s, r)
        }), t.emit("_slideClasses", i)
    }
    slidesPerViewDynamic(t, i) {
        t === void 0 && (t = "current"), i === void 0 && (i = !1);
        const s = this,
            {
                params: r,
                slides: n,
                slidesGrid: a,
                slidesSizesGrid: l,
                size: o,
                activeIndex: d
            } = s;
        let f = 1;
        if (r.centeredSlides) {
            let c = n[d].swiperSlideSize,
                u;
            for (let h = d + 1; h < n.length; h += 1) n[h] && !u && (c += n[h].swiperSlideSize, f += 1, c > o && (u = !0));
            for (let h = d - 1; h >= 0; h -= 1) n[h] && !u && (c += n[h].swiperSlideSize, f += 1, c > o && (u = !0))
        } else if (t === "current")
            for (let c = d + 1; c < n.length; c += 1)(i ? a[c] + l[c] - a[d] < o : a[c] - a[d] < o) && (f += 1);
        else
            for (let c = d - 1; c >= 0; c -= 1) a[d] - a[c] < o && (f += 1);
        return f
    }
    update() {
        const t = this;
        if (!t || t.destroyed) return;
        const {
            snapGrid: i,
            params: s
        } = t;
        s.breakpoints && t.setBreakpoint(), t.updateSize(), t.updateSlides(), t.updateProgress(), t.updateSlidesClasses();

        function r() {
            const a = t.rtlTranslate ? t.translate * -1 : t.translate,
                l = Math.min(Math.max(a, t.maxTranslate()), t.minTranslate());
            t.setTranslate(l), t.updateActiveIndex(), t.updateSlidesClasses()
        }
        let n;
        t.params.freeMode && t.params.freeMode.enabled ? (r(), t.params.autoHeight && t.updateAutoHeight()) : ((t.params.slidesPerView === "auto" || t.params.slidesPerView > 1) && t.isEnd && !t.params.centeredSlides ? n = t.slideTo(t.slides.length - 1, 0, !1, !0) : n = t.slideTo(t.activeIndex, 0, !1, !0), n || r()), s.watchOverflow && i !== t.snapGrid && t.checkOverflow(), t.emit("update")
    }
    changeDirection(t, i) {
        i === void 0 && (i = !0);
        const s = this,
            r = s.params.direction;
        return t || (t = r === "horizontal" ? "vertical" : "horizontal"), t === r || t !== "horizontal" && t !== "vertical" || (s.$el.removeClass(`${s.params.containerModifierClass}${r}`).addClass(`${s.params.containerModifierClass}${t}`), s.emitContainerClasses(), s.params.direction = t, s.slides.each(n => {
            t === "vertical" ? n.style.width = "" : n.style.height = ""
        }), s.emit("changeDirection"), i && s.update()), s
    }
    changeLanguageDirection(t) {
        const i = this;
        i.rtl && t === "rtl" || !i.rtl && t === "ltr" || (i.rtl = t === "rtl", i.rtlTranslate = i.params.direction === "horizontal" && i.rtl, i.rtl ? (i.$el.addClass(`${i.params.containerModifierClass}rtl`), i.el.dir = "rtl") : (i.$el.removeClass(`${i.params.containerModifierClass}rtl`), i.el.dir = "ltr"), i.update())
    }
    mount(t) {
        const i = this;
        if (i.mounted) return !0;
        const s = p(t || i.params.el);
        if (t = s[0], !t) return !1;
        t.swiper = i;
        const r = () => `.${(i.params.wrapperClass||"").trim().split(" ").join(".")}`;
        let a = (() => {
            if (t && t.shadowRoot && t.shadowRoot.querySelector) {
                const l = p(t.shadowRoot.querySelector(r()));
                return l.children = o => s.children(o), l
            }
            return s.children ? s.children(r()) : p(s).children(r())
        })();
        if (a.length === 0 && i.params.createElements) {
            const o = L().createElement("div");
            a = p(o), o.className = i.params.wrapperClass, s.append(o), s.children(`.${i.params.slideClass}`).each(d => {
                a.append(d)
            })
        }
        return Object.assign(i, {
            $el: s,
            el: t,
            $wrapperEl: a,
            wrapperEl: a[0],
            mounted: !0,
            rtl: t.dir.toLowerCase() === "rtl" || s.css("direction") === "rtl",
            rtlTranslate: i.params.direction === "horizontal" && (t.dir.toLowerCase() === "rtl" || s.css("direction") === "rtl"),
            wrongRTL: a.css("display") === "-webkit-box"
        }), !0
    }
    init(t) {
        const i = this;
        return i.initialized || i.mount(t) === !1 || (i.emit("beforeInit"), i.params.breakpoints && i.setBreakpoint(), i.addClasses(), i.params.loop && i.loopCreate(), i.updateSize(), i.updateSlides(), i.params.watchOverflow && i.checkOverflow(), i.params.grabCursor && i.enabled && i.setGrabCursor(), i.params.preloadImages && i.preloadImages(), i.params.loop ? i.slideTo(i.params.initialSlide + i.loopedSlides, 0, i.params.runCallbacksOnInit, !1, !0) : i.slideTo(i.params.initialSlide, 0, i.params.runCallbacksOnInit, !1, !0), i.attachEvents(), i.initialized = !0, i.emit("init"), i.emit("afterInit")), i
    }
    destroy(t, i) {
        t === void 0 && (t = !0), i === void 0 && (i = !0);
        const s = this,
            {
                params: r,
                $el: n,
                $wrapperEl: a,
                slides: l
            } = s;
        return typeof s.params == "undefined" || s.destroyed || (s.emit("beforeDestroy"), s.initialized = !1, s.detachEvents(), r.loop && s.loopDestroy(), i && (s.removeClasses(), n.removeAttr("style"), a.removeAttr("style"), l && l.length && l.removeClass([r.slideVisibleClass, r.slideActiveClass, r.slideNextClass, r.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-slide-index")), s.emit("destroy"), Object.keys(s.eventsListeners).forEach(o => {
            s.off(o)
        }), t !== !1 && (s.$el[0].swiper = null, et(s)), s.destroyed = !0), null
    }
    static extendDefaults(t) {
        P(W, t)
    }
    static get extendedDefaults() {
        return W
    }
    static get defaults() {
        return ie
    }
    static installModule(t) {
        O.prototype.__modules__ || (O.prototype.__modules__ = []);
        const i = O.prototype.__modules__;
        typeof t == "function" && i.indexOf(t) < 0 && i.push(t)
    }
    static use(t) {
        return Array.isArray(t) ? (t.forEach(i => O.installModule(i)), O) : (O.installModule(t), O)
    }
}
Object.keys(R).forEach(e => {
    Object.keys(R[e]).forEach(t => {
        O.prototype[t] = R[e][t]
    })
});
O.use([dt, ft]);
var gi = O;
export {
    p as $, gi as S, C as a, A as b, it as c, L as g, G as i, j as n, N as s
};