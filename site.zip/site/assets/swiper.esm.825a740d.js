import {
    s as fe,
    $ as X,
    g as V,
    a as W,
    n as U,
    b as q,
    c as pe,
    i as ue
} from "./core.c3b10569.js";
import {
    S as Fe,
    S as je
} from "./core.c3b10569.js";

function $e(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    x({
        virtual: {
            enabled: !1,
            slides: [],
            cache: !0,
            renderSlide: null,
            renderExternal: null,
            renderExternalUpdate: !0,
            addSlidesBefore: 0,
            addSlidesAfter: 0
        }
    });
    let $;
    e.virtual = {
        cache: {},
        from: void 0,
        to: void 0,
        slides: [],
        offset: 0,
        slidesGrid: []
    };

    function b(t, n) {
        const o = e.params.virtual;
        if (o.cache && e.virtual.cache[n]) return e.virtual.cache[n];
        const c = o.renderSlide ? X(o.renderSlide.call(e, t, n)) : X(`<div class="${e.params.slideClass}" data-swiper-slide-index="${n}">${t}</div>`);
        return c.attr("data-swiper-slide-index") || c.attr("data-swiper-slide-index", n), o.cache && (e.virtual.cache[n] = c), c
    }

    function v(t) {
        const {
            slidesPerView: n,
            slidesPerGroup: o,
            centeredSlides: c
        } = e.params, {
            addSlidesBefore: s,
            addSlidesAfter: r
        } = e.params.virtual, {
            from: g,
            to: l,
            slides: m,
            slidesGrid: D,
            offset: T
        } = e.virtual;
        e.params.cssMode || e.updateActiveIndex();
        const z = e.activeIndex || 0;
        let M;
        e.rtlTranslate ? M = "right" : M = e.isHorizontal() ? "left" : "top";
        let O, k;
        c ? (O = Math.floor(n / 2) + o + r, k = Math.floor(n / 2) + o + s) : (O = n + (o - 1) + r, k = o + s);
        const w = Math.max((z || 0) - k, 0),
            p = Math.min((z || 0) + O, m.length - 1),
            y = (e.slidesGrid[w] || 0) - (e.slidesGrid[0] || 0);
        Object.assign(e.virtual, {
            from: w,
            to: p,
            offset: y,
            slidesGrid: e.slidesGrid
        });

        function S() {
            e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.lazy && e.params.lazy.enabled && e.lazy.load(), E("virtualUpdate")
        }
        if (g === w && l === p && !t) {
            e.slidesGrid !== D && y !== T && e.slides.css(M, `${y}px`), e.updateProgress(), E("virtualUpdate");
            return
        }
        if (e.params.virtual.renderExternal) {
            e.params.virtual.renderExternal.call(e, {
                offset: y,
                from: w,
                to: p,
                slides: function() {
                    const I = [];
                    for (let P = w; P <= p; P += 1) I.push(m[P]);
                    return I
                }()
            }), e.params.virtual.renderExternalUpdate ? S() : E("virtualUpdate");
            return
        }
        const Y = [],
            H = [];
        if (t) e.$wrapperEl.find(`.${e.params.slideClass}`).remove();
        else
            for (let h = g; h <= l; h += 1)(h < w || h > p) && e.$wrapperEl.find(`.${e.params.slideClass}[data-swiper-slide-index="${h}"]`).remove();
        for (let h = 0; h < m.length; h += 1) h >= w && h <= p && (typeof l == "undefined" || t ? H.push(h) : (h > l && H.push(h), h < g && Y.push(h)));
        H.forEach(h => {
            e.$wrapperEl.append(b(m[h], h))
        }), Y.sort((h, I) => I - h).forEach(h => {
            e.$wrapperEl.prepend(b(m[h], h))
        }), e.$wrapperEl.children(".swiper-slide").css(M, `${y}px`), S()
    }

    function f(t) {
        if (typeof t == "object" && "length" in t)
            for (let n = 0; n < t.length; n += 1) t[n] && e.virtual.slides.push(t[n]);
        else e.virtual.slides.push(t);
        v(!0)
    }

    function d(t) {
        const n = e.activeIndex;
        let o = n + 1,
            c = 1;
        if (Array.isArray(t)) {
            for (let s = 0; s < t.length; s += 1) t[s] && e.virtual.slides.unshift(t[s]);
            o = n + t.length, c = t.length
        } else e.virtual.slides.unshift(t);
        if (e.params.virtual.cache) {
            const s = e.virtual.cache,
                r = {};
            Object.keys(s).forEach(g => {
                const l = s[g],
                    m = l.attr("data-swiper-slide-index");
                m && l.attr("data-swiper-slide-index", parseInt(m, 10) + c), r[parseInt(g, 10) + c] = l
            }), e.virtual.cache = r
        }
        v(!0), e.slideTo(o, 0)
    }

    function i(t) {
        if (typeof t == "undefined" || t === null) return;
        let n = e.activeIndex;
        if (Array.isArray(t))
            for (let o = t.length - 1; o >= 0; o -= 1) e.virtual.slides.splice(t[o], 1), e.params.virtual.cache && delete e.virtual.cache[t[o]], t[o] < n && (n -= 1), n = Math.max(n, 0);
        else e.virtual.slides.splice(t, 1), e.params.virtual.cache && delete e.virtual.cache[t], t < n && (n -= 1), n = Math.max(n, 0);
        v(!0), e.slideTo(n, 0)
    }

    function a() {
        e.virtual.slides = [], e.params.virtual.cache && (e.virtual.cache = {}), v(!0), e.slideTo(0, 0)
    }
    u("beforeInit", () => {
        !e.params.virtual.enabled || (e.virtual.slides = e.params.virtual.slides, e.classNames.push(`${e.params.containerModifierClass}virtual`), e.params.watchSlidesProgress = !0, e.originalParams.watchSlidesProgress = !0, e.params.initialSlide || v())
    }), u("setTranslate", () => {
        !e.params.virtual.enabled || (e.params.cssMode && !e._immediateVirtual ? (clearTimeout($), $ = setTimeout(() => {
            v()
        }, 100)) : v())
    }), u("init update resize", () => {
        !e.params.virtual.enabled || e.params.cssMode && fe(e.wrapperEl, "--swiper-virtual-size", `${e.virtualSize}px`)
    }), Object.assign(e.virtual, {
        appendSlide: f,
        prependSlide: d,
        removeSlide: i,
        removeAllSlides: a,
        update: v
    })
}

function Ee(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    const $ = V(),
        b = W();
    e.keyboard = {
        enabled: !1
    }, x({
        keyboard: {
            enabled: !1,
            onlyInViewport: !0,
            pageUpDown: !0
        }
    });

    function v(i) {
        if (!e.enabled) return;
        const {
            rtlTranslate: a
        } = e;
        let t = i;
        t.originalEvent && (t = t.originalEvent);
        const n = t.keyCode || t.charCode,
            o = e.params.keyboard.pageUpDown,
            c = o && n === 33,
            s = o && n === 34,
            r = n === 37,
            g = n === 39,
            l = n === 38,
            m = n === 40;
        if (!e.allowSlideNext && (e.isHorizontal() && g || e.isVertical() && m || s) || !e.allowSlidePrev && (e.isHorizontal() && r || e.isVertical() && l || c)) return !1;
        if (!(t.shiftKey || t.altKey || t.ctrlKey || t.metaKey) && !($.activeElement && $.activeElement.nodeName && ($.activeElement.nodeName.toLowerCase() === "input" || $.activeElement.nodeName.toLowerCase() === "textarea"))) {
            if (e.params.keyboard.onlyInViewport && (c || s || r || g || l || m)) {
                let D = !1;
                if (e.$el.parents(`.${e.params.slideClass}`).length > 0 && e.$el.parents(`.${e.params.slideActiveClass}`).length === 0) return;
                const T = e.$el,
                    z = T[0].clientWidth,
                    M = T[0].clientHeight,
                    O = b.innerWidth,
                    k = b.innerHeight,
                    w = e.$el.offset();
                a && (w.left -= e.$el[0].scrollLeft);
                const p = [
                    [w.left, w.top],
                    [w.left + z, w.top],
                    [w.left, w.top + M],
                    [w.left + z, w.top + M]
                ];
                for (let y = 0; y < p.length; y += 1) {
                    const S = p[y];
                    if (S[0] >= 0 && S[0] <= O && S[1] >= 0 && S[1] <= k) {
                        if (S[0] === 0 && S[1] === 0) continue;
                        D = !0
                    }
                }
                if (!D) return
            }
            e.isHorizontal() ? ((c || s || r || g) && (t.preventDefault ? t.preventDefault() : t.returnValue = !1), ((s || g) && !a || (c || r) && a) && e.slideNext(), ((c || r) && !a || (s || g) && a) && e.slidePrev()) : ((c || s || l || m) && (t.preventDefault ? t.preventDefault() : t.returnValue = !1), (s || m) && e.slideNext(), (c || l) && e.slidePrev()), E("keyPress", n)
        }
    }

    function f() {
        e.keyboard.enabled || (X($).on("keydown", v), e.keyboard.enabled = !0)
    }

    function d() {
        !e.keyboard.enabled || (X($).off("keydown", v), e.keyboard.enabled = !1)
    }
    u("init", () => {
        e.params.keyboard.enabled && f()
    }), u("destroy", () => {
        e.keyboard.enabled && d()
    }), Object.assign(e.keyboard, {
        enable: f,
        disable: d
    })
}

function xe(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    const $ = W();
    x({
        mousewheel: {
            enabled: !1,
            releaseOnEdges: !1,
            invert: !1,
            forceToAxis: !1,
            sensitivity: 1,
            eventsTarget: "container",
            thresholdDelta: null,
            thresholdTime: null
        }
    }), e.mousewheel = {
        enabled: !1
    };
    let b, v = q(),
        f;
    const d = [];

    function i(l) {
        let z = 0,
            M = 0,
            O = 0,
            k = 0;
        return "detail" in l && (M = l.detail), "wheelDelta" in l && (M = -l.wheelDelta / 120), "wheelDeltaY" in l && (M = -l.wheelDeltaY / 120), "wheelDeltaX" in l && (z = -l.wheelDeltaX / 120), "axis" in l && l.axis === l.HORIZONTAL_AXIS && (z = M, M = 0), O = z * 10, k = M * 10, "deltaY" in l && (k = l.deltaY), "deltaX" in l && (O = l.deltaX), l.shiftKey && !O && (O = k, k = 0), (O || k) && l.deltaMode && (l.deltaMode === 1 ? (O *= 40, k *= 40) : (O *= 800, k *= 800)), O && !z && (z = O < 1 ? -1 : 1), k && !M && (M = k < 1 ? -1 : 1), {
            spinX: z,
            spinY: M,
            pixelX: O,
            pixelY: k
        }
    }

    function a() {
        !e.enabled || (e.mouseEntered = !0)
    }

    function t() {
        !e.enabled || (e.mouseEntered = !1)
    }

    function n(l) {
        return e.params.mousewheel.thresholdDelta && l.delta < e.params.mousewheel.thresholdDelta || e.params.mousewheel.thresholdTime && q() - v < e.params.mousewheel.thresholdTime ? !1 : l.delta >= 6 && q() - v < 60 ? !0 : (l.direction < 0 ? (!e.isEnd || e.params.loop) && !e.animating && (e.slideNext(), E("scroll", l.raw)) : (!e.isBeginning || e.params.loop) && !e.animating && (e.slidePrev(), E("scroll", l.raw)), v = new $.Date().getTime(), !1)
    }

    function o(l) {
        const m = e.params.mousewheel;
        if (l.direction < 0) {
            if (e.isEnd && !e.params.loop && m.releaseOnEdges) return !0
        } else if (e.isBeginning && !e.params.loop && m.releaseOnEdges) return !0;
        return !1
    }

    function c(l) {
        let m = l,
            D = !0;
        if (!e.enabled) return;
        const T = e.params.mousewheel;
        e.params.cssMode && m.preventDefault();
        let z = e.$el;
        if (e.params.mousewheel.eventsTarget !== "container" && (z = X(e.params.mousewheel.eventsTarget)), !e.mouseEntered && !z[0].contains(m.target) && !T.releaseOnEdges) return !0;
        m.originalEvent && (m = m.originalEvent);
        let M = 0;
        const O = e.rtlTranslate ? -1 : 1,
            k = i(m);
        if (T.forceToAxis)
            if (e.isHorizontal())
                if (Math.abs(k.pixelX) > Math.abs(k.pixelY)) M = -k.pixelX * O;
                else return !0;
        else if (Math.abs(k.pixelY) > Math.abs(k.pixelX)) M = -k.pixelY;
        else return !0;
        else M = Math.abs(k.pixelX) > Math.abs(k.pixelY) ? -k.pixelX * O : -k.pixelY;
        if (M === 0) return !0;
        T.invert && (M = -M);
        let w = e.getTranslate() + M * T.sensitivity;
        if (w >= e.minTranslate() && (w = e.minTranslate()), w <= e.maxTranslate() && (w = e.maxTranslate()), D = e.params.loop ? !0 : !(w === e.minTranslate() || w === e.maxTranslate()), D && e.params.nested && m.stopPropagation(), !e.params.freeMode || !e.params.freeMode.enabled) {
            const p = {
                time: q(),
                delta: Math.abs(M),
                direction: Math.sign(M),
                raw: l
            };
            d.length >= 2 && d.shift();
            const y = d.length ? d[d.length - 1] : void 0;
            if (d.push(p), y ? (p.direction !== y.direction || p.delta > y.delta || p.time > y.time + 150) && n(p) : n(p), o(p)) return !0
        } else {
            const p = {
                    time: q(),
                    delta: Math.abs(M),
                    direction: Math.sign(M)
                },
                y = f && p.time < f.time + 500 && p.delta <= f.delta && p.direction === f.direction;
            if (!y) {
                f = void 0, e.params.loop && e.loopFix();
                let S = e.getTranslate() + M * T.sensitivity;
                const Y = e.isBeginning,
                    H = e.isEnd;
                if (S >= e.minTranslate() && (S = e.minTranslate()), S <= e.maxTranslate() && (S = e.maxTranslate()), e.setTransition(0), e.setTranslate(S), e.updateProgress(), e.updateActiveIndex(), e.updateSlidesClasses(), (!Y && e.isBeginning || !H && e.isEnd) && e.updateSlidesClasses(), e.params.freeMode.sticky) {
                    clearTimeout(b), b = void 0, d.length >= 15 && d.shift();
                    const h = d.length ? d[d.length - 1] : void 0,
                        I = d[0];
                    if (d.push(p), h && (p.delta > h.delta || p.direction !== h.direction)) d.splice(0);
                    else if (d.length >= 15 && p.time - I.time < 500 && I.delta - p.delta >= 1 && p.delta <= 6) {
                        const P = M > 0 ? .8 : .2;
                        f = p, d.splice(0), b = U(() => {
                            e.slideToClosest(e.params.speed, !0, void 0, P)
                        }, 0)
                    }
                    b || (b = U(() => {
                        f = p, d.splice(0), e.slideToClosest(e.params.speed, !0, void 0, .5)
                    }, 500))
                }
                if (y || E("scroll", m), e.params.autoplay && e.params.autoplayDisableOnInteraction && e.autoplay.stop(), S === e.minTranslate() || S === e.maxTranslate()) return !0
            }
        }
        return m.preventDefault ? m.preventDefault() : m.returnValue = !1, !1
    }

    function s(l) {
        let m = e.$el;
        e.params.mousewheel.eventsTarget !== "container" && (m = X(e.params.mousewheel.eventsTarget)), m[l]("mouseenter", a), m[l]("mouseleave", t), m[l]("wheel", c)
    }

    function r() {
        return e.params.cssMode ? (e.wrapperEl.removeEventListener("wheel", c), !0) : e.mousewheel.enabled ? !1 : (s("on"), e.mousewheel.enabled = !0, !0)
    }

    function g() {
        return e.params.cssMode ? (e.wrapperEl.addEventListener(event, c), !0) : e.mousewheel.enabled ? (s("off"), e.mousewheel.enabled = !1, !0) : !1
    }
    u("init", () => {
        !e.params.mousewheel.enabled && e.params.cssMode && g(), e.params.mousewheel.enabled && r()
    }), u("destroy", () => {
        e.params.cssMode && r(), e.mousewheel.enabled && g()
    }), Object.assign(e.mousewheel, {
        enable: r,
        disable: g
    })
}

function ne(C, e, x, u) {
    const E = V();
    return C.params.createElements && Object.keys(u).forEach($ => {
        if (!x[$] && x.auto === !0) {
            let b = C.$el.children(`.${u[$]}`)[0];
            b || (b = E.createElement("div"), b.className = u[$], C.$el.append(b)), x[$] = b, e[$] = b
        }
    }), x
}

function ye(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    x({
        navigation: {
            nextEl: null,
            prevEl: null,
            hideOnClick: !1,
            disabledClass: "swiper-button-disabled",
            hiddenClass: "swiper-button-hidden",
            lockClass: "swiper-button-lock",
            navigationDisabledClass: "swiper-navigation-disabled"
        }
    }), e.navigation = {
        nextEl: null,
        $nextEl: null,
        prevEl: null,
        $prevEl: null
    };

    function $(o) {
        let c;
        return o && (c = X(o), e.params.uniqueNavElements && typeof o == "string" && c.length > 1 && e.$el.find(o).length === 1 && (c = e.$el.find(o))), c
    }

    function b(o, c) {
        const s = e.params.navigation;
        o && o.length > 0 && (o[c ? "addClass" : "removeClass"](s.disabledClass), o[0] && o[0].tagName === "BUTTON" && (o[0].disabled = c), e.params.watchOverflow && e.enabled && o[e.isLocked ? "addClass" : "removeClass"](s.lockClass))
    }

    function v() {
        if (e.params.loop) return;
        const {
            $nextEl: o,
            $prevEl: c
        } = e.navigation;
        b(c, e.isBeginning && !e.params.rewind), b(o, e.isEnd && !e.params.rewind)
    }

    function f(o) {
        o.preventDefault(), !(e.isBeginning && !e.params.loop && !e.params.rewind) && (e.slidePrev(), E("navigationPrev"))
    }

    function d(o) {
        o.preventDefault(), !(e.isEnd && !e.params.loop && !e.params.rewind) && (e.slideNext(), E("navigationNext"))
    }

    function i() {
        const o = e.params.navigation;
        if (e.params.navigation = ne(e, e.originalParams.navigation, e.params.navigation, {
                nextEl: "swiper-button-next",
                prevEl: "swiper-button-prev"
            }), !(o.nextEl || o.prevEl)) return;
        const c = $(o.nextEl),
            s = $(o.prevEl);
        c && c.length > 0 && c.on("click", d), s && s.length > 0 && s.on("click", f), Object.assign(e.navigation, {
            $nextEl: c,
            nextEl: c && c[0],
            $prevEl: s,
            prevEl: s && s[0]
        }), e.enabled || (c && c.addClass(o.lockClass), s && s.addClass(o.lockClass))
    }

    function a() {
        const {
            $nextEl: o,
            $prevEl: c
        } = e.navigation;
        o && o.length && (o.off("click", d), o.removeClass(e.params.navigation.disabledClass)), c && c.length && (c.off("click", f), c.removeClass(e.params.navigation.disabledClass))
    }
    u("init", () => {
        e.params.navigation.enabled === !1 ? n() : (i(), v())
    }), u("toEdge fromEdge lock unlock", () => {
        v()
    }), u("destroy", () => {
        a()
    }), u("enable disable", () => {
        const {
            $nextEl: o,
            $prevEl: c
        } = e.navigation;
        o && o[e.enabled ? "removeClass" : "addClass"](e.params.navigation.lockClass), c && c[e.enabled ? "removeClass" : "addClass"](e.params.navigation.lockClass)
    }), u("click", (o, c) => {
        const {
            $nextEl: s,
            $prevEl: r
        } = e.navigation, g = c.target;
        if (e.params.navigation.hideOnClick && !X(g).is(r) && !X(g).is(s)) {
            if (e.pagination && e.params.pagination && e.params.pagination.clickable && (e.pagination.el === g || e.pagination.el.contains(g))) return;
            let l;
            s ? l = s.hasClass(e.params.navigation.hiddenClass) : r && (l = r.hasClass(e.params.navigation.hiddenClass)), E(l === !0 ? "navigationShow" : "navigationHide"), s && s.toggleClass(e.params.navigation.hiddenClass), r && r.toggleClass(e.params.navigation.hiddenClass)
        }
    });
    const t = () => {
            e.$el.removeClass(e.params.navigation.navigationDisabledClass), i(), v()
        },
        n = () => {
            e.$el.addClass(e.params.navigation.navigationDisabledClass), a()
        };
    Object.assign(e.navigation, {
        enable: t,
        disable: n,
        update: v,
        init: i,
        destroy: a
    })
}

function N(C) {
    return C === void 0 && (C = ""), `.${C.trim().replace(/([\.:!\/])/g,"\\$1").replace(/ /g,".")}`
}

function Ce(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    const $ = "swiper-pagination";
    x({
        pagination: {
            el: null,
            bulletElement: "span",
            clickable: !1,
            hideOnClick: !1,
            renderBullet: null,
            renderProgressbar: null,
            renderFraction: null,
            renderCustom: null,
            progressbarOpposite: !1,
            type: "bullets",
            dynamicBullets: !1,
            dynamicMainBullets: 1,
            formatFractionCurrent: s => s,
            formatFractionTotal: s => s,
            bulletClass: `${$}-bullet`,
            bulletActiveClass: `${$}-bullet-active`,
            modifierClass: `${$}-`,
            currentClass: `${$}-current`,
            totalClass: `${$}-total`,
            hiddenClass: `${$}-hidden`,
            progressbarFillClass: `${$}-progressbar-fill`,
            progressbarOppositeClass: `${$}-progressbar-opposite`,
            clickableClass: `${$}-clickable`,
            lockClass: `${$}-lock`,
            horizontalClass: `${$}-horizontal`,
            verticalClass: `${$}-vertical`,
            paginationDisabledClass: `${$}-disabled`
        }
    }), e.pagination = {
        el: null,
        $el: null,
        bullets: []
    };
    let b, v = 0;

    function f() {
        return !e.params.pagination.el || !e.pagination.el || !e.pagination.$el || e.pagination.$el.length === 0
    }

    function d(s, r) {
        const {
            bulletActiveClass: g
        } = e.params.pagination;
        s[r]().addClass(`${g}-${r}`)[r]().addClass(`${g}-${r}-${r}`)
    }

    function i() {
        const s = e.rtl,
            r = e.params.pagination;
        if (f()) return;
        const g = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
            l = e.pagination.$el;
        let m;
        const D = e.params.loop ? Math.ceil((g - e.loopedSlides * 2) / e.params.slidesPerGroup) : e.snapGrid.length;
        if (e.params.loop ? (m = Math.ceil((e.activeIndex - e.loopedSlides) / e.params.slidesPerGroup), m > g - 1 - e.loopedSlides * 2 && (m -= g - e.loopedSlides * 2), m > D - 1 && (m -= D), m < 0 && e.params.paginationType !== "bullets" && (m = D + m)) : typeof e.snapIndex != "undefined" ? m = e.snapIndex : m = e.activeIndex || 0, r.type === "bullets" && e.pagination.bullets && e.pagination.bullets.length > 0) {
            const T = e.pagination.bullets;
            let z, M, O;
            if (r.dynamicBullets && (b = T.eq(0)[e.isHorizontal() ? "outerWidth" : "outerHeight"](!0), l.css(e.isHorizontal() ? "width" : "height", `${b*(r.dynamicMainBullets+4)}px`), r.dynamicMainBullets > 1 && e.previousIndex !== void 0 && (v += m - (e.previousIndex - e.loopedSlides || 0), v > r.dynamicMainBullets - 1 ? v = r.dynamicMainBullets - 1 : v < 0 && (v = 0)), z = Math.max(m - v, 0), M = z + (Math.min(T.length, r.dynamicMainBullets) - 1), O = (M + z) / 2), T.removeClass(["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map(k => `${r.bulletActiveClass}${k}`).join(" ")), l.length > 1) T.each(k => {
                const w = X(k),
                    p = w.index();
                p === m && w.addClass(r.bulletActiveClass), r.dynamicBullets && (p >= z && p <= M && w.addClass(`${r.bulletActiveClass}-main`), p === z && d(w, "prev"), p === M && d(w, "next"))
            });
            else {
                const k = T.eq(m),
                    w = k.index();
                if (k.addClass(r.bulletActiveClass), r.dynamicBullets) {
                    const p = T.eq(z),
                        y = T.eq(M);
                    for (let S = z; S <= M; S += 1) T.eq(S).addClass(`${r.bulletActiveClass}-main`);
                    if (e.params.loop)
                        if (w >= T.length) {
                            for (let S = r.dynamicMainBullets; S >= 0; S -= 1) T.eq(T.length - S).addClass(`${r.bulletActiveClass}-main`);
                            T.eq(T.length - r.dynamicMainBullets - 1).addClass(`${r.bulletActiveClass}-prev`)
                        } else d(p, "prev"), d(y, "next");
                    else d(p, "prev"), d(y, "next")
                }
            }
            if (r.dynamicBullets) {
                const k = Math.min(T.length, r.dynamicMainBullets + 4),
                    w = (b * k - b) / 2 - O * b,
                    p = s ? "right" : "left";
                T.css(e.isHorizontal() ? p : "top", `${w}px`)
            }
        }
        if (r.type === "fraction" && (l.find(N(r.currentClass)).text(r.formatFractionCurrent(m + 1)), l.find(N(r.totalClass)).text(r.formatFractionTotal(D))), r.type === "progressbar") {
            let T;
            r.progressbarOpposite ? T = e.isHorizontal() ? "vertical" : "horizontal" : T = e.isHorizontal() ? "horizontal" : "vertical";
            const z = (m + 1) / D;
            let M = 1,
                O = 1;
            T === "horizontal" ? M = z : O = z, l.find(N(r.progressbarFillClass)).transform(`translate3d(0,0,0) scaleX(${M}) scaleY(${O})`).transition(e.params.speed)
        }
        r.type === "custom" && r.renderCustom ? (l.html(r.renderCustom(e, m + 1, D)), E("paginationRender", l[0])) : E("paginationUpdate", l[0]), e.params.watchOverflow && e.enabled && l[e.isLocked ? "addClass" : "removeClass"](r.lockClass)
    }

    function a() {
        const s = e.params.pagination;
        if (f()) return;
        const r = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
            g = e.pagination.$el;
        let l = "";
        if (s.type === "bullets") {
            let m = e.params.loop ? Math.ceil((r - e.loopedSlides * 2) / e.params.slidesPerGroup) : e.snapGrid.length;
            e.params.freeMode && e.params.freeMode.enabled && !e.params.loop && m > r && (m = r);
            for (let D = 0; D < m; D += 1) s.renderBullet ? l += s.renderBullet.call(e, D, s.bulletClass) : l += `<${s.bulletElement} class="${s.bulletClass}"></${s.bulletElement}>`;
            g.html(l), e.pagination.bullets = g.find(N(s.bulletClass))
        }
        s.type === "fraction" && (s.renderFraction ? l = s.renderFraction.call(e, s.currentClass, s.totalClass) : l = `<span class="${s.currentClass}"></span> / <span class="${s.totalClass}"></span>`, g.html(l)), s.type === "progressbar" && (s.renderProgressbar ? l = s.renderProgressbar.call(e, s.progressbarFillClass) : l = `<span class="${s.progressbarFillClass}"></span>`, g.html(l)), s.type !== "custom" && E("paginationRender", e.pagination.$el[0])
    }

    function t() {
        e.params.pagination = ne(e, e.originalParams.pagination, e.params.pagination, {
            el: "swiper-pagination"
        });
        const s = e.params.pagination;
        if (!s.el) return;
        let r = X(s.el);
        r.length !== 0 && (e.params.uniqueNavElements && typeof s.el == "string" && r.length > 1 && (r = e.$el.find(s.el), r.length > 1 && (r = r.filter(g => X(g).parents(".swiper")[0] === e.el))), s.type === "bullets" && s.clickable && r.addClass(s.clickableClass), r.addClass(s.modifierClass + s.type), r.addClass(e.isHorizontal() ? s.horizontalClass : s.verticalClass), s.type === "bullets" && s.dynamicBullets && (r.addClass(`${s.modifierClass}${s.type}-dynamic`), v = 0, s.dynamicMainBullets < 1 && (s.dynamicMainBullets = 1)), s.type === "progressbar" && s.progressbarOpposite && r.addClass(s.progressbarOppositeClass), s.clickable && r.on("click", N(s.bulletClass), function(l) {
            l.preventDefault();
            let m = X(this).index() * e.params.slidesPerGroup;
            e.params.loop && (m += e.loopedSlides), e.slideTo(m)
        }), Object.assign(e.pagination, {
            $el: r,
            el: r[0]
        }), e.enabled || r.addClass(s.lockClass))
    }

    function n() {
        const s = e.params.pagination;
        if (f()) return;
        const r = e.pagination.$el;
        r.removeClass(s.hiddenClass), r.removeClass(s.modifierClass + s.type), r.removeClass(e.isHorizontal() ? s.horizontalClass : s.verticalClass), e.pagination.bullets && e.pagination.bullets.removeClass && e.pagination.bullets.removeClass(s.bulletActiveClass), s.clickable && r.off("click", N(s.bulletClass))
    }
    u("init", () => {
        e.params.pagination.enabled === !1 ? c() : (t(), a(), i())
    }), u("activeIndexChange", () => {
        (e.params.loop || typeof e.snapIndex == "undefined") && i()
    }), u("snapIndexChange", () => {
        e.params.loop || i()
    }), u("slidesLengthChange", () => {
        e.params.loop && (a(), i())
    }), u("snapGridLengthChange", () => {
        e.params.loop || (a(), i())
    }), u("destroy", () => {
        n()
    }), u("enable disable", () => {
        const {
            $el: s
        } = e.pagination;
        s && s[e.enabled ? "removeClass" : "addClass"](e.params.pagination.lockClass)
    }), u("lock unlock", () => {
        i()
    }), u("click", (s, r) => {
        const g = r.target,
            {
                $el: l
            } = e.pagination;
        if (e.params.pagination.el && e.params.pagination.hideOnClick && l && l.length > 0 && !X(g).hasClass(e.params.pagination.bulletClass)) {
            if (e.navigation && (e.navigation.nextEl && g === e.navigation.nextEl || e.navigation.prevEl && g === e.navigation.prevEl)) return;
            const m = l.hasClass(e.params.pagination.hiddenClass);
            E(m === !0 ? "paginationShow" : "paginationHide"), l.toggleClass(e.params.pagination.hiddenClass)
        }
    });
    const o = () => {
            e.$el.removeClass(e.params.pagination.paginationDisabledClass), e.pagination.$el && e.pagination.$el.removeClass(e.params.pagination.paginationDisabledClass), t(), a(), i()
        },
        c = () => {
            e.$el.addClass(e.params.pagination.paginationDisabledClass), e.pagination.$el && e.pagination.$el.addClass(e.params.pagination.paginationDisabledClass), n()
        };
    Object.assign(e.pagination, {
        enable: o,
        disable: c,
        render: a,
        update: i,
        init: t,
        destroy: n
    })
}

function Me(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    const $ = V();
    let b = !1,
        v = null,
        f = null,
        d, i, a, t;
    x({
        scrollbar: {
            el: null,
            dragSize: "auto",
            hide: !1,
            draggable: !1,
            snapOnRelease: !0,
            lockClass: "swiper-scrollbar-lock",
            dragClass: "swiper-scrollbar-drag",
            scrollbarDisabledClass: "swiper-scrollbar-disabled",
            horizontalClass: "swiper-scrollbar-horizontal",
            verticalClass: "swiper-scrollbar-vertical"
        }
    }), e.scrollbar = {
        el: null,
        dragEl: null,
        $el: null,
        $dragEl: null
    };

    function n() {
        if (!e.params.scrollbar.el || !e.scrollbar.el) return;
        const {
            scrollbar: p,
            rtlTranslate: y,
            progress: S
        } = e, {
            $dragEl: Y,
            $el: H
        } = p, h = e.params.scrollbar;
        let I = i,
            P = (a - i) * S;
        y ? (P = -P, P > 0 ? (I = i - P, P = 0) : -P + i > a && (I = a + P)) : P < 0 ? (I = i + P, P = 0) : P + i > a && (I = a - P), e.isHorizontal() ? (Y.transform(`translate3d(${P}px, 0, 0)`), Y[0].style.width = `${I}px`) : (Y.transform(`translate3d(0px, ${P}px, 0)`), Y[0].style.height = `${I}px`), h.hide && (clearTimeout(v), H[0].style.opacity = 1, v = setTimeout(() => {
            H[0].style.opacity = 0, H.transition(400)
        }, 1e3))
    }

    function o(p) {
        !e.params.scrollbar.el || !e.scrollbar.el || e.scrollbar.$dragEl.transition(p)
    }

    function c() {
        if (!e.params.scrollbar.el || !e.scrollbar.el) return;
        const {
            scrollbar: p
        } = e, {
            $dragEl: y,
            $el: S
        } = p;
        y[0].style.width = "", y[0].style.height = "", a = e.isHorizontal() ? S[0].offsetWidth : S[0].offsetHeight, t = e.size / (e.virtualSize + e.params.slidesOffsetBefore - (e.params.centeredSlides ? e.snapGrid[0] : 0)), e.params.scrollbar.dragSize === "auto" ? i = a * t : i = parseInt(e.params.scrollbar.dragSize, 10), e.isHorizontal() ? y[0].style.width = `${i}px` : y[0].style.height = `${i}px`, t >= 1 ? S[0].style.display = "none" : S[0].style.display = "", e.params.scrollbar.hide && (S[0].style.opacity = 0), e.params.watchOverflow && e.enabled && p.$el[e.isLocked ? "addClass" : "removeClass"](e.params.scrollbar.lockClass)
    }

    function s(p) {
        return e.isHorizontal() ? p.type === "touchstart" || p.type === "touchmove" ? p.targetTouches[0].clientX : p.clientX : p.type === "touchstart" || p.type === "touchmove" ? p.targetTouches[0].clientY : p.clientY
    }

    function r(p) {
        const {
            scrollbar: y,
            rtlTranslate: S
        } = e, {
            $el: Y
        } = y;
        let H;
        H = (s(p) - Y.offset()[e.isHorizontal() ? "left" : "top"] - (d !== null ? d : i / 2)) / (a - i), H = Math.max(Math.min(H, 1), 0), S && (H = 1 - H);
        const h = e.minTranslate() + (e.maxTranslate() - e.minTranslate()) * H;
        e.updateProgress(h), e.setTranslate(h), e.updateActiveIndex(), e.updateSlidesClasses()
    }

    function g(p) {
        const y = e.params.scrollbar,
            {
                scrollbar: S,
                $wrapperEl: Y
            } = e,
            {
                $el: H,
                $dragEl: h
            } = S;
        b = !0, d = p.target === h[0] || p.target === h ? s(p) - p.target.getBoundingClientRect()[e.isHorizontal() ? "left" : "top"] : null, p.preventDefault(), p.stopPropagation(), Y.transition(100), h.transition(100), r(p), clearTimeout(f), H.transition(0), y.hide && H.css("opacity", 1), e.params.cssMode && e.$wrapperEl.css("scroll-snap-type", "none"), E("scrollbarDragStart", p)
    }

    function l(p) {
        const {
            scrollbar: y,
            $wrapperEl: S
        } = e, {
            $el: Y,
            $dragEl: H
        } = y;
        !b || (p.preventDefault ? p.preventDefault() : p.returnValue = !1, r(p), S.transition(0), Y.transition(0), H.transition(0), E("scrollbarDragMove", p))
    }

    function m(p) {
        const y = e.params.scrollbar,
            {
                scrollbar: S,
                $wrapperEl: Y
            } = e,
            {
                $el: H
            } = S;
        !b || (b = !1, e.params.cssMode && (e.$wrapperEl.css("scroll-snap-type", ""), Y.transition("")), y.hide && (clearTimeout(f), f = U(() => {
            H.css("opacity", 0), H.transition(400)
        }, 1e3)), E("scrollbarDragEnd", p), y.snapOnRelease && e.slideToClosest())
    }

    function D(p) {
        const {
            scrollbar: y,
            touchEventsTouch: S,
            touchEventsDesktop: Y,
            params: H,
            support: h
        } = e, I = y.$el;
        if (!I) return;
        const P = I[0],
            A = h.passiveListener && H.passiveListeners ? {
                passive: !1,
                capture: !1
            } : !1,
            L = h.passiveListener && H.passiveListeners ? {
                passive: !0,
                capture: !1
            } : !1;
        if (!P) return;
        const B = p === "on" ? "addEventListener" : "removeEventListener";
        h.touch ? (P[B](S.start, g, A), P[B](S.move, l, A), P[B](S.end, m, L)) : (P[B](Y.start, g, A), $[B](Y.move, l, A), $[B](Y.end, m, L))
    }

    function T() {
        !e.params.scrollbar.el || !e.scrollbar.el || D("on")
    }

    function z() {
        !e.params.scrollbar.el || !e.scrollbar.el || D("off")
    }

    function M() {
        const {
            scrollbar: p,
            $el: y
        } = e;
        e.params.scrollbar = ne(e, e.originalParams.scrollbar, e.params.scrollbar, {
            el: "swiper-scrollbar"
        });
        const S = e.params.scrollbar;
        if (!S.el) return;
        let Y = X(S.el);
        e.params.uniqueNavElements && typeof S.el == "string" && Y.length > 1 && y.find(S.el).length === 1 && (Y = y.find(S.el)), Y.addClass(e.isHorizontal() ? S.horizontalClass : S.verticalClass);
        let H = Y.find(`.${e.params.scrollbar.dragClass}`);
        H.length === 0 && (H = X(`<div class="${e.params.scrollbar.dragClass}"></div>`), Y.append(H)), Object.assign(p, {
            $el: Y,
            el: Y[0],
            $dragEl: H,
            dragEl: H[0]
        }), S.draggable && T(), Y && Y[e.enabled ? "removeClass" : "addClass"](e.params.scrollbar.lockClass)
    }

    function O() {
        const p = e.params.scrollbar,
            y = e.scrollbar.$el;
        y && y.removeClass(e.isHorizontal() ? p.horizontalClass : p.verticalClass), z()
    }
    u("init", () => {
        e.params.scrollbar.enabled === !1 ? w() : (M(), c(), n())
    }), u("update resize observerUpdate lock unlock", () => {
        c()
    }), u("setTranslate", () => {
        n()
    }), u("setTransition", (p, y) => {
        o(y)
    }), u("enable disable", () => {
        const {
            $el: p
        } = e.scrollbar;
        p && p[e.enabled ? "removeClass" : "addClass"](e.params.scrollbar.lockClass)
    }), u("destroy", () => {
        O()
    });
    const k = () => {
            e.$el.removeClass(e.params.scrollbar.scrollbarDisabledClass), e.scrollbar.$el && e.scrollbar.$el.removeClass(e.params.scrollbar.scrollbarDisabledClass), M(), c(), n()
        },
        w = () => {
            e.$el.addClass(e.params.scrollbar.scrollbarDisabledClass), e.scrollbar.$el && e.scrollbar.$el.addClass(e.params.scrollbar.scrollbarDisabledClass), O()
        };
    Object.assign(e.scrollbar, {
        enable: k,
        disable: w,
        updateSize: c,
        setTranslate: n,
        init: M,
        destroy: O
    })
}

function Te(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        parallax: {
            enabled: !1
        }
    });
    const E = (v, f) => {
            const {
                rtl: d
            } = e, i = X(v), a = d ? -1 : 1, t = i.attr("data-swiper-parallax") || "0";
            let n = i.attr("data-swiper-parallax-x"),
                o = i.attr("data-swiper-parallax-y");
            const c = i.attr("data-swiper-parallax-scale"),
                s = i.attr("data-swiper-parallax-opacity");
            if (n || o ? (n = n || "0", o = o || "0") : e.isHorizontal() ? (n = t, o = "0") : (o = t, n = "0"), n.indexOf("%") >= 0 ? n = `${parseInt(n,10)*f*a}%` : n = `${n*f*a}px`, o.indexOf("%") >= 0 ? o = `${parseInt(o,10)*f}%` : o = `${o*f}px`, typeof s != "undefined" && s !== null) {
                const r = s - (s - 1) * (1 - Math.abs(f));
                i[0].style.opacity = r
            }
            if (typeof c == "undefined" || c === null) i.transform(`translate3d(${n}, ${o}, 0px)`);
            else {
                const r = c - (c - 1) * (1 - Math.abs(f));
                i.transform(`translate3d(${n}, ${o}, 0px) scale(${r})`)
            }
        },
        $ = () => {
            const {
                $el: v,
                slides: f,
                progress: d,
                snapGrid: i
            } = e;
            v.children("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each(a => {
                E(a, d)
            }), f.each((a, t) => {
                let n = a.progress;
                e.params.slidesPerGroup > 1 && e.params.slidesPerView !== "auto" && (n += Math.ceil(t / 2) - d * (i.length - 1)), n = Math.min(Math.max(n, -1), 1), X(a).find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each(o => {
                    E(o, n)
                })
            })
        },
        b = function(v) {
            v === void 0 && (v = e.params.speed);
            const {
                $el: f
            } = e;
            f.find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each(d => {
                const i = X(d);
                let a = parseInt(i.attr("data-swiper-parallax-duration"), 10) || v;
                v === 0 && (a = 0), i.transition(a)
            })
        };
    u("beforeInit", () => {
        !e.params.parallax.enabled || (e.params.watchSlidesProgress = !0, e.originalParams.watchSlidesProgress = !0)
    }), u("init", () => {
        !e.params.parallax.enabled || $()
    }), u("setTranslate", () => {
        !e.params.parallax.enabled || $()
    }), u("setTransition", (v, f) => {
        !e.params.parallax.enabled || b(f)
    })
}

function Se(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    const $ = W();
    x({
        zoom: {
            enabled: !1,
            maxRatio: 3,
            minRatio: 1,
            toggle: !0,
            containerClass: "swiper-zoom-container",
            zoomedSlideClass: "swiper-slide-zoomed"
        }
    }), e.zoom = {
        enabled: !1
    };
    let b = 1,
        v = !1,
        f, d, i;
    const a = {
            $slideEl: void 0,
            slideWidth: void 0,
            slideHeight: void 0,
            $imageEl: void 0,
            $imageWrapEl: void 0,
            maxRatio: 3
        },
        t = {
            isTouched: void 0,
            isMoved: void 0,
            currentX: void 0,
            currentY: void 0,
            minX: void 0,
            minY: void 0,
            maxX: void 0,
            maxY: void 0,
            width: void 0,
            height: void 0,
            startX: void 0,
            startY: void 0,
            touchesStart: {},
            touchesCurrent: {}
        },
        n = {
            x: void 0,
            y: void 0,
            prevPositionX: void 0,
            prevPositionY: void 0,
            prevTime: void 0
        };
    let o = 1;
    Object.defineProperty(e.zoom, "scale", {
        get() {
            return o
        },
        set(h) {
            if (o !== h) {
                const I = a.$imageEl ? a.$imageEl[0] : void 0,
                    P = a.$slideEl ? a.$slideEl[0] : void 0;
                E("zoomChange", h, I, P)
            }
            o = h
        }
    });

    function c(h) {
        if (h.targetTouches.length < 2) return 1;
        const I = h.targetTouches[0].pageX,
            P = h.targetTouches[0].pageY,
            A = h.targetTouches[1].pageX,
            L = h.targetTouches[1].pageY;
        return Math.sqrt((A - I) ** 2 + (L - P) ** 2)
    }

    function s(h) {
        const I = e.support,
            P = e.params.zoom;
        if (d = !1, i = !1, !I.gestures) {
            if (h.type !== "touchstart" || h.type === "touchstart" && h.targetTouches.length < 2) return;
            d = !0, a.scaleStart = c(h)
        }
        if ((!a.$slideEl || !a.$slideEl.length) && (a.$slideEl = X(h.target).closest(`.${e.params.slideClass}`), a.$slideEl.length === 0 && (a.$slideEl = e.slides.eq(e.activeIndex)), a.$imageEl = a.$slideEl.find(`.${P.containerClass}`).eq(0).find("picture, img, svg, canvas, .swiper-zoom-target").eq(0), a.$imageWrapEl = a.$imageEl.parent(`.${P.containerClass}`), a.maxRatio = a.$imageWrapEl.attr("data-swiper-zoom") || P.maxRatio, a.$imageWrapEl.length === 0)) {
            a.$imageEl = void 0;
            return
        }
        a.$imageEl && a.$imageEl.transition(0), v = !0
    }

    function r(h) {
        const I = e.support,
            P = e.params.zoom,
            A = e.zoom;
        if (!I.gestures) {
            if (h.type !== "touchmove" || h.type === "touchmove" && h.targetTouches.length < 2) return;
            i = !0, a.scaleMove = c(h)
        }
        if (!a.$imageEl || a.$imageEl.length === 0) {
            h.type === "gesturechange" && s(h);
            return
        }
        I.gestures ? A.scale = h.scale * b : A.scale = a.scaleMove / a.scaleStart * b, A.scale > a.maxRatio && (A.scale = a.maxRatio - 1 + (A.scale - a.maxRatio + 1) ** .5), A.scale < P.minRatio && (A.scale = P.minRatio + 1 - (P.minRatio - A.scale + 1) ** .5), a.$imageEl.transform(`translate3d(0,0,0) scale(${A.scale})`)
    }

    function g(h) {
        const I = e.device,
            P = e.support,
            A = e.params.zoom,
            L = e.zoom;
        if (!P.gestures) {
            if (!d || !i || h.type !== "touchend" || h.type === "touchend" && h.changedTouches.length < 2 && !I.android) return;
            d = !1, i = !1
        }!a.$imageEl || a.$imageEl.length === 0 || (L.scale = Math.max(Math.min(L.scale, a.maxRatio), A.minRatio), a.$imageEl.transition(e.params.speed).transform(`translate3d(0,0,0) scale(${L.scale})`), b = L.scale, v = !1, L.scale === 1 && (a.$slideEl = void 0))
    }

    function l(h) {
        const I = e.device;
        !a.$imageEl || a.$imageEl.length === 0 || t.isTouched || (I.android && h.cancelable && h.preventDefault(), t.isTouched = !0, t.touchesStart.x = h.type === "touchstart" ? h.targetTouches[0].pageX : h.pageX, t.touchesStart.y = h.type === "touchstart" ? h.targetTouches[0].pageY : h.pageY)
    }

    function m(h) {
        const I = e.zoom;
        if (!a.$imageEl || a.$imageEl.length === 0 || (e.allowClick = !1, !t.isTouched || !a.$slideEl)) return;
        t.isMoved || (t.width = a.$imageEl[0].offsetWidth, t.height = a.$imageEl[0].offsetHeight, t.startX = pe(a.$imageWrapEl[0], "x") || 0, t.startY = pe(a.$imageWrapEl[0], "y") || 0, a.slideWidth = a.$slideEl[0].offsetWidth, a.slideHeight = a.$slideEl[0].offsetHeight, a.$imageWrapEl.transition(0));
        const P = t.width * I.scale,
            A = t.height * I.scale;
        if (!(P < a.slideWidth && A < a.slideHeight)) {
            if (t.minX = Math.min(a.slideWidth / 2 - P / 2, 0), t.maxX = -t.minX, t.minY = Math.min(a.slideHeight / 2 - A / 2, 0), t.maxY = -t.minY, t.touchesCurrent.x = h.type === "touchmove" ? h.targetTouches[0].pageX : h.pageX, t.touchesCurrent.y = h.type === "touchmove" ? h.targetTouches[0].pageY : h.pageY, !t.isMoved && !v) {
                if (e.isHorizontal() && (Math.floor(t.minX) === Math.floor(t.startX) && t.touchesCurrent.x < t.touchesStart.x || Math.floor(t.maxX) === Math.floor(t.startX) && t.touchesCurrent.x > t.touchesStart.x)) {
                    t.isTouched = !1;
                    return
                }
                if (!e.isHorizontal() && (Math.floor(t.minY) === Math.floor(t.startY) && t.touchesCurrent.y < t.touchesStart.y || Math.floor(t.maxY) === Math.floor(t.startY) && t.touchesCurrent.y > t.touchesStart.y)) {
                    t.isTouched = !1;
                    return
                }
            }
            h.cancelable && h.preventDefault(), h.stopPropagation(), t.isMoved = !0, t.currentX = t.touchesCurrent.x - t.touchesStart.x + t.startX, t.currentY = t.touchesCurrent.y - t.touchesStart.y + t.startY, t.currentX < t.minX && (t.currentX = t.minX + 1 - (t.minX - t.currentX + 1) ** .8), t.currentX > t.maxX && (t.currentX = t.maxX - 1 + (t.currentX - t.maxX + 1) ** .8), t.currentY < t.minY && (t.currentY = t.minY + 1 - (t.minY - t.currentY + 1) ** .8), t.currentY > t.maxY && (t.currentY = t.maxY - 1 + (t.currentY - t.maxY + 1) ** .8), n.prevPositionX || (n.prevPositionX = t.touchesCurrent.x), n.prevPositionY || (n.prevPositionY = t.touchesCurrent.y), n.prevTime || (n.prevTime = Date.now()), n.x = (t.touchesCurrent.x - n.prevPositionX) / (Date.now() - n.prevTime) / 2, n.y = (t.touchesCurrent.y - n.prevPositionY) / (Date.now() - n.prevTime) / 2, Math.abs(t.touchesCurrent.x - n.prevPositionX) < 2 && (n.x = 0), Math.abs(t.touchesCurrent.y - n.prevPositionY) < 2 && (n.y = 0), n.prevPositionX = t.touchesCurrent.x, n.prevPositionY = t.touchesCurrent.y, n.prevTime = Date.now(), a.$imageWrapEl.transform(`translate3d(${t.currentX}px, ${t.currentY}px,0)`)
        }
    }

    function D() {
        const h = e.zoom;
        if (!a.$imageEl || a.$imageEl.length === 0) return;
        if (!t.isTouched || !t.isMoved) {
            t.isTouched = !1, t.isMoved = !1;
            return
        }
        t.isTouched = !1, t.isMoved = !1;
        let I = 300,
            P = 300;
        const A = n.x * I,
            L = t.currentX + A,
            B = n.y * P,
            _ = t.currentY + B;
        n.x !== 0 && (I = Math.abs((L - t.currentX) / n.x)), n.y !== 0 && (P = Math.abs((_ - t.currentY) / n.y));
        const Z = Math.max(I, P);
        t.currentX = L, t.currentY = _;
        const Q = t.width * h.scale,
            R = t.height * h.scale;
        t.minX = Math.min(a.slideWidth / 2 - Q / 2, 0), t.maxX = -t.minX, t.minY = Math.min(a.slideHeight / 2 - R / 2, 0), t.maxY = -t.minY, t.currentX = Math.max(Math.min(t.currentX, t.maxX), t.minX), t.currentY = Math.max(Math.min(t.currentY, t.maxY), t.minY), a.$imageWrapEl.transition(Z).transform(`translate3d(${t.currentX}px, ${t.currentY}px,0)`)
    }

    function T() {
        const h = e.zoom;
        a.$slideEl && e.previousIndex !== e.activeIndex && (a.$imageEl && a.$imageEl.transform("translate3d(0,0,0) scale(1)"), a.$imageWrapEl && a.$imageWrapEl.transform("translate3d(0,0,0)"), h.scale = 1, b = 1, a.$slideEl = void 0, a.$imageEl = void 0, a.$imageWrapEl = void 0)
    }

    function z(h) {
        const I = e.zoom,
            P = e.params.zoom;
        if (a.$slideEl || (h && h.target && (a.$slideEl = X(h.target).closest(`.${e.params.slideClass}`)), a.$slideEl || (e.params.virtual && e.params.virtual.enabled && e.virtual ? a.$slideEl = e.$wrapperEl.children(`.${e.params.slideActiveClass}`) : a.$slideEl = e.slides.eq(e.activeIndex)), a.$imageEl = a.$slideEl.find(`.${P.containerClass}`).eq(0).find("picture, img, svg, canvas, .swiper-zoom-target").eq(0), a.$imageWrapEl = a.$imageEl.parent(`.${P.containerClass}`)), !a.$imageEl || a.$imageEl.length === 0 || !a.$imageWrapEl || a.$imageWrapEl.length === 0) return;
        e.params.cssMode && (e.wrapperEl.style.overflow = "hidden", e.wrapperEl.style.touchAction = "none"), a.$slideEl.addClass(`${P.zoomedSlideClass}`);
        let A, L, B, _, Z, Q, R, G, le, oe, de, ce, J, ee, ae, se, ie, re;
        typeof t.touchesStart.x == "undefined" && h ? (A = h.type === "touchend" ? h.changedTouches[0].pageX : h.pageX, L = h.type === "touchend" ? h.changedTouches[0].pageY : h.pageY) : (A = t.touchesStart.x, L = t.touchesStart.y), I.scale = a.$imageWrapEl.attr("data-swiper-zoom") || P.maxRatio, b = a.$imageWrapEl.attr("data-swiper-zoom") || P.maxRatio, h ? (ie = a.$slideEl[0].offsetWidth, re = a.$slideEl[0].offsetHeight, B = a.$slideEl.offset().left + $.scrollX, _ = a.$slideEl.offset().top + $.scrollY, Z = B + ie / 2 - A, Q = _ + re / 2 - L, le = a.$imageEl[0].offsetWidth, oe = a.$imageEl[0].offsetHeight, de = le * I.scale, ce = oe * I.scale, J = Math.min(ie / 2 - de / 2, 0), ee = Math.min(re / 2 - ce / 2, 0), ae = -J, se = -ee, R = Z * I.scale, G = Q * I.scale, R < J && (R = J), R > ae && (R = ae), G < ee && (G = ee), G > se && (G = se)) : (R = 0, G = 0), a.$imageWrapEl.transition(300).transform(`translate3d(${R}px, ${G}px,0)`), a.$imageEl.transition(300).transform(`translate3d(0,0,0) scale(${I.scale})`)
    }

    function M() {
        const h = e.zoom,
            I = e.params.zoom;
        a.$slideEl || (e.params.virtual && e.params.virtual.enabled && e.virtual ? a.$slideEl = e.$wrapperEl.children(`.${e.params.slideActiveClass}`) : a.$slideEl = e.slides.eq(e.activeIndex), a.$imageEl = a.$slideEl.find(`.${I.containerClass}`).eq(0).find("picture, img, svg, canvas, .swiper-zoom-target").eq(0), a.$imageWrapEl = a.$imageEl.parent(`.${I.containerClass}`)), !(!a.$imageEl || a.$imageEl.length === 0 || !a.$imageWrapEl || a.$imageWrapEl.length === 0) && (e.params.cssMode && (e.wrapperEl.style.overflow = "", e.wrapperEl.style.touchAction = ""), h.scale = 1, b = 1, a.$imageWrapEl.transition(300).transform("translate3d(0,0,0)"), a.$imageEl.transition(300).transform("translate3d(0,0,0) scale(1)"), a.$slideEl.removeClass(`${I.zoomedSlideClass}`), a.$slideEl = void 0)
    }

    function O(h) {
        const I = e.zoom;
        I.scale && I.scale !== 1 ? M() : z(h)
    }

    function k() {
        const h = e.support,
            I = e.touchEvents.start === "touchstart" && h.passiveListener && e.params.passiveListeners ? {
                passive: !0,
                capture: !1
            } : !1,
            P = h.passiveListener ? {
                passive: !1,
                capture: !0
            } : !0;
        return {
            passiveListener: I,
            activeListenerWithCapture: P
        }
    }

    function w() {
        return `.${e.params.slideClass}`
    }

    function p(h) {
        const {
            passiveListener: I
        } = k(), P = w();
        e.$wrapperEl[h]("gesturestart", P, s, I), e.$wrapperEl[h]("gesturechange", P, r, I), e.$wrapperEl[h]("gestureend", P, g, I)
    }

    function y() {
        f || (f = !0, p("on"))
    }

    function S() {
        !f || (f = !1, p("off"))
    }

    function Y() {
        const h = e.zoom;
        if (h.enabled) return;
        h.enabled = !0;
        const I = e.support,
            {
                passiveListener: P,
                activeListenerWithCapture: A
            } = k(),
            L = w();
        I.gestures ? (e.$wrapperEl.on(e.touchEvents.start, y, P), e.$wrapperEl.on(e.touchEvents.end, S, P)) : e.touchEvents.start === "touchstart" && (e.$wrapperEl.on(e.touchEvents.start, L, s, P), e.$wrapperEl.on(e.touchEvents.move, L, r, A), e.$wrapperEl.on(e.touchEvents.end, L, g, P), e.touchEvents.cancel && e.$wrapperEl.on(e.touchEvents.cancel, L, g, P)), e.$wrapperEl.on(e.touchEvents.move, `.${e.params.zoom.containerClass}`, m, A)
    }

    function H() {
        const h = e.zoom;
        if (!h.enabled) return;
        const I = e.support;
        h.enabled = !1;
        const {
            passiveListener: P,
            activeListenerWithCapture: A
        } = k(), L = w();
        I.gestures ? (e.$wrapperEl.off(e.touchEvents.start, y, P), e.$wrapperEl.off(e.touchEvents.end, S, P)) : e.touchEvents.start === "touchstart" && (e.$wrapperEl.off(e.touchEvents.start, L, s, P), e.$wrapperEl.off(e.touchEvents.move, L, r, A), e.$wrapperEl.off(e.touchEvents.end, L, g, P), e.touchEvents.cancel && e.$wrapperEl.off(e.touchEvents.cancel, L, g, P)), e.$wrapperEl.off(e.touchEvents.move, `.${e.params.zoom.containerClass}`, m, A)
    }
    u("init", () => {
        e.params.zoom.enabled && Y()
    }), u("destroy", () => {
        H()
    }), u("touchStart", (h, I) => {
        !e.zoom.enabled || l(I)
    }), u("touchEnd", (h, I) => {
        !e.zoom.enabled || D()
    }), u("doubleTap", (h, I) => {
        !e.animating && e.params.zoom.enabled && e.zoom.enabled && e.params.zoom.toggle && O(I)
    }), u("transitionEnd", () => {
        e.zoom.enabled && e.params.zoom.enabled && T()
    }), u("slideChange", () => {
        e.zoom.enabled && e.params.zoom.enabled && e.params.cssMode && T()
    }), Object.assign(e.zoom, {
        enable: Y,
        disable: H,
        in: z,
        out: M,
        toggle: O
    })
}

function Pe(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C;
    x({
        lazy: {
            checkInView: !1,
            enabled: !1,
            loadPrevNext: !1,
            loadPrevNextAmount: 1,
            loadOnTransitionStart: !1,
            scrollingElement: "",
            elementClass: "swiper-lazy",
            loadingClass: "swiper-lazy-loading",
            loadedClass: "swiper-lazy-loaded",
            preloaderClass: "swiper-lazy-preloader"
        }
    }), e.lazy = {};
    let $ = !1,
        b = !1;

    function v(i, a) {
        a === void 0 && (a = !0);
        const t = e.params.lazy;
        if (typeof i == "undefined" || e.slides.length === 0) return;
        const o = e.virtual && e.params.virtual.enabled ? e.$wrapperEl.children(`.${e.params.slideClass}[data-swiper-slide-index="${i}"]`) : e.slides.eq(i),
            c = o.find(`.${t.elementClass}:not(.${t.loadedClass}):not(.${t.loadingClass})`);
        o.hasClass(t.elementClass) && !o.hasClass(t.loadedClass) && !o.hasClass(t.loadingClass) && c.push(o[0]), c.length !== 0 && c.each(s => {
            const r = X(s);
            r.addClass(t.loadingClass);
            const g = r.attr("data-background"),
                l = r.attr("data-src"),
                m = r.attr("data-srcset"),
                D = r.attr("data-sizes"),
                T = r.parent("picture");
            e.loadImage(r[0], l || g, m, D, !1, () => {
                if (!(typeof e == "undefined" || e === null || !e || e && !e.params || e.destroyed)) {
                    if (g ? (r.css("background-image", `url("${g}")`), r.removeAttr("data-background")) : (m && (r.attr("srcset", m), r.removeAttr("data-srcset")), D && (r.attr("sizes", D), r.removeAttr("data-sizes")), T.length && T.children("source").each(z => {
                            const M = X(z);
                            M.attr("data-srcset") && (M.attr("srcset", M.attr("data-srcset")), M.removeAttr("data-srcset"))
                        }), l && (r.attr("src", l), r.removeAttr("data-src"))), r.addClass(t.loadedClass).removeClass(t.loadingClass), o.find(`.${t.preloaderClass}`).remove(), e.params.loop && a) {
                        const z = o.attr("data-swiper-slide-index");
                        if (o.hasClass(e.params.slideDuplicateClass)) {
                            const M = e.$wrapperEl.children(`[data-swiper-slide-index="${z}"]:not(.${e.params.slideDuplicateClass})`);
                            v(M.index(), !1)
                        } else {
                            const M = e.$wrapperEl.children(`.${e.params.slideDuplicateClass}[data-swiper-slide-index="${z}"]`);
                            v(M.index(), !1)
                        }
                    }
                    E("lazyImageReady", o[0], r[0]), e.params.autoHeight && e.updateAutoHeight()
                }
            }), E("lazyImageLoad", o[0], r[0])
        })
    }

    function f() {
        const {
            $wrapperEl: i,
            params: a,
            slides: t,
            activeIndex: n
        } = e, o = e.virtual && a.virtual.enabled, c = a.lazy;
        let s = a.slidesPerView;
        s === "auto" && (s = 0);

        function r(l) {
            if (o) {
                if (i.children(`.${a.slideClass}[data-swiper-slide-index="${l}"]`).length) return !0
            } else if (t[l]) return !0;
            return !1
        }

        function g(l) {
            return o ? X(l).attr("data-swiper-slide-index") : X(l).index()
        }
        if (b || (b = !0), e.params.watchSlidesProgress) i.children(`.${a.slideVisibleClass}`).each(l => {
            const m = o ? X(l).attr("data-swiper-slide-index") : X(l).index();
            v(m)
        });
        else if (s > 1)
            for (let l = n; l < n + s; l += 1) r(l) && v(l);
        else v(n);
        if (c.loadPrevNext)
            if (s > 1 || c.loadPrevNextAmount && c.loadPrevNextAmount > 1) {
                const l = c.loadPrevNextAmount,
                    m = Math.ceil(s),
                    D = Math.min(n + m + Math.max(l, m), t.length),
                    T = Math.max(n - Math.max(m, l), 0);
                for (let z = n + m; z < D; z += 1) r(z) && v(z);
                for (let z = T; z < n; z += 1) r(z) && v(z)
            } else {
                const l = i.children(`.${a.slideNextClass}`);
                l.length > 0 && v(g(l));
                const m = i.children(`.${a.slidePrevClass}`);
                m.length > 0 && v(g(m))
            }
    }

    function d() {
        const i = W();
        if (!e || e.destroyed) return;
        const a = e.params.lazy.scrollingElement ? X(e.params.lazy.scrollingElement) : X(i),
            t = a[0] === i,
            n = t ? i.innerWidth : a[0].offsetWidth,
            o = t ? i.innerHeight : a[0].offsetHeight,
            c = e.$el.offset(),
            {
                rtlTranslate: s
            } = e;
        let r = !1;
        s && (c.left -= e.$el[0].scrollLeft);
        const g = [
            [c.left, c.top],
            [c.left + e.width, c.top],
            [c.left, c.top + e.height],
            [c.left + e.width, c.top + e.height]
        ];
        for (let m = 0; m < g.length; m += 1) {
            const D = g[m];
            if (D[0] >= 0 && D[0] <= n && D[1] >= 0 && D[1] <= o) {
                if (D[0] === 0 && D[1] === 0) continue;
                r = !0
            }
        }
        const l = e.touchEvents.start === "touchstart" && e.support.passiveListener && e.params.passiveListeners ? {
            passive: !0,
            capture: !1
        } : !1;
        r ? (f(), a.off("scroll", d, l)) : $ || ($ = !0, a.on("scroll", d, l))
    }
    u("beforeInit", () => {
        e.params.lazy.enabled && e.params.preloadImages && (e.params.preloadImages = !1)
    }), u("init", () => {
        e.params.lazy.enabled && (e.params.lazy.checkInView ? d() : f())
    }), u("scroll", () => {
        e.params.freeMode && e.params.freeMode.enabled && !e.params.freeMode.sticky && f()
    }), u("scrollbarDragMove resize _freeModeNoMomentumRelease", () => {
        e.params.lazy.enabled && (e.params.lazy.checkInView ? d() : f())
    }), u("transitionStart", () => {
        e.params.lazy.enabled && (e.params.lazy.loadOnTransitionStart || !e.params.lazy.loadOnTransitionStart && !b) && (e.params.lazy.checkInView ? d() : f())
    }), u("transitionEnd", () => {
        e.params.lazy.enabled && !e.params.lazy.loadOnTransitionStart && (e.params.lazy.checkInView ? d() : f())
    }), u("slideChange", () => {
        const {
            lazy: i,
            cssMode: a,
            watchSlidesProgress: t,
            touchReleaseOnEdges: n,
            resistanceRatio: o
        } = e.params;
        i.enabled && (a || t && (n || o === 0)) && f()
    }), u("destroy", () => {
        !e.$el || e.$el.find(`.${e.params.lazy.loadingClass}`).removeClass(e.params.lazy.loadingClass)
    }), Object.assign(e.lazy, {
        load: f,
        loadInSlide: v
    })
}

function ze(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        controller: {
            control: void 0,
            inverse: !1,
            by: "slide"
        }
    }), e.controller = {
        control: void 0
    };

    function E(d, i) {
        const a = function() {
            let c, s, r;
            return (g, l) => {
                for (s = -1, c = g.length; c - s > 1;) r = c + s >> 1, g[r] <= l ? s = r : c = r;
                return c
            }
        }();
        this.x = d, this.y = i, this.lastIndex = d.length - 1;
        let t, n;
        return this.interpolate = function(c) {
            return c ? (n = a(this.x, c), t = n - 1, (c - this.x[t]) * (this.y[n] - this.y[t]) / (this.x[n] - this.x[t]) + this.y[t]) : 0
        }, this
    }

    function $(d) {
        e.controller.spline || (e.controller.spline = e.params.loop ? new E(e.slidesGrid, d.slidesGrid) : new E(e.snapGrid, d.snapGrid))
    }

    function b(d, i) {
        const a = e.controller.control;
        let t, n;
        const o = e.constructor;

        function c(s) {
            const r = e.rtlTranslate ? -e.translate : e.translate;
            e.params.controller.by === "slide" && ($(s), n = -e.controller.spline.interpolate(-r)), (!n || e.params.controller.by === "container") && (t = (s.maxTranslate() - s.minTranslate()) / (e.maxTranslate() - e.minTranslate()), n = (r - e.minTranslate()) * t + s.minTranslate()), e.params.controller.inverse && (n = s.maxTranslate() - n), s.updateProgress(n), s.setTranslate(n, e), s.updateActiveIndex(), s.updateSlidesClasses()
        }
        if (Array.isArray(a))
            for (let s = 0; s < a.length; s += 1) a[s] !== i && a[s] instanceof o && c(a[s]);
        else a instanceof o && i !== a && c(a)
    }

    function v(d, i) {
        const a = e.constructor,
            t = e.controller.control;
        let n;

        function o(c) {
            c.setTransition(d, e), d !== 0 && (c.transitionStart(), c.params.autoHeight && U(() => {
                c.updateAutoHeight()
            }), c.$wrapperEl.transitionEnd(() => {
                !t || (c.params.loop && e.params.controller.by === "slide" && c.loopFix(), c.transitionEnd())
            }))
        }
        if (Array.isArray(t))
            for (n = 0; n < t.length; n += 1) t[n] !== i && t[n] instanceof a && o(t[n]);
        else t instanceof a && i !== t && o(t)
    }

    function f() {
        !e.controller.control || e.controller.spline && (e.controller.spline = void 0, delete e.controller.spline)
    }
    u("beforeInit", () => {
        e.controller.control = e.params.controller.control
    }), u("update", () => {
        f()
    }), u("resize", () => {
        f()
    }), u("observerUpdate", () => {
        f()
    }), u("setTranslate", (d, i, a) => {
        !e.controller.control || e.controller.setTranslate(i, a)
    }), u("setTransition", (d, i, a) => {
        !e.controller.control || e.controller.setTransition(i, a)
    }), Object.assign(e.controller, {
        setTranslate: b,
        setTransition: v
    })
}

function Ie(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        a11y: {
            enabled: !0,
            notificationClass: "swiper-notification",
            prevSlideMessage: "Previous slide",
            nextSlideMessage: "Next slide",
            firstSlideMessage: "This is the first slide",
            lastSlideMessage: "This is the last slide",
            paginationBulletMessage: "Go to slide {{index}}",
            slideLabelMessage: "{{index}} / {{slidesLength}}",
            containerMessage: null,
            containerRoleDescriptionMessage: null,
            itemRoleDescriptionMessage: null,
            slideRole: "group",
            id: null
        }
    });
    let E = null;

    function $(w) {
        const p = E;
        p.length !== 0 && (p.html(""), p.html(w))
    }

    function b(w) {
        w === void 0 && (w = 16);
        const p = () => Math.round(16 * Math.random()).toString(16);
        return "x".repeat(w).replace(/x/g, p)
    }

    function v(w) {
        w.attr("tabIndex", "0")
    }

    function f(w) {
        w.attr("tabIndex", "-1")
    }

    function d(w, p) {
        w.attr("role", p)
    }

    function i(w, p) {
        w.attr("aria-roledescription", p)
    }

    function a(w, p) {
        w.attr("aria-controls", p)
    }

    function t(w, p) {
        w.attr("aria-label", p)
    }

    function n(w, p) {
        w.attr("id", p)
    }

    function o(w, p) {
        w.attr("aria-live", p)
    }

    function c(w) {
        w.attr("aria-disabled", !0)
    }

    function s(w) {
        w.attr("aria-disabled", !1)
    }

    function r(w) {
        if (w.keyCode !== 13 && w.keyCode !== 32) return;
        const p = e.params.a11y,
            y = X(w.target);
        e.navigation && e.navigation.$nextEl && y.is(e.navigation.$nextEl) && (e.isEnd && !e.params.loop || e.slideNext(), e.isEnd ? $(p.lastSlideMessage) : $(p.nextSlideMessage)), e.navigation && e.navigation.$prevEl && y.is(e.navigation.$prevEl) && (e.isBeginning && !e.params.loop || e.slidePrev(), e.isBeginning ? $(p.firstSlideMessage) : $(p.prevSlideMessage)), e.pagination && y.is(N(e.params.pagination.bulletClass)) && y[0].click()
    }

    function g() {
        if (e.params.loop || e.params.rewind || !e.navigation) return;
        const {
            $nextEl: w,
            $prevEl: p
        } = e.navigation;
        p && p.length > 0 && (e.isBeginning ? (c(p), f(p)) : (s(p), v(p))), w && w.length > 0 && (e.isEnd ? (c(w), f(w)) : (s(w), v(w)))
    }

    function l() {
        return e.pagination && e.pagination.bullets && e.pagination.bullets.length
    }

    function m() {
        return l() && e.params.pagination.clickable
    }

    function D() {
        const w = e.params.a11y;
        !l() || e.pagination.bullets.each(p => {
            const y = X(p);
            e.params.pagination.clickable && (v(y), e.params.pagination.renderBullet || (d(y, "button"), t(y, w.paginationBulletMessage.replace(/\{\{index\}\}/, y.index() + 1)))), y.is(`.${e.params.pagination.bulletActiveClass}`) ? y.attr("aria-current", "true") : y.removeAttr("aria-current")
        })
    }
    const T = (w, p, y) => {
            v(w), w[0].tagName !== "BUTTON" && (d(w, "button"), w.on("keydown", r)), t(w, y), a(w, p)
        },
        z = w => {
            const p = w.target.closest(`.${e.params.slideClass}`);
            if (!p || !e.slides.includes(p)) return;
            const y = e.slides.indexOf(p) === e.activeIndex,
                S = e.params.watchSlidesProgress && e.visibleSlides && e.visibleSlides.includes(p);
            y || S || (e.isHorizontal() ? e.el.scrollLeft = 0 : e.el.scrollTop = 0, e.slideTo(e.slides.indexOf(p), 0))
        },
        M = () => {
            const w = e.params.a11y;
            w.itemRoleDescriptionMessage && i(X(e.slides), w.itemRoleDescriptionMessage), w.slideRole && d(X(e.slides), w.slideRole);
            const p = e.params.loop ? e.slides.filter(y => !y.classList.contains(e.params.slideDuplicateClass)).length : e.slides.length;
            w.slideLabelMessage && e.slides.each((y, S) => {
                const Y = X(y),
                    H = e.params.loop ? parseInt(Y.attr("data-swiper-slide-index"), 10) : S,
                    h = w.slideLabelMessage.replace(/\{\{index\}\}/, H + 1).replace(/\{\{slidesLength\}\}/, p);
                t(Y, h)
            })
        },
        O = () => {
            const w = e.params.a11y;
            e.$el.append(E);
            const p = e.$el;
            w.containerRoleDescriptionMessage && i(p, w.containerRoleDescriptionMessage), w.containerMessage && t(p, w.containerMessage);
            const y = e.$wrapperEl,
                S = w.id || y.attr("id") || `swiper-wrapper-${b(16)}`,
                Y = e.params.autoplay && e.params.autoplay.enabled ? "off" : "polite";
            n(y, S), o(y, Y), M();
            let H, h;
            e.navigation && e.navigation.$nextEl && (H = e.navigation.$nextEl), e.navigation && e.navigation.$prevEl && (h = e.navigation.$prevEl), H && H.length && T(H, S, w.nextSlideMessage), h && h.length && T(h, S, w.prevSlideMessage), m() && e.pagination.$el.on("keydown", N(e.params.pagination.bulletClass), r), e.$el.on("focus", z, !0)
        };

    function k() {
        E && E.length > 0 && E.remove();
        let w, p;
        e.navigation && e.navigation.$nextEl && (w = e.navigation.$nextEl), e.navigation && e.navigation.$prevEl && (p = e.navigation.$prevEl), w && w.off("keydown", r), p && p.off("keydown", r), m() && e.pagination.$el.off("keydown", N(e.params.pagination.bulletClass), r), e.$el.off("focus", z, !0)
    }
    u("beforeInit", () => {
        E = X(`<span class="${e.params.a11y.notificationClass}" aria-live="assertive" aria-atomic="true"></span>`)
    }), u("afterInit", () => {
        !e.params.a11y.enabled || O()
    }), u("slidesLengthChange snapGridLengthChange slidesGridLengthChange", () => {
        !e.params.a11y.enabled || M()
    }), u("fromEdge toEdge afterInit lock unlock", () => {
        !e.params.a11y.enabled || g()
    }), u("paginationUpdate", () => {
        !e.params.a11y.enabled || D()
    }), u("destroy", () => {
        !e.params.a11y.enabled || k()
    })
}

function ke(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        history: {
            enabled: !1,
            root: "",
            replaceState: !1,
            key: "slides",
            keepQuery: !1
        }
    });
    let E = !1,
        $ = {};
    const b = n => n.toString().replace(/\s+/g, "-").replace(/[^\w-]+/g, "").replace(/--+/g, "-").replace(/^-+/, "").replace(/-+$/, ""),
        v = n => {
            const o = W();
            let c;
            n ? c = new URL(n) : c = o.location;
            const s = c.pathname.slice(1).split("/").filter(m => m !== ""),
                r = s.length,
                g = s[r - 2],
                l = s[r - 1];
            return {
                key: g,
                value: l
            }
        },
        f = (n, o) => {
            const c = W();
            if (!E || !e.params.history.enabled) return;
            let s;
            e.params.url ? s = new URL(e.params.url) : s = c.location;
            const r = e.slides.eq(o);
            let g = b(r.attr("data-history"));
            if (e.params.history.root.length > 0) {
                let m = e.params.history.root;
                m[m.length - 1] === "/" && (m = m.slice(0, m.length - 1)), g = `${m}/${n}/${g}`
            } else s.pathname.includes(n) || (g = `${n}/${g}`);
            e.params.history.keepQuery && (g += s.search);
            const l = c.history.state;
            l && l.value === g || (e.params.history.replaceState ? c.history.replaceState({
                value: g
            }, null, g) : c.history.pushState({
                value: g
            }, null, g))
        },
        d = (n, o, c) => {
            if (o)
                for (let s = 0, r = e.slides.length; s < r; s += 1) {
                    const g = e.slides.eq(s);
                    if (b(g.attr("data-history")) === o && !g.hasClass(e.params.slideDuplicateClass)) {
                        const m = g.index();
                        e.slideTo(m, n, c)
                    }
                } else e.slideTo(0, n, c)
        },
        i = () => {
            $ = v(e.params.url), d(e.params.speed, $.value, !1)
        },
        a = () => {
            const n = W();
            if (!!e.params.history) {
                if (!n.history || !n.history.pushState) {
                    e.params.history.enabled = !1, e.params.hashNavigation.enabled = !0;
                    return
                }
                E = !0, $ = v(e.params.url), !(!$.key && !$.value) && (d(0, $.value, e.params.runCallbacksOnInit), e.params.history.replaceState || n.addEventListener("popstate", i))
            }
        },
        t = () => {
            const n = W();
            e.params.history.replaceState || n.removeEventListener("popstate", i)
        };
    u("init", () => {
        e.params.history.enabled && a()
    }), u("destroy", () => {
        e.params.history.enabled && t()
    }), u("transitionEnd _freeModeNoMomentumRelease", () => {
        E && f(e.params.history.key, e.activeIndex)
    }), u("slideChange", () => {
        E && e.params.cssMode && f(e.params.history.key, e.activeIndex)
    })
}

function Oe(C) {
    let {
        swiper: e,
        extendParams: x,
        emit: u,
        on: E
    } = C, $ = !1;
    const b = V(),
        v = W();
    x({
        hashNavigation: {
            enabled: !1,
            replaceState: !1,
            watchState: !1
        }
    });
    const f = () => {
            u("hashChange");
            const t = b.location.hash.replace("#", ""),
                n = e.slides.eq(e.activeIndex).attr("data-hash");
            if (t !== n) {
                const o = e.$wrapperEl.children(`.${e.params.slideClass}[data-hash="${t}"]`).index();
                if (typeof o == "undefined") return;
                e.slideTo(o)
            }
        },
        d = () => {
            if (!(!$ || !e.params.hashNavigation.enabled))
                if (e.params.hashNavigation.replaceState && v.history && v.history.replaceState) v.history.replaceState(null, null, `#${e.slides.eq(e.activeIndex).attr("data-hash")}` || ""), u("hashSet");
                else {
                    const t = e.slides.eq(e.activeIndex),
                        n = t.attr("data-hash") || t.attr("data-history");
                    b.location.hash = n || "", u("hashSet")
                }
        },
        i = () => {
            if (!e.params.hashNavigation.enabled || e.params.history && e.params.history.enabled) return;
            $ = !0;
            const t = b.location.hash.replace("#", "");
            if (t)
                for (let o = 0, c = e.slides.length; o < c; o += 1) {
                    const s = e.slides.eq(o);
                    if ((s.attr("data-hash") || s.attr("data-history")) === t && !s.hasClass(e.params.slideDuplicateClass)) {
                        const g = s.index();
                        e.slideTo(g, 0, e.params.runCallbacksOnInit, !0)
                    }
                }
            e.params.hashNavigation.watchState && X(v).on("hashchange", f)
        },
        a = () => {
            e.params.hashNavigation.watchState && X(v).off("hashchange", f)
        };
    E("init", () => {
        e.params.hashNavigation.enabled && i()
    }), E("destroy", () => {
        e.params.hashNavigation.enabled && a()
    }), E("transitionEnd _freeModeNoMomentumRelease", () => {
        $ && d()
    }), E("slideChange", () => {
        $ && e.params.cssMode && d()
    })
}

function De(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u,
        emit: E
    } = C, $;
    e.autoplay = {
        running: !1,
        paused: !1
    }, x({
        autoplay: {
            enabled: !1,
            delay: 3e3,
            waitForTransition: !0,
            disableOnInteraction: !0,
            stopOnLastSlide: !1,
            reverseDirection: !1,
            pauseOnMouseEnter: !1
        }
    });

    function b() {
        if (!e.size) {
            e.autoplay.running = !1, e.autoplay.paused = !1;
            return
        }
        const s = e.slides.eq(e.activeIndex);
        let r = e.params.autoplay.delay;
        s.attr("data-swiper-autoplay") && (r = s.attr("data-swiper-autoplay") || e.params.autoplay.delay), clearTimeout($), $ = U(() => {
            let g;
            e.params.autoplay.reverseDirection ? e.params.loop ? (e.loopFix(), g = e.slidePrev(e.params.speed, !0, !0), E("autoplay")) : e.isBeginning ? e.params.autoplay.stopOnLastSlide ? f() : (g = e.slideTo(e.slides.length - 1, e.params.speed, !0, !0), E("autoplay")) : (g = e.slidePrev(e.params.speed, !0, !0), E("autoplay")) : e.params.loop ? (e.loopFix(), g = e.slideNext(e.params.speed, !0, !0), E("autoplay")) : e.isEnd ? e.params.autoplay.stopOnLastSlide ? f() : (g = e.slideTo(0, e.params.speed, !0, !0), E("autoplay")) : (g = e.slideNext(e.params.speed, !0, !0), E("autoplay")), (e.params.cssMode && e.autoplay.running || g === !1) && b()
        }, r)
    }

    function v() {
        return typeof $ != "undefined" || e.autoplay.running ? !1 : (e.autoplay.running = !0, E("autoplayStart"), b(), !0)
    }

    function f() {
        return !e.autoplay.running || typeof $ == "undefined" ? !1 : ($ && (clearTimeout($), $ = void 0), e.autoplay.running = !1, E("autoplayStop"), !0)
    }

    function d(s) {
        !e.autoplay.running || e.autoplay.paused || ($ && clearTimeout($), e.autoplay.paused = !0, s === 0 || !e.params.autoplay.waitForTransition ? (e.autoplay.paused = !1, b()) : ["transitionend", "webkitTransitionEnd"].forEach(r => {
            e.$wrapperEl[0].addEventListener(r, a)
        }))
    }

    function i() {
        const s = V();
        s.visibilityState === "hidden" && e.autoplay.running && d(), s.visibilityState === "visible" && e.autoplay.paused && (b(), e.autoplay.paused = !1)
    }

    function a(s) {
        !e || e.destroyed || !e.$wrapperEl || s.target === e.$wrapperEl[0] && (["transitionend", "webkitTransitionEnd"].forEach(r => {
            e.$wrapperEl[0].removeEventListener(r, a)
        }), e.autoplay.paused = !1, e.autoplay.running ? b() : f())
    }

    function t() {
        e.params.autoplay.disableOnInteraction ? f() : (E("autoplayPause"), d()), ["transitionend", "webkitTransitionEnd"].forEach(s => {
            e.$wrapperEl[0].removeEventListener(s, a)
        })
    }

    function n() {
        e.params.autoplay.disableOnInteraction || (e.autoplay.paused = !1, E("autoplayResume"), b())
    }

    function o() {
        e.params.autoplay.pauseOnMouseEnter && (e.$el.on("mouseenter", t), e.$el.on("mouseleave", n))
    }

    function c() {
        e.$el.off("mouseenter", t), e.$el.off("mouseleave", n)
    }
    u("init", () => {
        e.params.autoplay.enabled && (v(), V().addEventListener("visibilitychange", i), o())
    }), u("beforeTransitionStart", (s, r, g) => {
        e.autoplay.running && (g || !e.params.autoplay.disableOnInteraction ? e.autoplay.pause(r) : f())
    }), u("sliderFirstMove", () => {
        e.autoplay.running && (e.params.autoplay.disableOnInteraction ? f() : d())
    }), u("touchEnd", () => {
        e.params.cssMode && e.autoplay.paused && !e.params.autoplay.disableOnInteraction && b()
    }), u("destroy", () => {
        c(), e.autoplay.running && f(), V().removeEventListener("visibilitychange", i)
    }), Object.assign(e.autoplay, {
        pause: d,
        run: b,
        start: v,
        stop: f
    })
}

function He(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        thumbs: {
            swiper: null,
            multipleActiveThumbs: !0,
            autoScrollOffset: 0,
            slideThumbActiveClass: "swiper-slide-thumb-active",
            thumbsContainerClass: "swiper-thumbs"
        }
    });
    let E = !1,
        $ = !1;
    e.thumbs = {
        swiper: null
    };

    function b() {
        const d = e.thumbs.swiper;
        if (!d || d.destroyed) return;
        const i = d.clickedIndex,
            a = d.clickedSlide;
        if (a && X(a).hasClass(e.params.thumbs.slideThumbActiveClass) || typeof i == "undefined" || i === null) return;
        let t;
        if (d.params.loop ? t = parseInt(X(d.clickedSlide).attr("data-swiper-slide-index"), 10) : t = i, e.params.loop) {
            let n = e.activeIndex;
            e.slides.eq(n).hasClass(e.params.slideDuplicateClass) && (e.loopFix(), e._clientLeft = e.$wrapperEl[0].clientLeft, n = e.activeIndex);
            const o = e.slides.eq(n).prevAll(`[data-swiper-slide-index="${t}"]`).eq(0).index(),
                c = e.slides.eq(n).nextAll(`[data-swiper-slide-index="${t}"]`).eq(0).index();
            typeof o == "undefined" ? t = c : typeof c == "undefined" ? t = o : c - n < n - o ? t = c : t = o
        }
        e.slideTo(t)
    }

    function v() {
        const {
            thumbs: d
        } = e.params;
        if (E) return !1;
        E = !0;
        const i = e.constructor;
        if (d.swiper instanceof i) e.thumbs.swiper = d.swiper, Object.assign(e.thumbs.swiper.originalParams, {
            watchSlidesProgress: !0,
            slideToClickedSlide: !1
        }), Object.assign(e.thumbs.swiper.params, {
            watchSlidesProgress: !0,
            slideToClickedSlide: !1
        });
        else if (ue(d.swiper)) {
            const a = Object.assign({}, d.swiper);
            Object.assign(a, {
                watchSlidesProgress: !0,
                slideToClickedSlide: !1
            }), e.thumbs.swiper = new i(a), $ = !0
        }
        return e.thumbs.swiper.$el.addClass(e.params.thumbs.thumbsContainerClass), e.thumbs.swiper.on("tap", b), !0
    }

    function f(d) {
        const i = e.thumbs.swiper;
        if (!i || i.destroyed) return;
        const a = i.params.slidesPerView === "auto" ? i.slidesPerViewDynamic() : i.params.slidesPerView;
        let t = 1;
        const n = e.params.thumbs.slideThumbActiveClass;
        if (e.params.slidesPerView > 1 && !e.params.centeredSlides && (t = e.params.slidesPerView), e.params.thumbs.multipleActiveThumbs || (t = 1), t = Math.floor(t), i.slides.removeClass(n), i.params.loop || i.params.virtual && i.params.virtual.enabled)
            for (let s = 0; s < t; s += 1) i.$wrapperEl.children(`[data-swiper-slide-index="${e.realIndex+s}"]`).addClass(n);
        else
            for (let s = 0; s < t; s += 1) i.slides.eq(e.realIndex + s).addClass(n);
        const o = e.params.thumbs.autoScrollOffset,
            c = o && !i.params.loop;
        if (e.realIndex !== i.realIndex || c) {
            let s = i.activeIndex,
                r, g;
            if (i.params.loop) {
                i.slides.eq(s).hasClass(i.params.slideDuplicateClass) && (i.loopFix(), i._clientLeft = i.$wrapperEl[0].clientLeft, s = i.activeIndex);
                const l = i.slides.eq(s).prevAll(`[data-swiper-slide-index="${e.realIndex}"]`).eq(0).index(),
                    m = i.slides.eq(s).nextAll(`[data-swiper-slide-index="${e.realIndex}"]`).eq(0).index();
                typeof l == "undefined" ? r = m : typeof m == "undefined" ? r = l : m - s === s - l ? r = i.params.slidesPerGroup > 1 ? m : s : m - s < s - l ? r = m : r = l, g = e.activeIndex > e.previousIndex ? "next" : "prev"
            } else r = e.realIndex, g = r > e.previousIndex ? "next" : "prev";
            c && (r += g === "next" ? o : -1 * o), i.visibleSlidesIndexes && i.visibleSlidesIndexes.indexOf(r) < 0 && (i.params.centeredSlides ? r > s ? r = r - Math.floor(a / 2) + 1 : r = r + Math.floor(a / 2) - 1 : r > s && i.params.slidesPerGroup, i.slideTo(r, d ? 0 : void 0))
        }
    }
    u("beforeInit", () => {
        const {
            thumbs: d
        } = e.params;
        !d || !d.swiper || (v(), f(!0))
    }), u("slideChange update resize observerUpdate", () => {
        f()
    }), u("setTransition", (d, i) => {
        const a = e.thumbs.swiper;
        !a || a.destroyed || a.setTransition(i)
    }), u("beforeDestroy", () => {
        const d = e.thumbs.swiper;
        !d || d.destroyed || $ && d.destroy()
    }), Object.assign(e.thumbs, {
        init: v,
        update: f
    })
}

function Xe(C) {
    let {
        swiper: e,
        extendParams: x,
        emit: u,
        once: E
    } = C;
    x({
        freeMode: {
            enabled: !1,
            momentum: !0,
            momentumRatio: 1,
            momentumBounce: !0,
            momentumBounceRatio: 1,
            momentumVelocityRatio: 1,
            sticky: !1,
            minimumVelocity: .02
        }
    });

    function $() {
        const f = e.getTranslate();
        e.setTranslate(f), e.setTransition(0), e.touchEventsData.velocities.length = 0, e.freeMode.onTouchEnd({
            currentPos: e.rtl ? e.translate : -e.translate
        })
    }

    function b() {
        const {
            touchEventsData: f,
            touches: d
        } = e;
        f.velocities.length === 0 && f.velocities.push({
            position: d[e.isHorizontal() ? "startX" : "startY"],
            time: f.touchStartTime
        }), f.velocities.push({
            position: d[e.isHorizontal() ? "currentX" : "currentY"],
            time: q()
        })
    }

    function v(f) {
        let {
            currentPos: d
        } = f;
        const {
            params: i,
            $wrapperEl: a,
            rtlTranslate: t,
            snapGrid: n,
            touchEventsData: o
        } = e, s = q() - o.touchStartTime;
        if (d < -e.minTranslate()) {
            e.slideTo(e.activeIndex);
            return
        }
        if (d > -e.maxTranslate()) {
            e.slides.length < n.length ? e.slideTo(n.length - 1) : e.slideTo(e.slides.length - 1);
            return
        }
        if (i.freeMode.momentum) {
            if (o.velocities.length > 1) {
                const M = o.velocities.pop(),
                    O = o.velocities.pop(),
                    k = M.position - O.position,
                    w = M.time - O.time;
                e.velocity = k / w, e.velocity /= 2, Math.abs(e.velocity) < i.freeMode.minimumVelocity && (e.velocity = 0), (w > 150 || q() - M.time > 300) && (e.velocity = 0)
            } else e.velocity = 0;
            e.velocity *= i.freeMode.momentumVelocityRatio, o.velocities.length = 0;
            let r = 1e3 * i.freeMode.momentumRatio;
            const g = e.velocity * r;
            let l = e.translate + g;
            t && (l = -l);
            let m = !1,
                D;
            const T = Math.abs(e.velocity) * 20 * i.freeMode.momentumBounceRatio;
            let z;
            if (l < e.maxTranslate()) i.freeMode.momentumBounce ? (l + e.maxTranslate() < -T && (l = e.maxTranslate() - T), D = e.maxTranslate(), m = !0, o.allowMomentumBounce = !0) : l = e.maxTranslate(), i.loop && i.centeredSlides && (z = !0);
            else if (l > e.minTranslate()) i.freeMode.momentumBounce ? (l - e.minTranslate() > T && (l = e.minTranslate() + T), D = e.minTranslate(), m = !0, o.allowMomentumBounce = !0) : l = e.minTranslate(), i.loop && i.centeredSlides && (z = !0);
            else if (i.freeMode.sticky) {
                let M;
                for (let O = 0; O < n.length; O += 1)
                    if (n[O] > -l) {
                        M = O;
                        break
                    }
                Math.abs(n[M] - l) < Math.abs(n[M - 1] - l) || e.swipeDirection === "next" ? l = n[M] : l = n[M - 1], l = -l
            }
            if (z && E("transitionEnd", () => {
                    e.loopFix()
                }), e.velocity !== 0) {
                if (t ? r = Math.abs((-l - e.translate) / e.velocity) : r = Math.abs((l - e.translate) / e.velocity), i.freeMode.sticky) {
                    const M = Math.abs((t ? -l : l) - e.translate),
                        O = e.slidesSizesGrid[e.activeIndex];
                    M < O ? r = i.speed : M < 2 * O ? r = i.speed * 1.5 : r = i.speed * 2.5
                }
            } else if (i.freeMode.sticky) {
                e.slideToClosest();
                return
            }
            i.freeMode.momentumBounce && m ? (e.updateProgress(D), e.setTransition(r), e.setTranslate(l), e.transitionStart(!0, e.swipeDirection), e.animating = !0, a.transitionEnd(() => {
                !e || e.destroyed || !o.allowMomentumBounce || (u("momentumBounce"), e.setTransition(i.speed), setTimeout(() => {
                    e.setTranslate(D), a.transitionEnd(() => {
                        !e || e.destroyed || e.transitionEnd()
                    })
                }, 0))
            })) : e.velocity ? (u("_freeModeNoMomentumRelease"), e.updateProgress(l), e.setTransition(r), e.setTranslate(l), e.transitionStart(!0, e.swipeDirection), e.animating || (e.animating = !0, a.transitionEnd(() => {
                !e || e.destroyed || e.transitionEnd()
            }))) : e.updateProgress(l), e.updateActiveIndex(), e.updateSlidesClasses()
        } else if (i.freeMode.sticky) {
            e.slideToClosest();
            return
        } else i.freeMode && u("_freeModeNoMomentumRelease");
        (!i.freeMode.momentum || s >= i.longSwipesMs) && (e.updateProgress(), e.updateActiveIndex(), e.updateSlidesClasses())
    }
    Object.assign(e, {
        freeMode: {
            onTouchStart: $,
            onTouchMove: b,
            onTouchEnd: v
        }
    })
}

function Ye(C) {
    let {
        swiper: e,
        extendParams: x
    } = C;
    x({
        grid: {
            rows: 1,
            fill: "column"
        }
    });
    let u, E, $;
    const b = d => {
            const {
                slidesPerView: i
            } = e.params, {
                rows: a,
                fill: t
            } = e.params.grid;
            E = u / a, $ = Math.floor(d / a), Math.floor(d / a) === d / a ? u = d : u = Math.ceil(d / a) * a, i !== "auto" && t === "row" && (u = Math.max(u, i * a))
        },
        v = (d, i, a, t) => {
            const {
                slidesPerGroup: n,
                spaceBetween: o
            } = e.params, {
                rows: c,
                fill: s
            } = e.params.grid;
            let r, g, l;
            if (s === "row" && n > 1) {
                const m = Math.floor(d / (n * c)),
                    D = d - c * n * m,
                    T = m === 0 ? n : Math.min(Math.ceil((a - m * c * n) / c), n);
                l = Math.floor(D / T), g = D - l * T + m * n, r = g + l * u / c, i.css({
                    "-webkit-order": r,
                    order: r
                })
            } else s === "column" ? (g = Math.floor(d / c), l = d - g * c, (g > $ || g === $ && l === c - 1) && (l += 1, l >= c && (l = 0, g += 1))) : (l = Math.floor(d / E), g = d - l * E);
            i.css(t("margin-top"), l !== 0 ? o && `${o}px` : "")
        },
        f = (d, i, a) => {
            const {
                spaceBetween: t,
                centeredSlides: n,
                roundLengths: o
            } = e.params, {
                rows: c
            } = e.params.grid;
            if (e.virtualSize = (d + t) * u, e.virtualSize = Math.ceil(e.virtualSize / c) - t, e.$wrapperEl.css({
                    [a("width")]: `${e.virtualSize+t}px`
                }), n) {
                i.splice(0, i.length);
                const s = [];
                for (let r = 0; r < i.length; r += 1) {
                    let g = i[r];
                    o && (g = Math.floor(g)), i[r] < e.virtualSize + i[0] && s.push(g)
                }
                i.push(...s)
            }
        };
    e.grid = {
        initSlides: b,
        updateSlide: v,
        updateWrapperSize: f
    }
}

function me(C) {
    const e = this,
        {
            $wrapperEl: x,
            params: u
        } = e;
    if (u.loop && e.loopDestroy(), typeof C == "object" && "length" in C)
        for (let E = 0; E < C.length; E += 1) C[E] && x.append(C[E]);
    else x.append(C);
    u.loop && e.loopCreate(), u.observer || e.update()
}

function he(C) {
    const e = this,
        {
            params: x,
            $wrapperEl: u,
            activeIndex: E
        } = e;
    x.loop && e.loopDestroy();
    let $ = E + 1;
    if (typeof C == "object" && "length" in C) {
        for (let b = 0; b < C.length; b += 1) C[b] && u.prepend(C[b]);
        $ = E + C.length
    } else u.prepend(C);
    x.loop && e.loopCreate(), x.observer || e.update(), e.slideTo($, 0, !1)
}

function ge(C, e) {
    const x = this,
        {
            $wrapperEl: u,
            params: E,
            activeIndex: $
        } = x;
    let b = $;
    E.loop && (b -= x.loopedSlides, x.loopDestroy(), x.slides = u.children(`.${E.slideClass}`));
    const v = x.slides.length;
    if (C <= 0) {
        x.prependSlide(e);
        return
    }
    if (C >= v) {
        x.appendSlide(e);
        return
    }
    let f = b > C ? b + 1 : b;
    const d = [];
    for (let i = v - 1; i >= C; i -= 1) {
        const a = x.slides.eq(i);
        a.remove(), d.unshift(a)
    }
    if (typeof e == "object" && "length" in e) {
        for (let i = 0; i < e.length; i += 1) e[i] && u.append(e[i]);
        f = b > C ? b + e.length : b
    } else u.append(e);
    for (let i = 0; i < d.length; i += 1) u.append(d[i]);
    E.loop && x.loopCreate(), E.observer || x.update(), E.loop ? x.slideTo(f + x.loopedSlides, 0, !1) : x.slideTo(f, 0, !1)
}

function ve(C) {
    const e = this,
        {
            params: x,
            $wrapperEl: u,
            activeIndex: E
        } = e;
    let $ = E;
    x.loop && ($ -= e.loopedSlides, e.loopDestroy(), e.slides = u.children(`.${x.slideClass}`));
    let b = $,
        v;
    if (typeof C == "object" && "length" in C) {
        for (let f = 0; f < C.length; f += 1) v = C[f], e.slides[v] && e.slides.eq(v).remove(), v < b && (b -= 1);
        b = Math.max(b, 0)
    } else v = C, e.slides[v] && e.slides.eq(v).remove(), v < b && (b -= 1), b = Math.max(b, 0);
    x.loop && e.loopCreate(), x.observer || e.update(), x.loop ? e.slideTo(b + e.loopedSlides, 0, !1) : e.slideTo(b, 0, !1)
}

function we() {
    const C = this,
        e = [];
    for (let x = 0; x < C.slides.length; x += 1) e.push(x);
    C.removeSlide(e)
}

function Ae(C) {
    let {
        swiper: e
    } = C;
    Object.assign(e, {
        appendSlide: me.bind(e),
        prependSlide: he.bind(e),
        addSlide: ge.bind(e),
        removeSlide: ve.bind(e),
        removeAllSlides: we.bind(e)
    })
}

function j(C) {
    const {
        effect: e,
        swiper: x,
        on: u,
        setTranslate: E,
        setTransition: $,
        overwriteParams: b,
        perspective: v,
        recreateShadows: f,
        getEffectParams: d
    } = C;
    u("beforeInit", () => {
        if (x.params.effect !== e) return;
        x.classNames.push(`${x.params.containerModifierClass}${e}`), v && v() && x.classNames.push(`${x.params.containerModifierClass}3d`);
        const a = b ? b() : {};
        Object.assign(x.params, a), Object.assign(x.originalParams, a)
    }), u("setTranslate", () => {
        x.params.effect === e && E()
    }), u("setTransition", (a, t) => {
        x.params.effect === e && $(t)
    }), u("transitionEnd", () => {
        if (x.params.effect === e && f) {
            if (!d || !d().slideShadows) return;
            x.slides.each(a => {
                x.$(a).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").remove()
            }), f()
        }
    });
    let i;
    u("virtualUpdate", () => {
        x.params.effect === e && (x.slides.length || (i = !0), requestAnimationFrame(() => {
            i && x.slides && x.slides.length && (E(), i = !1)
        }))
    })
}

function K(C, e) {
    return C.transformEl ? e.find(C.transformEl).css({
        "backface-visibility": "hidden",
        "-webkit-backface-visibility": "hidden"
    }) : e
}

function te(C) {
    let {
        swiper: e,
        duration: x,
        transformEl: u,
        allSlides: E
    } = C;
    const {
        slides: $,
        activeIndex: b,
        $wrapperEl: v
    } = e;
    if (e.params.virtualTranslate && x !== 0) {
        let f = !1,
            d;
        E ? d = u ? $.find(u) : $ : d = u ? $.eq(b).find(u) : $.eq(b), d.transitionEnd(() => {
            if (f || !e || e.destroyed) return;
            f = !0, e.animating = !1;
            const i = ["webkitTransitionEnd", "transitionend"];
            for (let a = 0; a < i.length; a += 1) v.trigger(i[a])
        })
    }
}

function Le(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        fadeEffect: {
            crossFade: !1,
            transformEl: null
        }
    }), j({
        effect: "fade",
        swiper: e,
        on: u,
        setTranslate: () => {
            const {
                slides: b
            } = e, v = e.params.fadeEffect;
            for (let f = 0; f < b.length; f += 1) {
                const d = e.slides.eq(f);
                let a = -d[0].swiperSlideOffset;
                e.params.virtualTranslate || (a -= e.translate);
                let t = 0;
                e.isHorizontal() || (t = a, a = 0);
                const n = e.params.fadeEffect.crossFade ? Math.max(1 - Math.abs(d[0].progress), 0) : 1 + Math.min(Math.max(d[0].progress, -1), 0);
                K(v, d).css({
                    opacity: n
                }).transform(`translate3d(${a}px, ${t}px, 0px)`)
            }
        },
        setTransition: b => {
            const {
                transformEl: v
            } = e.params.fadeEffect;
            (v ? e.slides.find(v) : e.slides).transition(b), te({
                swiper: e,
                duration: b,
                transformEl: v,
                allSlides: !0
            })
        },
        overwriteParams: () => ({
            slidesPerView: 1,
            slidesPerGroup: 1,
            watchSlidesProgress: !0,
            spaceBetween: 0,
            virtualTranslate: !e.params.cssMode
        })
    })
}

function Be(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        cubeEffect: {
            slideShadows: !0,
            shadow: !0,
            shadowOffset: 20,
            shadowScale: .94
        }
    });
    const E = (f, d, i) => {
        let a = i ? f.find(".swiper-slide-shadow-left") : f.find(".swiper-slide-shadow-top"),
            t = i ? f.find(".swiper-slide-shadow-right") : f.find(".swiper-slide-shadow-bottom");
        a.length === 0 && (a = X(`<div class="swiper-slide-shadow-${i?"left":"top"}"></div>`), f.append(a)), t.length === 0 && (t = X(`<div class="swiper-slide-shadow-${i?"right":"bottom"}"></div>`), f.append(t)), a.length && (a[0].style.opacity = Math.max(-d, 0)), t.length && (t[0].style.opacity = Math.max(d, 0))
    };
    j({
        effect: "cube",
        swiper: e,
        on: u,
        setTranslate: () => {
            const {
                $el: f,
                $wrapperEl: d,
                slides: i,
                width: a,
                height: t,
                rtlTranslate: n,
                size: o,
                browser: c
            } = e, s = e.params.cubeEffect, r = e.isHorizontal(), g = e.virtual && e.params.virtual.enabled;
            let l = 0,
                m;
            s.shadow && (r ? (m = d.find(".swiper-cube-shadow"), m.length === 0 && (m = X('<div class="swiper-cube-shadow"></div>'), d.append(m)), m.css({
                height: `${a}px`
            })) : (m = f.find(".swiper-cube-shadow"), m.length === 0 && (m = X('<div class="swiper-cube-shadow"></div>'), f.append(m))));
            for (let T = 0; T < i.length; T += 1) {
                const z = i.eq(T);
                let M = T;
                g && (M = parseInt(z.attr("data-swiper-slide-index"), 10));
                let O = M * 90,
                    k = Math.floor(O / 360);
                n && (O = -O, k = Math.floor(-O / 360));
                const w = Math.max(Math.min(z[0].progress, 1), -1);
                let p = 0,
                    y = 0,
                    S = 0;
                M % 4 === 0 ? (p = -k * 4 * o, S = 0) : (M - 1) % 4 === 0 ? (p = 0, S = -k * 4 * o) : (M - 2) % 4 === 0 ? (p = o + k * 4 * o, S = o) : (M - 3) % 4 === 0 && (p = -o, S = 3 * o + o * 4 * k), n && (p = -p), r || (y = p, p = 0);
                const Y = `rotateX(${r?0:-O}deg) rotateY(${r?O:0}deg) translate3d(${p}px, ${y}px, ${S}px)`;
                w <= 1 && w > -1 && (l = M * 90 + w * 90, n && (l = -M * 90 - w * 90)), z.transform(Y), s.slideShadows && E(z, w, r)
            }
            if (d.css({
                    "-webkit-transform-origin": `50% 50% -${o/2}px`,
                    "transform-origin": `50% 50% -${o/2}px`
                }), s.shadow)
                if (r) m.transform(`translate3d(0px, ${a/2+s.shadowOffset}px, ${-a/2}px) rotateX(90deg) rotateZ(0deg) scale(${s.shadowScale})`);
                else {
                    const T = Math.abs(l) - Math.floor(Math.abs(l) / 90) * 90,
                        z = 1.5 - (Math.sin(T * 2 * Math.PI / 360) / 2 + Math.cos(T * 2 * Math.PI / 360) / 2),
                        M = s.shadowScale,
                        O = s.shadowScale / z,
                        k = s.shadowOffset;
                    m.transform(`scale3d(${M}, 1, ${O}) translate3d(0px, ${t/2+k}px, ${-t/2/O}px) rotateX(-90deg)`)
                }
            const D = c.isSafari || c.isWebView ? -o / 2 : 0;
            d.transform(`translate3d(0px,0,${D}px) rotateX(${e.isHorizontal()?0:l}deg) rotateY(${e.isHorizontal()?-l:0}deg)`), d[0].style.setProperty("--swiper-cube-translate-z", `${D}px`)
        },
        setTransition: f => {
            const {
                $el: d,
                slides: i
            } = e;
            i.transition(f).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(f), e.params.cubeEffect.shadow && !e.isHorizontal() && d.find(".swiper-cube-shadow").transition(f)
        },
        recreateShadows: () => {
            const f = e.isHorizontal();
            e.slides.each(d => {
                const i = Math.max(Math.min(d.progress, 1), -1);
                E(X(d), i, f)
            })
        },
        getEffectParams: () => e.params.cubeEffect,
        perspective: () => !0,
        overwriteParams: () => ({
            slidesPerView: 1,
            slidesPerGroup: 1,
            watchSlidesProgress: !0,
            resistanceRatio: 0,
            spaceBetween: 0,
            centeredSlides: !1,
            virtualTranslate: !0
        })
    })
}

function F(C, e, x) {
    const u = `swiper-slide-shadow${x?`-${x}`:""}`,
        E = C.transformEl ? e.find(C.transformEl) : e;
    let $ = E.children(`.${u}`);
    return $.length || ($ = X(`<div class="swiper-slide-shadow${x?`-${x}`:""}"></div>`), E.append($)), $
}

function Re(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        flipEffect: {
            slideShadows: !0,
            limitRotation: !0,
            transformEl: null
        }
    });
    const E = (f, d, i) => {
        let a = e.isHorizontal() ? f.find(".swiper-slide-shadow-left") : f.find(".swiper-slide-shadow-top"),
            t = e.isHorizontal() ? f.find(".swiper-slide-shadow-right") : f.find(".swiper-slide-shadow-bottom");
        a.length === 0 && (a = F(i, f, e.isHorizontal() ? "left" : "top")), t.length === 0 && (t = F(i, f, e.isHorizontal() ? "right" : "bottom")), a.length && (a[0].style.opacity = Math.max(-d, 0)), t.length && (t[0].style.opacity = Math.max(d, 0))
    };
    j({
        effect: "flip",
        swiper: e,
        on: u,
        setTranslate: () => {
            const {
                slides: f,
                rtlTranslate: d
            } = e, i = e.params.flipEffect;
            for (let a = 0; a < f.length; a += 1) {
                const t = f.eq(a);
                let n = t[0].progress;
                e.params.flipEffect.limitRotation && (n = Math.max(Math.min(t[0].progress, 1), -1));
                const o = t[0].swiperSlideOffset;
                let s = -180 * n,
                    r = 0,
                    g = e.params.cssMode ? -o - e.translate : -o,
                    l = 0;
                e.isHorizontal() ? d && (s = -s) : (l = g, g = 0, r = -s, s = 0), t[0].style.zIndex = -Math.abs(Math.round(n)) + f.length, i.slideShadows && E(t, n, i);
                const m = `translate3d(${g}px, ${l}px, 0px) rotateX(${r}deg) rotateY(${s}deg)`;
                K(i, t).transform(m)
            }
        },
        setTransition: f => {
            const {
                transformEl: d
            } = e.params.flipEffect;
            (d ? e.slides.find(d) : e.slides).transition(f).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(f), te({
                swiper: e,
                duration: f,
                transformEl: d
            })
        },
        recreateShadows: () => {
            const f = e.params.flipEffect;
            e.slides.each(d => {
                const i = X(d);
                let a = i[0].progress;
                e.params.flipEffect.limitRotation && (a = Math.max(Math.min(d.progress, 1), -1)), E(i, a, f)
            })
        },
        getEffectParams: () => e.params.flipEffect,
        perspective: () => !0,
        overwriteParams: () => ({
            slidesPerView: 1,
            slidesPerGroup: 1,
            watchSlidesProgress: !0,
            spaceBetween: 0,
            virtualTranslate: !e.params.cssMode
        })
    })
}

function Ne(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        coverflowEffect: {
            rotate: 50,
            stretch: 0,
            depth: 100,
            scale: 1,
            modifier: 1,
            slideShadows: !0,
            transformEl: null
        }
    }), j({
        effect: "coverflow",
        swiper: e,
        on: u,
        setTranslate: () => {
            const {
                width: b,
                height: v,
                slides: f,
                slidesSizesGrid: d
            } = e, i = e.params.coverflowEffect, a = e.isHorizontal(), t = e.translate, n = a ? -t + b / 2 : -t + v / 2, o = a ? i.rotate : -i.rotate, c = i.depth;
            for (let s = 0, r = f.length; s < r; s += 1) {
                const g = f.eq(s),
                    l = d[s],
                    m = g[0].swiperSlideOffset,
                    D = (n - m - l / 2) / l,
                    T = typeof i.modifier == "function" ? i.modifier(D) : D * i.modifier;
                let z = a ? o * T : 0,
                    M = a ? 0 : o * T,
                    O = -c * Math.abs(T),
                    k = i.stretch;
                typeof k == "string" && k.indexOf("%") !== -1 && (k = parseFloat(i.stretch) / 100 * l);
                let w = a ? 0 : k * T,
                    p = a ? k * T : 0,
                    y = 1 - (1 - i.scale) * Math.abs(T);
                Math.abs(p) < .001 && (p = 0), Math.abs(w) < .001 && (w = 0), Math.abs(O) < .001 && (O = 0), Math.abs(z) < .001 && (z = 0), Math.abs(M) < .001 && (M = 0), Math.abs(y) < .001 && (y = 0);
                const S = `translate3d(${p}px,${w}px,${O}px)  rotateX(${M}deg) rotateY(${z}deg) scale(${y})`;
                if (K(i, g).transform(S), g[0].style.zIndex = -Math.abs(Math.round(T)) + 1, i.slideShadows) {
                    let H = a ? g.find(".swiper-slide-shadow-left") : g.find(".swiper-slide-shadow-top"),
                        h = a ? g.find(".swiper-slide-shadow-right") : g.find(".swiper-slide-shadow-bottom");
                    H.length === 0 && (H = F(i, g, a ? "left" : "top")), h.length === 0 && (h = F(i, g, a ? "right" : "bottom")), H.length && (H[0].style.opacity = T > 0 ? T : 0), h.length && (h[0].style.opacity = -T > 0 ? -T : 0)
                }
            }
        },
        setTransition: b => {
            const {
                transformEl: v
            } = e.params.coverflowEffect;
            (v ? e.slides.find(v) : e.slides).transition(b).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(b)
        },
        perspective: () => !0,
        overwriteParams: () => ({
            watchSlidesProgress: !0
        })
    })
}

function We(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        creativeEffect: {
            transformEl: null,
            limitProgress: 1,
            shadowPerProgress: !1,
            progressMultiplier: 1,
            perspective: !0,
            prev: {
                translate: [0, 0, 0],
                rotate: [0, 0, 0],
                opacity: 1,
                scale: 1
            },
            next: {
                translate: [0, 0, 0],
                rotate: [0, 0, 0],
                opacity: 1,
                scale: 1
            }
        }
    });
    const E = v => typeof v == "string" ? v : `${v}px`;
    j({
        effect: "creative",
        swiper: e,
        on: u,
        setTranslate: () => {
            const {
                slides: v,
                $wrapperEl: f,
                slidesSizesGrid: d
            } = e, i = e.params.creativeEffect, {
                progressMultiplier: a
            } = i, t = e.params.centeredSlides;
            if (t) {
                const n = d[0] / 2 - e.params.slidesOffsetBefore || 0;
                f.transform(`translateX(calc(50% - ${n}px))`)
            }
            for (let n = 0; n < v.length; n += 1) {
                const o = v.eq(n),
                    c = o[0].progress,
                    s = Math.min(Math.max(o[0].progress, -i.limitProgress), i.limitProgress);
                let r = s;
                t || (r = Math.min(Math.max(o[0].originalProgress, -i.limitProgress), i.limitProgress));
                const g = o[0].swiperSlideOffset,
                    l = [e.params.cssMode ? -g - e.translate : -g, 0, 0],
                    m = [0, 0, 0];
                let D = !1;
                e.isHorizontal() || (l[1] = l[0], l[0] = 0);
                let T = {
                    translate: [0, 0, 0],
                    rotate: [0, 0, 0],
                    scale: 1,
                    opacity: 1
                };
                s < 0 ? (T = i.next, D = !0) : s > 0 && (T = i.prev, D = !0), l.forEach((y, S) => {
                    l[S] = `calc(${y}px + (${E(T.translate[S])} * ${Math.abs(s*a)}))`
                }), m.forEach((y, S) => {
                    m[S] = T.rotate[S] * Math.abs(s * a)
                }), o[0].style.zIndex = -Math.abs(Math.round(c)) + v.length;
                const z = l.join(", "),
                    M = `rotateX(${m[0]}deg) rotateY(${m[1]}deg) rotateZ(${m[2]}deg)`,
                    O = r < 0 ? `scale(${1+(1-T.scale)*r*a})` : `scale(${1-(1-T.scale)*r*a})`,
                    k = r < 0 ? 1 + (1 - T.opacity) * r * a : 1 - (1 - T.opacity) * r * a,
                    w = `translate3d(${z}) ${M} ${O}`;
                if (D && T.shadow || !D) {
                    let y = o.children(".swiper-slide-shadow");
                    if (y.length === 0 && T.shadow && (y = F(i, o)), y.length) {
                        const S = i.shadowPerProgress ? s * (1 / i.limitProgress) : s;
                        y[0].style.opacity = Math.min(Math.max(Math.abs(S), 0), 1)
                    }
                }
                const p = K(i, o);
                p.transform(w).css({
                    opacity: k
                }), T.origin && p.css("transform-origin", T.origin)
            }
        },
        setTransition: v => {
            const {
                transformEl: f
            } = e.params.creativeEffect;
            (f ? e.slides.find(f) : e.slides).transition(v).find(".swiper-slide-shadow").transition(v), te({
                swiper: e,
                duration: v,
                transformEl: f,
                allSlides: !0
            })
        },
        perspective: () => e.params.creativeEffect.perspective,
        overwriteParams: () => ({
            watchSlidesProgress: !0,
            virtualTranslate: !e.params.cssMode
        })
    })
}

function qe(C) {
    let {
        swiper: e,
        extendParams: x,
        on: u
    } = C;
    x({
        cardsEffect: {
            slideShadows: !0,
            transformEl: null,
            rotate: !0
        }
    }), j({
        effect: "cards",
        swiper: e,
        on: u,
        setTranslate: () => {
            const {
                slides: b,
                activeIndex: v
            } = e, f = e.params.cardsEffect, {
                startTranslate: d,
                isTouched: i
            } = e.touchEventsData, a = e.translate;
            for (let t = 0; t < b.length; t += 1) {
                const n = b.eq(t),
                    o = n[0].progress,
                    c = Math.min(Math.max(o, -4), 4);
                let s = n[0].swiperSlideOffset;
                e.params.centeredSlides && !e.params.cssMode && e.$wrapperEl.transform(`translateX(${e.minTranslate()}px)`), e.params.centeredSlides && e.params.cssMode && (s -= b[0].swiperSlideOffset);
                let r = e.params.cssMode ? -s - e.translate : -s,
                    g = 0;
                const l = -100 * Math.abs(c);
                let m = 1,
                    D = -2 * c,
                    T = 8 - Math.abs(c) * .75;
                const z = e.virtual && e.params.virtual.enabled ? e.virtual.from + t : t,
                    M = (z === v || z === v - 1) && c > 0 && c < 1 && (i || e.params.cssMode) && a < d,
                    O = (z === v || z === v + 1) && c < 0 && c > -1 && (i || e.params.cssMode) && a > d;
                if (M || O) {
                    const y = (1 - Math.abs((Math.abs(c) - .5) / .5)) ** .5;
                    D += -28 * c * y, m += -.5 * y, T += 96 * y, g = `${-25*y*Math.abs(c)}%`
                }
                if (c < 0 ? r = `calc(${r}px + (${T*Math.abs(c)}%))` : c > 0 ? r = `calc(${r}px + (-${T*Math.abs(c)}%))` : r = `${r}px`, !e.isHorizontal()) {
                    const y = g;
                    g = r, r = y
                }
                const k = c < 0 ? `${1+(1-m)*c}` : `${1-(1-m)*c}`,
                    w = `
        translate3d(${r}, ${g}, ${l}px)
        rotateZ(${f.rotate?D:0}deg)
        scale(${k})
      `;
                if (f.slideShadows) {
                    let y = n.find(".swiper-slide-shadow");
                    y.length === 0 && (y = F(f, n)), y.length && (y[0].style.opacity = Math.min(Math.max((Math.abs(c) - .5) / .5, 0), 1))
                }
                n[0].style.zIndex = -Math.abs(Math.round(o)) + b.length, K(f, n).transform(w)
            }
        },
        setTransition: b => {
            const {
                transformEl: v
            } = e.params.cardsEffect;
            (v ? e.slides.find(v) : e.slides).transition(b).find(".swiper-slide-shadow").transition(b), te({
                swiper: e,
                duration: b,
                transformEl: v
            })
        },
        perspective: () => !0,
        overwriteParams: () => ({
            watchSlidesProgress: !0,
            virtualTranslate: !e.params.cssMode
        })
    })
}
export {
    Ie as A11y, De as Autoplay, ze as Controller, qe as EffectCards, Ne as EffectCoverflow, We as EffectCreative, Be as EffectCube, Le as EffectFade, Re as EffectFlip, Xe as FreeMode, Ye as Grid, Oe as HashNavigation, ke as History, Ee as Keyboard, Pe as Lazy, Ae as Manipulation, xe as Mousewheel, ye as Navigation, Ce as Pagination, Te as Parallax, Me as Scrollbar, Fe as Swiper, He as Thumbs, $e as Virtual, Se as Zoom, je as
    default
};